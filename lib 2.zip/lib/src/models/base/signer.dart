import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/exception/exception.dart';
import 'package:stellar_dart/src/serialization/serialization.dart';
import 'package:stellar_dart/src/utils/validator.dart';

class SignerKeyType {
  final String name;
  final int value;

  const SignerKeyType._({required this.name, required this.value});

  static const SignerKeyType ed25519 =
      SignerKeyType._(name: 'ed25519', value: 0);
  static const SignerKeyType preAuthTx =
      SignerKeyType._(name: 'preAuthTx', value: 1);
  static const SignerKeyType hashX = SignerKeyType._(name: 'hashX', value: 2);
  static const SignerKeyType ed25519SignedPayload =
      SignerKeyType._(name: 'ed25519SignedPayload', value: 3);
  static const List<SignerKeyType> values = [
    ed25519,
    preAuthTx,
    hashX,
    ed25519SignedPayload
  ];
  static SignerKeyType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "SignerKey type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "SignerKeyType.$name";
  }
}

abstract class SignerKey extends XDRVariantSerialization<Map<String, dynamic>> {
  final SignerKeyType type;
  const SignerKey({required this.type});
  factory SignerKey.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = SignerKeyType.fromName(decode.variantName);
    switch (type) {
      case SignerKeyType.ed25519:
        return SignerKeyEd25519.fromStruct(decode.value);
      case SignerKeyType.hashX:
        return SignerKeyHashX.fromStruct(decode.value);
      case SignerKeyType.preAuthTx:
        return SignerKeyPreAuthTx.fromStruct(decode.value);
      case SignerKeyType.ed25519SignedPayload:
        return SignerKeyEd25519SignedPayload.fromStruct(decode.value);
      default:
        throw UnimplementedError("Invalid SignerKeyType.");
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be(
        List.generate(SignerKeyType.values.length, (index) {
          final type = SignerKeyType.values.elementAt(index);
          switch (type) {
            case SignerKeyType.ed25519:
              return LazyLayout(
                  layout: SignerKeyEd25519.layout, property: type.name);
            case SignerKeyType.hashX:
              return LazyLayout(
                  layout: SignerKeyHashX.layout, property: type.name);
            case SignerKeyType.preAuthTx:
              return LazyLayout(
                  layout: SignerKeyPreAuthTx.layout, property: type.name);
            case SignerKeyType.ed25519SignedPayload:
              return LazyLayout(
                  layout: SignerKeyEd25519.layout, property: type.name);
            default:
              throw UnimplementedError("Invalid SignerKeyType.");
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class SignerKeyEd25519SignedPayload extends SignerKey {
  final List<int> ed25519;
  final List<int> payload;
  SignerKeyEd25519SignedPayload(
      {required List<int> ed25519, required List<int> payload})
      : ed25519 =
            ed25519.asImmutableBytes.exc(StellarConst.ed25519PubKeyLength),
        payload = payload.asImmutableBytes.max(StellarConst.payloadLength),
        super(type: SignerKeyType.ed25519SignedPayload);

  factory SignerKeyEd25519SignedPayload.fromStruct(Map<String, dynamic> json) {
    return SignerKeyEd25519SignedPayload(
        ed25519: json.asBytes("ed25519"), payload: json.asBytes("payload"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.ed25519PubKeyLength,
          property: "ed25519"),
      LayoutConst.xdrVecBytes(property: "payload"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"ed25519": ed25519, "payload": payload};
  }
}

class SignerKeyEd25519 extends SignerKey {
  final List<int> ed25519;
  SignerKeyEd25519(List<int> ed25519)
      : ed25519 =
            ed25519.asImmutableBytes.exc(StellarConst.ed25519PubKeyLength),
        super(type: SignerKeyType.ed25519);

  factory SignerKeyEd25519.fromStruct(Map<String, dynamic> json) {
    return SignerKeyEd25519(json.asBytes("ed25519"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.ed25519PubKeyLength,
          property: "ed25519")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"ed25519": ed25519};
  }
}

class SignerKeyPreAuthTx extends SignerKey {
  final List<int> preAuthTx;
  SignerKeyPreAuthTx(List<int> preAuthTx)
      : preAuthTx = preAuthTx.asImmutableBytes.exc(StellarConst.hash256Length),
        super(type: SignerKeyType.preAuthTx);

  factory SignerKeyPreAuthTx.fromStruct(Map<String, dynamic> json) {
    return SignerKeyPreAuthTx(json.asBytes("preAuthTx"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.ed25519PubKeyLength,
          property: "preAuthTx")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"preAuthTx": preAuthTx};
  }
}

class SignerKeyHashX extends SignerKey {
  final List<int> hashX;
  SignerKeyHashX(List<int> hashX)
      : hashX = hashX.asImmutableBytes.exc(StellarConst.hash256Length),
        super(type: SignerKeyType.hashX);

  factory SignerKeyHashX.fromStruct(Map<String, dynamic> json) {
    return SignerKeyHashX(json.asBytes("hashX"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.ed25519PubKeyLength,
          property: "hashX")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hashX": hashX};
  }
}

class Signer extends XDRSerialization<Map<String, dynamic>> {
  final SignerKey key;
  final int weight;
  Signer({required this.key, required int weight}) : weight = weight.asUint32;
  factory Signer.fromStruct(Map<String, dynamic> json) {
    return Signer(
        key: SignerKey.fromStruct(json.asMap("key")),
        weight: json.as("weight"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      SignerKey.layout(property: "key"),
      LayoutConst.u32be(property: "weight")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"key": key.toVariantLayoutStruct(), "weight": weight};
  }
}
