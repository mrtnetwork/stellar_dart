import 'package:blockchain_utils/bip/address/encoders.dart';
import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:blockchain_utils/helper/helper.dart';
import 'package:blockchain_utils/layout/core/types/lazy_union.dart';
import 'package:stellar_dart/src/address/address.dart';
import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/exception/exception.dart';
import 'package:stellar_dart/src/helper/helper.dart';
import 'package:stellar_dart/src/keypair/keypair.dart';
import 'package:stellar_dart/src/models/asset/asset.dart';
import 'package:stellar_dart/src/models/hash/hash.dart';
import 'package:stellar_dart/src/operations/operation.dart';
import 'package:stellar_dart/src/serialization/serialization.dart';
import 'package:stellar_dart/src/utils/utils.dart';
import 'package:stellar_dart/src/utils/validator.dart';
import 'memo.dart';
import 'signer.dart';
import 'dart:math' as math;

class LedgerEntryType {
  final String name;
  final int value;
  const LedgerEntryType._(this.name, this.value);

  static const LedgerEntryType account = LedgerEntryType._('account', 0);
  static const LedgerEntryType trustline = LedgerEntryType._('trustline', 1);
  static const LedgerEntryType offer = LedgerEntryType._('offer', 2);
  static const LedgerEntryType data = LedgerEntryType._('data', 3);
  static const LedgerEntryType claimableBalance =
      LedgerEntryType._('claimableBalance', 4);
  static const LedgerEntryType liquidityPool =
      LedgerEntryType._('liquidityPool', 5);
  static const LedgerEntryType contractData =
      LedgerEntryType._('contractData', 6);
  static const LedgerEntryType contractCode =
      LedgerEntryType._('contractCode', 7);
  static const LedgerEntryType configSetting =
      LedgerEntryType._('configSetting', 8);
  static const LedgerEntryType ttl = LedgerEntryType._('ttl', 9);
  static const List<LedgerEntryType> values = [
    account,
    trustline,
    offer,
    data,
    claimableBalance,
    liquidityPool,
    contractData,
    contractCode,
    configSetting,
    ttl
  ];
  static LedgerEntryType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "LedgerEntry type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "LedgerEntryType.$name";
  }
}

abstract class LedgerEntryData<T> {
  final LedgerEntryType type;
  const LedgerEntryData(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    throw UnimplementedError();
  }

  // @override
  // Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
  //   throw UnimplementedError();
  // }

  // @override
  // String get variantName => type.name;
}

abstract class ExtPoint {
  abstract final int value;
  const ExtPoint();
}

class Liabilities {
  final BigInt buying;
  final BigInt selling;
  Liabilities({required BigInt buying, required BigInt selling})
      : buying = buying.asInt64,
        selling = selling.asInt64;
}

class AccountEntry extends LedgerEntryData {
  final StellarBaseAddress accountId;
  final BigInt balance;
  final BigInt seqNum;
  final int numSubEntries;
  final StellarBaseAddress? inflationDest;
  final int flags;
  final List<int> homeDomain;
  final List<int> thresholds;
  final List<Signer> signers;
  final AccountEntryExt ext;

  AccountEntry(
      {required this.accountId,
      required BigInt balance,
      required BigInt seqNum,
      required int numSubEntries,
      this.inflationDest,
      required int flags,
      required List<int> homeDomain,
      required List<int> thresholds,
      required List<Signer> signers,
      required this.ext})
      : homeDomain = homeDomain.asImmutableBytes,
        thresholds = thresholds.asImmutableBytes,
        signers = signers.immutable,
        balance = balance.asInt64,
        seqNum = seqNum.asInt64,
        flags = flags.asUint32,
        numSubEntries = numSubEntries.asUint32,
        super(LedgerEntryType.account);
}

abstract class ExtentionPoint<T, E> extends XDRVariantSerialization<T> {
  final int id;
  final E value;
  const ExtentionPoint({required this.id, required this.value});
  @override
  String get variantName => "$id";
}

class ExtentionPointVoid extends XDRVariantSerialization<Map<String, dynamic>> {
  const ExtentionPointVoid();
  factory ExtentionPointVoid.fromStruct(Map<String, dynamic> json) {
    return ExtentionPointVoid();
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be([
      LazyLayout(
          layout: LayoutConst.noArgs,
          property: ExtensionPointType.extVoid.name),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }

  @override
  String get variantName {
    return ExtensionPointType.extVoid.name;
  }
}

class AccountEntryExtensionV3 {
  final int seqLedger;
  final BigInt seqTime;
  AccountEntryExtensionV3({
    required this.seqLedger,
    required BigInt seqTime,
  }) : seqTime = seqTime.asUint64;
}

class AccountEntryExtensionV2Ext extends ExtPoint {
  final AccountEntryExtensionV3? ext;
  const AccountEntryExtensionV2Ext(this.ext);

  @override
  int get value => ext == null ? 0 : 3;
}

class AccountEntryExtensionV2 {
  final int numSponsored;
  final int numSponsoring;
  final List<StellarBaseAddress?> signerSponsoringIDs;
  final AccountEntryExtensionV2Ext ext;
  AccountEntryExtensionV2({
    required int numSponsored,
    required int numSponsoring,
    List<StellarBaseAddress?> signerSponsoringIDs = const [],
    required this.ext,
  })  : numSponsored = numSponsored.asUint32,
        numSponsoring = numSponsoring.asUint32,
        signerSponsoringIDs = signerSponsoringIDs.immutable;
}

class AccountEntryExtensionV1Ext extends ExtPoint {
  final AccountEntryExtensionV2? ext;
  const AccountEntryExtensionV1Ext(this.ext);

  @override
  int get value => ext == null ? 0 : 2;
}

class AccountEntryExtensionV1 {
  final Liabilities liabilities;
  final AccountEntryExtensionV1Ext ext;
  const AccountEntryExtensionV1({required this.liabilities, required this.ext});
}

class AccountEntryExt extends ExtPoint {
  final AccountEntryExtensionV1? ext;
  const AccountEntryExt(this.ext);

  @override
  int get value => ext == null ? 0 : 1;
}

class TrustLineEntryExtensionV2Ext extends ExtPoint {
  const TrustLineEntryExtensionV2Ext();
  @override
  int get value => 0;
}
//  class TrustLineEntryExtensionV2 {
//     constructor(attributes: {
//       liquidityPoolUseCount: number;
//       ext: TrustLineEntryExtensionV2Ext;
//     });

class TrustLineEntryExtensionV2 {
  final int liquidityPoolUseCount;
  final TrustLineEntryExtensionV2Ext ext;
  TrustLineEntryExtensionV2(
      {required int liquidityPoolUseCount,
      this.ext = const TrustLineEntryExtensionV2Ext()})
      : liquidityPoolUseCount = liquidityPoolUseCount.asInt32;
}

class TrustLineEntryV1Ext extends ExtPoint {
  final TrustLineEntryExtensionV2? ext;
  const TrustLineEntryV1Ext(this.ext);

  @override
  int get value => ext == null ? 0 : 2;
}

class TrustLineEntryV1 {
  final Liabilities liabilities;
  final TrustLineEntryV1Ext ext;
  const TrustLineEntryV1({required this.liabilities, required this.ext});
}

class TrustLineEntryExt extends ExtPoint {
  final TrustLineEntryV1? ext;
  const TrustLineEntryExt(this.ext);
  @override
  int get value => ext == null ? 0 : 1;
}

/// accept poolId
typedef TrustLineAsset = StellarAsset;

class TrustLineEntry extends LedgerEntryData {
  final StellarPublicKey accountId;
  final TrustLineAsset asset;
  final BigInt balance;
  final BigInt limit;
  final int flags;
  final TrustLineEntryExt ext;
  TrustLineEntry(
      {required this.accountId,
      required this.asset,
      required BigInt balance,
      required BigInt limit,
      required int flags,
      required this.ext})
      : balance = balance.asInt64,
        limit = limit.asInt64,
        flags = flags.asUint32,
        super(LedgerEntryType.trustline);
}

class OfferEntryExt extends ExtPoint {
  @override
  int get value => 0;
}

class StellarPrice extends XDRSerialization<Map<String, dynamic>> {
  final int numerator;
  final int denominator;
  StellarPrice({required int numerator, required int denominator})
      : numerator = numerator.asInt32,
        denominator = denominator.asInt32;
  factory StellarPrice.fromDecimal(String price) {
    return StellarHelper.approximatePrice(price);
  }
  factory StellarPrice.fromStruct(Map<String, dynamic> json) {
    return StellarPrice(
        numerator: json.as("numerator"), denominator: json.as("denominator"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s32be(property: "numerator"),
      LayoutConst.s32be(property: "denominator"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"numerator": numerator, "denominator": denominator};
  }
}

class OfferEntry extends LedgerEntryData {
  final StellarBaseAddress sellerId;
  final BigInt offerId;
  final StellarAsset selling;
  final StellarAsset buying;
  final BigInt amount;
  final StellarPrice price;
  final int flags;
  final OfferEntryExt ext;
  OfferEntry(
      {required this.sellerId,
      required BigInt offerId,
      required this.selling,
      required this.buying,
      required BigInt amount,
      required this.price,
      required int flags,
      required this.ext})
      : offerId = offerId.asInt64,
        amount = amount.asInt64,
        flags = flags.asUint32,
        super(LedgerEntryType.offer);
}

class DataEntryExt extends ExtPoint {
  @override
  int get value => 0;
}

class DataEntry extends LedgerEntryData {
  final StellarAddress accountId;
  final List<int> dataName;
  final List<int> dataValue;
  final DataEntryExt ext;
  DataEntry(
      {required this.accountId,
      required List<int> dataName,
      required List<int> dataValue,
      required this.ext})
      : dataName = dataName.asImmutableBytes,
        dataValue = dataValue.asImmutableBytes,
        super(LedgerEntryType.data);
}

class ClaimableBalanceEntryExtensionV1Ext extends ExtPoint {
  @override
  int get value => 0;
}

class ClaimableBalanceEntryExtensionV1 {
  final ClaimableBalanceEntryExtensionV1Ext ext;
  final int flags;
  ClaimableBalanceEntryExtensionV1({required this.ext, required int flags})
      : flags = flags.asUint32;
}

class ClaimableBalanceEntryExt extends ExtPoint {
  final ClaimableBalanceEntryExtensionV1? ext;
  const ClaimableBalanceEntryExt(this.ext);

  @override
  int get value => ext == null ? 0 : 1;
}

class ClaimableBalanceIdType {
  final String name;
  final int value;
  const ClaimableBalanceIdType._({required this.name, required this.value});
  static const ClaimableBalanceIdType v0 =
      ClaimableBalanceIdType._(name: "V0", value: 0);
  static const List<ClaimableBalanceIdType> values = [v0];
  static ClaimableBalanceIdType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "ClaimableBalanceId not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ClaimableBalanceIdType.$name";
  }
}

abstract class ClaimableBalanceId
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final ClaimableBalanceIdType type;
  const ClaimableBalanceId(this.type);

  factory ClaimableBalanceId.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = ClaimableBalanceIdType.fromName(decode.variantName);
    switch (type) {
      case ClaimableBalanceIdType.v0:
        return ClaimableBalanceIdV0.fromStruct(decode.value);
      default:
        throw StellarAddressException("Invalid ClaimableBalanceId type.",
            details: {"type": type.name});
    }
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be(
        [ClaimableBalanceIdV0.layout(property: ClaimableBalanceIdType.v0.name)],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ClaimableBalanceIdV0 extends ClaimableBalanceId {
  final List<int> hash;
  ClaimableBalanceIdV0(List<int> hash)
      : hash = hash.asImmutableBytes.exc(StellarConst.hash256Length),
        super(ClaimableBalanceIdType.v0);
  factory ClaimableBalanceIdV0.fromStruct(Map<String, dynamic> json) {
    return ClaimableBalanceIdV0(json.asBytes("hash"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "hash")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hash": hash};
  }
}

class ClaimantType {
  final String name;
  final int value;
  const ClaimantType._({required this.name, required this.value});
  static const ClaimantType v0 = ClaimantType._(name: "V0", value: 0);
  static const List<ClaimantType> values = [v0];
  static ClaimantType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "Claimant type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ClaimantType.$name";
  }
}

abstract class Claimant extends XDRVariantSerialization<Map<String, dynamic>> {
  final ClaimantType type;
  const Claimant(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      ClaimantV0.layout(property: ClaimantType.v0.name),
    ], property: property);
  }

  factory Claimant.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = ClaimantType.fromName(decode.variantName);
    switch (type) {
      case ClaimantType.v0:
        return ClaimantV0.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid Claimant type.");
    }
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ClaimantV0 extends Claimant {
  final StellarPublicKey destination;
  final ClaimPredicate predicate;
  const ClaimantV0({required this.predicate, required this.destination})
      : super(ClaimantType.v0);
  factory ClaimantV0.fromStruct(Map<String, dynamic> json) {
    return ClaimantV0(
        destination: StellarPublicKey.fromStruct(json.asMap("destination")),
        predicate: ClaimPredicate.fromStruct(json.asMap("predicate")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "destination"),
      ClaimPredicate.layout(property: "predicate"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "destination": destination.toLayoutStruct(),
      "predicate": predicate.toVariantLayoutStruct(),
    };
  }
}

class ClaimPredicateType {
  final String name;
  final int value;
  const ClaimPredicateType._({required this.name, required this.value});
  static const ClaimPredicateType unconditional =
      ClaimPredicateType._(name: "Unconditional", value: 0);
  static const ClaimPredicateType and =
      ClaimPredicateType._(name: "And", value: 1);
  static const ClaimPredicateType or =
      ClaimPredicateType._(name: "Or", value: 2);
  static const ClaimPredicateType not =
      ClaimPredicateType._(name: "Not", value: 3);
  static const ClaimPredicateType beforeAbsoluteTime =
      ClaimPredicateType._(name: "BeforeAbsoluteTime", value: 4);
  static const ClaimPredicateType beforeRelativeTime =
      ClaimPredicateType._(name: "BeforeRelativeTime", value: 5);
  static const List<ClaimPredicateType> values = [
    unconditional,
    and,
    or,
    not,
    beforeAbsoluteTime,
    beforeRelativeTime
  ];
  static ClaimPredicateType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "ClaimPredicate type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ClaimPredicateType.$name";
  }
}

abstract class ClaimPredicate
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final ClaimPredicateType type;
  const ClaimPredicate(this.type);
  factory ClaimPredicate.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = ClaimPredicateType.fromName(decode.variantName);
    switch (type) {
      case ClaimPredicateType.unconditional:
        return ClaimPredicateUnconditional.fromStruct(decode.value);
      case ClaimPredicateType.and:
        return ClaimPredicateAnd.fromStruct(decode.value);
      case ClaimPredicateType.or:
        return ClaimPredicateOr.fromStruct(decode.value);
      case ClaimPredicateType.not:
        return ClaimPredicateNot.fromStruct(decode.value);
      case ClaimPredicateType.beforeAbsoluteTime:
        return ClaimPredicateBeforeAbsoluteTime.fromStruct(decode.value);
      case ClaimPredicateType.beforeRelativeTime:
        return ClaimPredicateBeforeRelativeTime.fromStruct(decode.value);

      default:
        throw DartStellarPlugingException("Invalid ClaimPredicate type.");
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be(
        List.generate(ClaimPredicateType.values.length, (index) {
          final type = ClaimPredicateType.values.elementAt(index);
          switch (type) {
            case ClaimPredicateType.unconditional:
              return LazyLayout(
                  layout: ClaimPredicateUnconditional.layout,
                  property: type.name);
            case ClaimPredicateType.and:
              return LazyLayout(
                  layout: ClaimPredicateAnd.layout, property: type.name);
            case ClaimPredicateType.or:
              return LazyLayout(
                  layout: ClaimPredicateOr.layout, property: type.name);
            case ClaimPredicateType.not:
              return LazyLayout(
                  layout: ClaimPredicateNot.layout, property: type.name);
            case ClaimPredicateType.beforeAbsoluteTime:
              return LazyLayout(
                  layout: ClaimPredicateBeforeAbsoluteTime.layout,
                  property: type.name);
            case ClaimPredicateType.beforeRelativeTime:
              return LazyLayout(
                  layout: ClaimPredicateBeforeRelativeTime.layout,
                  property: type.name);

            default:
              throw DartStellarPlugingException("Invalid ClaimPredicate type.");
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ClaimPredicateUnconditional extends ClaimPredicate {
  const ClaimPredicateUnconditional() : super(ClaimPredicateType.unconditional);
  factory ClaimPredicateUnconditional.fromStruct(Map<String, dynamic> json) {
    return ClaimPredicateUnconditional();
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class ClaimPredicateAnd extends ClaimPredicate {
  final List<ClaimPredicate> andPredicates;
  ClaimPredicateAnd(List<ClaimPredicate> value)
      : andPredicates = value.immutable.max(2, name: "ClaimPredicate"),
        super(ClaimPredicateType.and);
  factory ClaimPredicateAnd.fromStruct(Map<String, dynamic> json) {
    return ClaimPredicateAnd(json
        .asListOfMap("andPredicates")!
        .map((e) => ClaimPredicate.fromStruct(e))
        .toList());
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.xdrVec(ClaimPredicate.layout(), property: "andPredicates")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "andPredicates":
          andPredicates.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

class ClaimPredicateOr extends ClaimPredicate {
  final List<ClaimPredicate> orPredicates;
  ClaimPredicateOr(List<ClaimPredicate> orPredicates)
      : orPredicates = orPredicates.immutable.max(2, name: "ClaimPredicate"),
        super(ClaimPredicateType.or);
  factory ClaimPredicateOr.fromStruct(Map<String, dynamic> json) {
    return ClaimPredicateOr(json
        .asListOfMap("orPredicates")!
        .map((e) => ClaimPredicate.fromStruct(e))
        .toList());
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [LayoutConst.xdrVec(ClaimPredicate.layout(), property: "orPredicates")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "orPredicates":
          orPredicates.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

class ClaimPredicateNot extends ClaimPredicate {
  final ClaimPredicate? notPredicate;
  ClaimPredicateNot(this.notPredicate) : super(ClaimPredicateType.not);
  factory ClaimPredicateNot.fromStruct(Map<String, dynamic> json) {
    return ClaimPredicateNot(
      json.mybeAs<ClaimPredicate, Map<String, dynamic>>(
          key: "notPredicate", onValue: (e) => ClaimPredicate.fromStruct(e)),
    );
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.optionalU32Be(ClaimPredicate.layout(),
          property: "notPredicate")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"notPredicate": notPredicate?.toVariantLayoutStruct()};
  }
}

class ClaimPredicateBeforeAbsoluteTime extends ClaimPredicate {
  final BigInt absBefore;
  ClaimPredicateBeforeAbsoluteTime(BigInt absBefore)
      : absBefore = absBefore.asInt64,
        super(ClaimPredicateType.beforeAbsoluteTime);
  factory ClaimPredicateBeforeAbsoluteTime.fromStruct(
      Map<String, dynamic> json) {
    return ClaimPredicateBeforeAbsoluteTime(json.as("absBefore"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.s64be(property: "absBefore")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"absBefore": absBefore};
  }
}

class ClaimPredicateBeforeRelativeTime extends ClaimPredicate {
  final BigInt relBefore;
  ClaimPredicateBeforeRelativeTime(BigInt relBefore)
      : relBefore = relBefore.asInt64,
        super(ClaimPredicateType.beforeRelativeTime);
  factory ClaimPredicateBeforeRelativeTime.fromStruct(
      Map<String, dynamic> json) {
    return ClaimPredicateBeforeRelativeTime(json.as("relBefore"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.s64be(property: "relBefore")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"relBefore": relBefore};
  }
}

class ClaimableBalanceEntry extends LedgerEntryData {
  final ClaimableBalanceId balanceId;
  final List<Claimant> claimants;
  final StellarAsset asset;
  final BigInt amount;
  final ClaimableBalanceEntryExt ext;
  ClaimableBalanceEntry(
      {required this.balanceId,
      required List<Claimant> claimants,
      required this.asset,
      required BigInt amount,
      required this.ext})
      : claimants = claimants.immutable,
        amount = amount.asInt64,
        super(LedgerEntryType.claimableBalance);
}

class LiquidityPoolType {
  final int value;
  final String name;
  const LiquidityPoolType._({required this.value, required this.name});
  static const LiquidityPoolType liquidityPoolConstantProduct =
      LiquidityPoolType._(name: "liquidityPoolConstantProduct", value: 0);

  @override
  String toString() {
    return "LiquidityPoolType.$name";
  }
}

abstract class LiquidityPoolEntryBody {
  final LiquidityPoolType type;
  const LiquidityPoolEntryBody(this.type);
}

class LiquidityPoolConstantProductParameters {
  final StellarAsset assetA;
  final StellarAsset assetB;
  final int fee;
  LiquidityPoolConstantProductParameters(
      {required this.assetA, required this.assetB, required int fee})
      : fee = fee.asInt32;
}

class LiquidityPoolEntryConstantProduct extends LiquidityPoolEntryBody {
  final LiquidityPoolConstantProductParameters param;
  final BigInt reserveA;
  final BigInt reserveB;
  final BigInt totalPoolShares;
  final BigInt poolSharesTrustLineCount;
  LiquidityPoolEntryConstantProduct(
      {required this.param,
      required BigInt reserveA,
      required BigInt reserveB,
      required BigInt totalPoolShares,
      required BigInt poolSharesTrustLineCount})
      : reserveA = reserveA.asInt64,
        reserveB = reserveB.asInt64,
        totalPoolShares = totalPoolShares.asInt64,
        poolSharesTrustLineCount = poolSharesTrustLineCount.asInt64,
        super(LiquidityPoolType.liquidityPoolConstantProduct);
}

class LiquidityPoolEntry extends LedgerEntryData {
  final Hash256 liquidityPoolId;
  final LiquidityPoolEntryBody body;
  const LiquidityPoolEntry({required this.liquidityPoolId, required this.body})
      : super(LedgerEntryType.liquidityPool);
}

class ScAddressType {
  final String name;
  final int value;
  const ScAddressType._({required this.name, required this.value});
  static const ScAddressType account =
      ScAddressType._(name: "account", value: 0);
  static const ScAddressType contract =
      ScAddressType._(name: "contract", value: 1);
  static const List<ScAddressType> values = [account, contract];
  static ScAddressType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "ScAddress type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ScAddressType.$name";
  }
}

abstract class ScAddress extends XDRVariantSerialization<Map<String, dynamic>> {
  final ScAddressType type;
  const ScAddress(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      ScAddressAccountId.layout(property: ScAddressType.account.name),
      ScAddressContract.layout(property: ScAddressType.contract.name)
    ], property: property);
  }

  factory ScAddress.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = ScAddressType.fromName(decode.variantName);
    switch (type) {
      case ScAddressType.account:
        return ScAddressAccountId.fromStruct(decode.value);
      case ScAddressType.contract:
        return ScAddressContract.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid ScAddress type.",
            details: {"type": type.name});
    }
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ScAddressAccountId extends ScAddress {
  final StellarPublicKey accountId;
  const ScAddressAccountId(this.accountId) : super(ScAddressType.account);
  factory ScAddressAccountId.fromStruct(Map<String, dynamic> json) {
    return ScAddressAccountId(
        StellarPublicKey.fromStruct(json.asMap("accountId")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([StellarPublicKey.layout(property: "accountId")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"accountId": accountId.toLayoutStruct()};
  }
}

class ScAddressContract extends ScAddress {
  final List<int> contractId;
  ScAddressContract(List<int> contractId)
      : contractId =
            contractId.asImmutableBytes.exc(StellarConst.hash256Length),
        super(ScAddressType.contract);

  factory ScAddressContract.fromStruct(Map<String, dynamic> json) {
    return ScAddressContract(json.asBytes("contractId"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "contractId")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"contractId": contractId};
  }
}

class ScValueType {
  final String name;
  final int value;

  const ScValueType._({required this.name, required this.value});

  static const boolType = ScValueType._(name: 'Bool', value: 0);
  static const voidType = ScValueType._(name: 'Void', value: 1);
  static const error = ScValueType._(name: 'Error', value: 2);
  static const u32 = ScValueType._(name: 'U32', value: 3);
  static const i32 = ScValueType._(name: 'I32', value: 4);
  static const u64 = ScValueType._(name: 'U64', value: 5);
  static const i64 = ScValueType._(name: 'I64', value: 6);
  static const timepoint = ScValueType._(name: 'Timepoint', value: 7);
  static const duration = ScValueType._(name: 'Duration', value: 8);
  static const u128 = ScValueType._(name: 'U128', value: 9);
  static const i128 = ScValueType._(name: 'I128', value: 10);
  static const u256 = ScValueType._(name: 'U256', value: 11);
  static const i256 = ScValueType._(name: 'I256', value: 112);
  static const bytes = ScValueType._(name: 'Bytes', value: 13);
  static const string = ScValueType._(name: 'String', value: 14);
  static const symbol = ScValueType._(name: 'Symbol', value: 15);
  static const vec = ScValueType._(name: 'Vec', value: 16);
  static const map = ScValueType._(name: 'Map', value: 17);
  static const address = ScValueType._(name: 'Address', value: 18);
  static const contractInstance =
      ScValueType._(name: 'ContractInstance', value: 19);
  static const ledgerKeyContractInstance =
      ScValueType._(name: 'LedgerKeyContractInstance', value: 20);
  static const ledgerKeyNonce =
      ScValueType._(name: 'LedgerKeyNonce', value: 21);
  static const List<ScValueType> values = [
    boolType,
    voidType,
    error,
    u32,
    i32,
    u64,
    i64,
    timepoint,
    duration,
    u128,
    i128,
    u256,
    i256,
    bytes,
    string,
    symbol,
    vec,
    map,
    address,
    contractInstance,
    ledgerKeyContractInstance,
    ledgerKeyNonce
  ];
  static ScValueType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException("ScValue type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ScValueType.$name";
  }
}

abstract class ScVal<T> extends XDRVariantSerialization<Map<String, dynamic>> {
  final ScValueType type;
  final T value;
  const ScVal({required this.type, required this.value});
  factory ScVal.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = ScValueType.fromName(decode.variantName);
    final ScVal val;
    switch (type) {
      case ScValueType.boolType:
        val = ScValBoolean.fromStruct(decode.value);
        break;
      case ScValueType.voidType:
        val = ScValVoid.fromStruct(decode.value);
        break;
      case ScValueType.error:
        val = ScValError.fromStruct(decode.value);
        break;
      case ScValueType.u32:
        val = ScValU32.fromStruct(decode.value);
        break;
      case ScValueType.i32:
        val = ScValI32.fromStruct(decode.value);
        break;
      case ScValueType.u64:
        val = ScValU64.fromStruct(decode.value);
        break;
      case ScValueType.i64:
        val = ScValI64.fromStruct(decode.value);
        break;
      case ScValueType.timepoint:
        val = ScValTimePoint.fromStruct(decode.value);
        break;
      case ScValueType.duration:
        val = ScValDuration.fromStruct(decode.value);
        break;
      case ScValueType.u128:
        val = ScValU128.fromStruct(decode.value);
        break;
      case ScValueType.i128:
        val = ScValI128.fromStruct(decode.value);
        break;
      case ScValueType.u256:
        val = ScValU256.fromStruct(decode.value);
        break;
      case ScValueType.i256:
        val = ScValI256.fromStruct(decode.value);
        break;
      case ScValueType.bytes:
        val = ScValBytes.fromStruct(decode.value);
        break;
      case ScValueType.string:
        val = ScValString.fromStruct(decode.value);
        break;
      case ScValueType.symbol:
        val = ScValSymbol.fromStruct(decode.value);
        break;
      case ScValueType.vec:
        val = ScValVec.fromStruct(decode.value);
        break;
      case ScValueType.map:
        val = ScValMap.fromStruct(decode.value);
        break;
      case ScValueType.address:
        val = ScValAddress.fromStruct(decode.value);
        break;
      case ScValueType.contractInstance:
        val = ScValInstance.fromStruct(decode.value);
        break;
      case ScValueType.ledgerKeyContractInstance:
        val = ScValKeyContractInstance.fromStruct(decode.value);
        break;
      case ScValueType.ledgerKeyNonce:
        val = ScValNonceKey.fromStruct(decode.value);
        break;
      default:
        throw DartStellarPlugingException("Invalid ScVal type.");
    }

    if (val is! ScVal<T>) {
      throw DartStellarPlugingException("Incorrect SCval type casting.",
          details: {"excepted": "$T", "ScVal": val.runtimeType});
    }
    return val;
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be(
        List.generate(ScValueType.values.length, (index) {
          final type = ScValueType.values.elementAt(index);
          switch (type) {
            case ScValueType.boolType:
              return LazyLayout(
                  layout: ScValBoolean.layout, property: type.name);
            case ScValueType.voidType:
              return LazyLayout(layout: ScValVoid.layout, property: type.name);
            case ScValueType.error:
              return LazyLayout(layout: ScValError.layout, property: type.name);
            case ScValueType.u32:
              return LazyLayout(layout: ScValU32.layout, property: type.name);
            case ScValueType.i32:
              return LazyLayout(layout: ScValI32.layout, property: type.name);
            case ScValueType.u64:
              return LazyLayout(layout: ScValU64.layout, property: type.name);
            case ScValueType.i64:
              return LazyLayout(layout: ScValI64.layout, property: type.name);
            case ScValueType.timepoint:
              return LazyLayout(
                  layout: ScValTimePoint.layout, property: type.name);
            case ScValueType.duration:
              return LazyLayout(
                  layout: ScValDuration.layout, property: type.name);
            case ScValueType.u128:
              return LazyLayout(layout: ScValU128.layout, property: type.name);
            case ScValueType.i128:
              return LazyLayout(layout: ScValI128.layout, property: type.name);
            case ScValueType.u256:
              return LazyLayout(layout: ScValU256.layout, property: type.name);
            case ScValueType.i256:
              return LazyLayout(layout: ScValI256.layout, property: type.name);
            case ScValueType.bytes:
              return LazyLayout(layout: ScValBytes.layout, property: type.name);
            case ScValueType.string:
              return LazyLayout(
                  layout: ScValString.layout, property: type.name);
            case ScValueType.symbol:
              return LazyLayout(
                  layout: ScValSymbol.layout, property: type.name);
            case ScValueType.vec:
              return LazyLayout(layout: ScValVec.layout, property: type.name);
            case ScValueType.map:
              return LazyLayout(layout: ScValMap.layout, property: type.name);
            case ScValueType.address:
              return LazyLayout(
                  layout: ScValAddress.layout, property: type.name);
            case ScValueType.contractInstance:
              return LazyLayout(
                  layout: ScValInstance.layout, property: type.name);
            case ScValueType.ledgerKeyContractInstance:
              return LazyLayout(
                  layout: ScValKeyContractInstance.layout, property: type.name);
            case ScValueType.ledgerKeyNonce:
              return LazyLayout(
                  layout: ScValNonceKey.layout, property: type.name);
            default:
              throw DartStellarPlugingException("Invalid ScVal type.");
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ScErrorType {
  final String name;
  final int value;

  const ScErrorType._({required this.name, required this.value});

  static const contract = ScErrorType._(name: 'Contract', value: 0);
  static const wasmVm = ScErrorType._(name: 'WasmVm', value: 1);
  static const context = ScErrorType._(name: 'Context', value: 2);
  static const storage = ScErrorType._(name: 'Storage', value: 3);
  static const object = ScErrorType._(name: 'Object', value: 4);
  static const crypto = ScErrorType._(name: 'Crypto', value: 5);
  static const events = ScErrorType._(name: 'Events', value: 6);
  static const budget = ScErrorType._(name: 'Budget', value: 7);
  static const valueType = ScErrorType._(name: 'Value', value: 8);
  static const auth = ScErrorType._(name: 'Auth', value: 9);
  static const List<ScErrorType> values = [
    contract,
    wasmVm,
    context,
    storage,
    object,
    crypto,
    events,
    budget,
    valueType,
    auth
  ];
  static ScErrorType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException("ScError type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ScErrorType.$name";
  }
}

abstract class ScError extends XDRVariantSerialization<Map<String, dynamic>> {
  final ScErrorType type;
  const ScError(this.type);
  factory ScError.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = ScErrorType.fromName(decode.variantName);
    switch (type) {
      case ScErrorType.contract:
        return ScErrorContract.fromStruct(decode.value);
      default:
        return ScErrorCode(type);
    }
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be(
        List.generate(ScErrorType.values.length, (index) {
          final type = ScErrorType.values.elementAt(index);
          switch (type) {
            case ScErrorType.contract:
              return ScErrorContract.layout(property: type.name);
            default:
              return ScErrorCode.layout(property: type.name);
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  // @override
  // Layout<T> createLayout({String? property}) {
  //   return LayoutConst.none(property: property) as Layout<T>;
  // }

  @override
  String get variantName => type.name;
}

class ScErrorContract extends ScError {
  final int contractCode;
  ScErrorContract(int contractCode)
      : contractCode = contractCode.asUint32,
        super(ScErrorType.contract);
  factory ScErrorContract.fromStruct(Map<String, dynamic> json) {
    return ScErrorContract(json.as("contractCode"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u32be(property: "contractCode"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"contractCode": contractCode};
  }
}

class ScErrorCode extends ScError {
  ScErrorCode._(ScErrorType code) : super(code);
  factory ScErrorCode(ScErrorType code) {
    if (code == ScErrorType.contract) {
      throw DartStellarPlugingException(
          "Use `ScErrorContract` instead `ScErrorCode` for user-defined error code.");
    }
    return ScErrorCode._(code);
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class ScValBoolean extends ScVal<bool> {
  ScValBoolean(bool bool) : super(type: ScValueType.boolType, value: bool);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.boolean32Be(property: "value"),
    ], property: property);
  }

  factory ScValBoolean.fromStruct(Map<String, dynamic> json) {
    return ScValBoolean(json.as("value"));
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValError extends ScVal<ScError> {
  ScValError(ScError value) : super(type: ScValueType.error, value: value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ScError.layout(property: "value")],
        property: property);
  }

  factory ScValError.fromStruct(Map<String, dynamic> json) {
    return ScValError(ScError.fromStruct(json.asMap("value")));
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "value": value.toVariantLayoutStruct(),
    };
  }
}

class ScValU32 extends ScVal<int> {
  ScValU32(int value) : super(type: ScValueType.u32, value: value.asUint32);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u32be(property: "value"),
    ], property: property);
  }

  factory ScValU32.fromStruct(Map<String, dynamic> json) {
    return ScValU32(json.as("value"));
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValI32 extends ScVal<int> {
  ScValI32(int value) : super(type: ScValueType.i32, value: value.asInt32);
  factory ScValI32.fromStruct(Map<String, dynamic> json) {
    return ScValI32(json.as("value"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s32be(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValU64 extends ScVal<BigInt> {
  ScValU64(BigInt value) : super(type: ScValueType.u64, value: value.asUint64);
  factory ScValU64.fromStruct(Map<String, dynamic> json) {
    return ScValU64(json.as("value"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValI64 extends ScVal<BigInt> {
  ScValI64(BigInt value) : super(type: ScValueType.i64, value: value.asInt64);
  factory ScValI64.fromStruct(Map<String, dynamic> json) {
    return ScValI64(json.as("value"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s64be(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValTimePoint extends ScVal<BigInt> {
  ScValTimePoint(BigInt value)
      : super(type: ScValueType.timepoint, value: value.asUint64);
  factory ScValTimePoint.fromStruct(Map<String, dynamic> json) {
    return ScValTimePoint(json.as("value"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class UInt128Parts extends XDRSerialization<Map<String, dynamic>> {
  final BigInt hi;
  final BigInt lo;
  UInt128Parts({required BigInt hi, required BigInt lo})
      : hi = hi.asUint64,
        lo = lo.asUint64;
  factory UInt128Parts.fromStruct(Map<String, dynamic> json) {
    return UInt128Parts(hi: json.as("hi"), lo: json.as("lo"));
  }
  factory UInt128Parts.fromNumber(BigInt number) {
    if (number.isNegative || number.bitLength > 128) {
      if (number.isNegative) {
        throw DartStellarPlugingException("Invalid Unsigned int.",
            details: {"number": number.toString()});
      }
      throw DartStellarPlugingException("Number is to large for `Int256Parts`",
          details: {"number": number.toString()});
    }
    BigInt hi = (number >> 64).toUnsigned(64);
    BigInt lo = number.toUnsigned(64);
    return UInt128Parts(hi: hi, lo: lo);
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "hi"),
      LayoutConst.u64be(property: "lo"),
    ], property: property);
  }

  BigInt toBigInt() {
    BigInt part = (hi << 64);
    BigInt int256 = part | lo;
    return int256;
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hi": hi, "lo": lo};
  }
}

class Int128Parts extends XDRSerialization<Map<String, dynamic>> {
  final BigInt hi;
  final BigInt lo;
  Int128Parts({required BigInt hi, required BigInt lo})
      : hi = hi.asInt64,
        lo = lo.asUint64;
  factory Int128Parts.fromNumber(BigInt number) {
    if (number.bitLength > 128) {
      throw DartStellarPlugingException("Number is to large for `Int256Parts`",
          details: {"number": number.toString()});
    }
    BigInt hi = (number >> 64).toSigned(64);
    BigInt lo = number.toUnsigned(64);
    return Int128Parts(hi: hi, lo: lo);
  }
  factory Int128Parts.fromStruct(Map<String, dynamic> json) {
    return Int128Parts(hi: json.as("hi"), lo: json.as("lo"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s64be(property: "hi"),
      LayoutConst.u64be(property: "lo"),
    ], property: property);
  }

  BigInt toBigInt() {
    BigInt part = (hi << 64);
    BigInt int256 = part | lo;
    return int256;
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hi": hi, "lo": lo};
  }
}

class UInt256Parts extends XDRSerialization<Map<String, dynamic>> {
  final BigInt hiHi;
  final BigInt hiLo;
  final BigInt loHi;
  final BigInt loLo;
  UInt256Parts({
    required BigInt hiHi,
    required BigInt hiLo,
    required BigInt loHi,
    required BigInt loLo,
  })  : hiHi = hiHi.asUint64,
        hiLo = hiLo.asUint64,
        loHi = loHi.asUint64,
        loLo = loLo.asUint64;
  factory UInt256Parts.fromStruct(Map<String, dynamic> json) {
    return UInt256Parts(
      hiHi: json.as("hiHi"),
      hiLo: json.as("hiLo"),
      loHi: json.as("loHi"),
      loLo: json.as("loLo"),
    );
  }
  factory UInt256Parts.fromNumber(BigInt number) {
    if (number.isNegative || number.bitLength > 256) {
      if (number.isNegative) {
        throw DartStellarPlugingException("Invalid Unsigned int.",
            details: {"number": number.toString()});
      }
      throw DartStellarPlugingException("Number is to large for `Int256Parts`",
          details: {"number": number.toString()});
    }
    BigInt hiHi = (number >> 192).toUnsigned(64);
    BigInt hiLo = (number >> 128).toUnsigned(64);
    BigInt loHi = (number >> 64).toUnsigned(64);
    BigInt loLo = number.toUnsigned(64);
    return UInt256Parts(hiHi: hiHi, hiLo: hiLo, loHi: loHi, loLo: loLo);
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "hiHi"),
      LayoutConst.u64be(property: "hiLo"),
      LayoutConst.u64be(property: "loHi"),
      LayoutConst.u64be(property: "loLo"),
    ], property: property);
  }

  BigInt toBigInt() {
    BigInt part1 = (hiHi << 192);
    BigInt part2 = (hiLo << 128);
    BigInt part3 = (loHi << 64);
    BigInt part4 = loLo;
    BigInt int256 = part1 | part2 | part3 | part4;
    return int256;
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hiHi": hiHi, "hiLo": hiLo, "loHi": loHi, "loLo": loLo};
  }
}

class Int256Parts extends XDRSerialization<Map<String, dynamic>> {
  final BigInt hiHi;
  final BigInt hiLo;
  final BigInt loHi;
  final BigInt loLo;
  Int256Parts({
    required BigInt hiHi,
    required BigInt hiLo,
    required BigInt loHi,
    required BigInt loLo,
  })  : hiHi = hiHi.asInt64,
        hiLo = hiLo.asUint64,
        loHi = loHi.asUint64,
        loLo = loLo.asUint64;
  factory Int256Parts.fromStruct(Map<String, dynamic> json) {
    return Int256Parts(
      hiHi: json.as("hiHi"),
      hiLo: json.as("hiLo"),
      loHi: json.as("loHi"),
      loLo: json.as("loLo"),
    );
  }
  factory Int256Parts.fromNumber(BigInt number) {
    if (number.bitLength > 256) {
      throw DartStellarPlugingException("Number is to large for `Int256Parts`");
    }
    BigInt hiHi = (number >> 192).toSigned(64);
    BigInt hiLo = (number >> 128).toUnsigned(64);
    BigInt loHi = (number >> 64).toUnsigned(64);
    BigInt loLo = number.toUnsigned(64);
    return Int256Parts(hiHi: hiHi, hiLo: hiLo, loHi: loHi, loLo: loLo);
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s64be(property: "hiHi"),
      LayoutConst.u64be(property: "hiLo"),
      LayoutConst.u64be(property: "loHi"),
      LayoutConst.u64be(property: "loLo"),
    ], property: property);
  }

  BigInt toBigInt() {
    BigInt part1 = (hiHi << 192);
    BigInt part2 = (hiLo << 128);
    BigInt part3 = (loHi << 64);
    BigInt part4 = loLo;
    BigInt int256 = part1 | part2 | part3 | part4;
    return int256;
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hiHi": hiHi, "hiLo": hiLo, "loHi": loHi, "loLo": loLo};
  }
}

class ScValDuration extends ScVal<BigInt> {
  ScValDuration(BigInt value)
      : super(type: ScValueType.duration, value: value.asUint64);
  factory ScValDuration.fromStruct(Map<String, dynamic> json) {
    return ScValDuration(json.as("value"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.u64be(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValU128 extends ScVal<UInt128Parts> {
  ScValU128(UInt128Parts value) : super(type: ScValueType.u128, value: value);
  factory ScValU128.fromStruct(Map<String, dynamic> json) {
    return ScValU128(UInt128Parts.fromStruct(json.asMap("value")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([UInt128Parts.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValI128 extends ScVal<Int128Parts> {
  ScValI128(Int128Parts value) : super(type: ScValueType.i128, value: value);
  factory ScValI128.fromStruct(Map<String, dynamic> json) {
    return ScValI128(Int128Parts.fromStruct(json.asMap("value")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([Int128Parts.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValU256 extends ScVal<UInt256Parts> {
  ScValU256(UInt256Parts value) : super(type: ScValueType.u256, value: value);
  factory ScValU256.fromStruct(Map<String, dynamic> json) {
    return ScValU256(UInt256Parts.fromStruct(json.asMap("value")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([UInt256Parts.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValI256 extends ScVal<Int256Parts> {
  ScValI256(Int256Parts value) : super(type: ScValueType.i256, value: value);
  factory ScValI256.fromStruct(Map<String, dynamic> json) {
    return ScValI256(Int256Parts.fromStruct(json.asMap("value")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([Int256Parts.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValBytes extends ScVal<List<int>> {
  ScValBytes(List<int> bytes)
      : super(type: ScValueType.bytes, value: bytes.asImmutableBytes);
  factory ScValBytes.fromStruct(Map<String, dynamic> json) {
    return ScValBytes(json.asBytes("value"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.xdrVecBytes(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValString extends ScVal<String> {
  ScValString(String str) : super(type: ScValueType.string, value: str);
  factory ScValString.fromStruct(Map<String, dynamic> json) {
    return ScValString(json.as("value"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.xdrString(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValSymbol extends ScVal<String> {
  ScValSymbol(String sym) : super(type: ScValueType.symbol, value: sym.max(32));
  factory ScValSymbol.fromStruct(Map<String, dynamic> json) {
    return ScValSymbol(json.as("value"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.xdrString(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScMapEntry<K extends ScVal, V extends ScVal>
    extends XDRSerialization<Map<String, dynamic>> {
  final K key;
  final V value;
  const ScMapEntry(this.key, this.value);
  factory ScMapEntry.fromStruct(Map<String, dynamic> json) {
    return ScMapEntry(ScVal.fromStruct(json.asMap("key")) as K,
        ScVal.fromStruct(json.asMap("value")) as V);
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScVal.layout(property: "key"),
      ScVal.layout(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "key": key.toVariantLayoutStruct(),
      "value": value.toVariantLayoutStruct()
    };
  }
}

class ScNonceKey extends XDRSerialization<Map<String, dynamic>> {
  final BigInt nonce;
  ScNonceKey(BigInt nonce) : nonce = nonce.asInt64;
  factory ScNonceKey.fromStruct(Map<String, dynamic> json) {
    return ScNonceKey(json.as("nonce"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.s64be(property: "nonce")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"nonce": nonce};
  }
}

class ScValVec extends ScVal<List<ScVal>?> {
  ScValVec({List<ScVal>? value})
      : super(type: ScValueType.vec, value: value?.immutable);
  factory ScValVec.fromStruct(Map<String, dynamic> json) {
    return ScValVec(
        value: json
            .asListOfMap("value", throwOnNull: false)
            ?.map((e) => ScVal.fromStruct(e))
            .toList());
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.optionalU32Be(LayoutConst.xdrVec(ScVal.layout()),
          property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "value": value?.map((e) => e.toVariantLayoutStruct()).toList() ?? const []
    };
  }
}

class ScValMap extends ScVal<List<ScMapEntry>?> {
  ScValMap({List<ScMapEntry>? value})
      : super(type: ScValueType.map, value: value?.immutable);
  factory ScValMap.fromStruct(Map<String, dynamic> json) {
    return ScValMap(
        value: json
            .asListOfMap("value", throwOnNull: false)
            ?.map((e) => ScMapEntry.fromStruct(e))
            .toList());
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.optionalU32Be(LayoutConst.xdrVec(ScMapEntry.layout()),
          property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "value": value?.map((e) => e.toLayoutStruct()).toList() ?? const [],
    };
  }
}

class ScValAddress extends ScVal<ScAddress> {
  ScValAddress(ScAddress value)
      : super(type: ScValueType.address, value: value);
  factory ScValAddress.fromStruct(Map<String, dynamic> json) {
    return ScValAddress(ScAddress.fromStruct(json.asMap("value")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ScAddress.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toVariantLayoutStruct()};
  }
}

class ScValNonceKey extends ScVal<ScNonceKey> {
  ScValNonceKey(ScNonceKey value)
      : super(type: ScValueType.ledgerKeyNonce, value: value);
  factory ScValNonceKey.fromStruct(Map<String, dynamic> json) {
    return ScValNonceKey(ScNonceKey.fromStruct(json.asMap("value")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ScNonceKey.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValInstance extends ScVal<ScContractInstance> {
  ScValInstance(ScContractInstance value)
      : super(type: ScValueType.contractInstance, value: value);

  factory ScValInstance.fromStruct(Map<String, dynamic> json) {
    return ScValInstance(ScContractInstance.fromStruct(json.asMap("value")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ScContractInstance.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValVoid extends ScVal<Null> {
  ScValVoid() : super(type: ScValueType.voidType, value: null);
  factory ScValVoid.fromStruct(Map<String, dynamic> json) {
    return ScValVoid();
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class ScValKeyContractInstance extends ScVal<Null> {
  ScValKeyContractInstance()
      : super(type: ScValueType.ledgerKeyContractInstance, value: null);
  factory ScValKeyContractInstance.fromStruct(Map<String, dynamic> json) {
    return ScValKeyContractInstance();
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class ContractExecutableType {
  final String name;
  final int value;
  const ContractExecutableType._({required this.name, required this.value});
  static const ContractExecutableType executableWasm =
      ContractExecutableType._(name: "ExecutableWasm", value: 0);
  static const ContractExecutableType executableStellarAsset =
      ContractExecutableType._(name: "ExecutableStellarAsset", value: 1);
  static const List<ContractExecutableType> values = [
    executableWasm,
    executableStellarAsset
  ];
  static ContractExecutableType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "ContractExecutable type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ContractExecutableType.$name";
  }
}

abstract class ContractExecutable
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final ContractExecutableType type;
  const ContractExecutable(this.type);
  factory ContractExecutable.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = ContractExecutableType.fromName(decode.variantName);
    switch (type) {
      case ContractExecutableType.executableStellarAsset:
        return ContractExecutableStellarAsset.fromStruct(decode.value);
      case ContractExecutableType.executableWasm:
        return ContractExecutableWasmHash.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid ContractExecutable type.");
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      ContractExecutableWasmHash.layout(
          property: ContractExecutableType.executableWasm.name),
      ContractExecutableStellarAsset.layout(
          property: ContractExecutableType.executableStellarAsset.name)
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ContractExecutableWasmHash extends ContractExecutable {
  final List<int> hash;
  ContractExecutableWasmHash(List<int> hash)
      : hash = hash.asImmutableBytes.exc(StellarConst.hash256Length),
        super(ContractExecutableType.executableWasm);
  factory ContractExecutableWasmHash.fromStruct(Map<String, dynamic> json) {
    return ContractExecutableWasmHash(json.asBytes("hash"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "hash"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hash": hash};
  }
}

class ContractExecutableStellarAsset extends ContractExecutable {
  ContractExecutableStellarAsset()
      : super(ContractExecutableType.executableStellarAsset);
  factory ContractExecutableStellarAsset.fromStruct(Map<String, dynamic> json) {
    return ContractExecutableStellarAsset();
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class ScContractInstance extends XDRSerialization<Map<String, dynamic>> {
  final ContractExecutable executable;
  final List<ScMapEntry>? storage;
  ScContractInstance({required this.executable, List<ScMapEntry>? storage})
      : storage = storage?.immutable;
  factory ScContractInstance.fromStruct(Map<String, dynamic> json) {
    return ScContractInstance(
        executable: ContractExecutable.fromStruct(json.asMap("executable")),
        storage: json
            .asListOfMap("storage", throwOnNull: false)
            ?.map((e) => ScMapEntry.fromStruct(e))
            .toList());
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ContractExecutable.layout(property: "executable"),
      LayoutConst.optionalU32Be(LayoutConst.xdrVec(ScMapEntry.layout()),
          property: "storage"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "executable": executable.toVariantLayoutStruct(),
      "storage": storage?.map((e) => e.toLayoutStruct()).toList(),
    };
  }
}

class ContractDataDurability {
  final String name;
  final int value;
  const ContractDataDurability._({required this.name, required this.value});
  static const ContractDataDurability temporary =
      ContractDataDurability._(name: "temporary", value: 0);
  static const ContractDataDurability persistent =
      ContractDataDurability._(name: "persistent", value: 1);
  static const List<ContractDataDurability> values = [temporary, persistent];
  static ContractDataDurability fromValue(int? value) {
    return values.firstWhere(
      (e) => e.value == value,
      orElse: () => throw DartStellarPlugingException(
          "ContractDataDurability not found.",
          details: {
            "value": value,
            "values": values.map((e) => e.value).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ContractDataDurability.$name";
  }
}

class ContractDataEntry extends LedgerEntryData {
  final ScAddress contract;
  final ScVal key;
  final ContractDataDurability durability;
  final ScVal val;
  const ContractDataEntry(
      {required this.contract,
      required this.key,
      required this.durability,
      required this.val})
      : super(LedgerEntryType.contractData);
}

class ContractCodeCostInputs {
  final int nInstructions;
  final int nFunctions;
  final int nGlobals;
  final int nTableEntries;
  final int nTypes;
  final int nDataSegments;
  final int nElemSegments;
  final int nImports;
  final int nExports;
  final int nDataSegmentBytes;
  ContractCodeCostInputs({
    required int nInstructions,
    required int nFunctions,
    required int nGlobals,
    required int nTableEntries,
    required int nTypes,
    required int nDataSegments,
    required int nElemSegments,
    required int nImports,
    required int nExports,
    required int nDataSegmentBytes,
  })  : nInstructions = nInstructions.asUint32,
        nFunctions = nFunctions.asUint32,
        nGlobals = nGlobals.asUint32,
        nTableEntries = nTableEntries.asUint32,
        nTypes = nTypes.asUint32,
        nDataSegments = nDataSegments.asUint32,
        nElemSegments = nElemSegments.asUint32,
        nImports = nImports.asUint32,
        nExports = nExports.asUint32,
        nDataSegmentBytes = nDataSegmentBytes.asUint32;
}

class ContractCodeEntryV1 {
  final ContractCodeCostInputs costInputs;
  const ContractCodeEntryV1({required this.costInputs});
}
// class ContractCodeEntryExt {
//   switch(): number;

//   v1(value?: ContractCodeEntryV1): ContractCodeEntryV1;

//   static 0(): ContractCodeEntryExt;

//   static 1(value: ContractCodeEntryV1): ContractCodeEntryExt;
class ContractCodeEntryExt extends ExtPoint {
  final ContractCodeEntryV1? ext;
  const ContractCodeEntryExt(this.ext);

  @override
  int get value => ext == null ? 0 : 1;
}

class ContractCodeEntry extends LedgerEntryData {
  final ContractCodeEntryExt ext;
  final List<int> hash;
  final List<int> code;
  ContractCodeEntry(
      {required this.ext, required List<int> hash, required List<int> code})
      : code = code.asImmutableBytes,
        hash = hash.asImmutableBytes,
        super(LedgerEntryType.contractCode);
}

class ConfigSettingId {
  final String name;
  final int value;

  const ConfigSettingId._({required this.name, required this.value});

  static const contractMaxSizeBytes =
      ConfigSettingId._(name: 'ContractMaxSizeBytes', value: 0);
  static const contractComputeV0 =
      ConfigSettingId._(name: 'ContractComputeV0', value: 1);
  static const contractLedgerCostV0 =
      ConfigSettingId._(name: 'ContractLedgerCostV0', value: 2);
  static const contractHistoricalDataV0 =
      ConfigSettingId._(name: 'ContractHistoricalDataV0', value: 3);
  static const contractEventsV0 =
      ConfigSettingId._(name: 'ContractEventsV0', value: 4);
  static const contractBandwidthV0 =
      ConfigSettingId._(name: 'ContractBandwidthV0', value: 5);
  static const contractCostParamsCpuInstructions =
      ConfigSettingId._(name: 'ContractCostParamsCpuInstructions', value: 6);
  static const contractCostParamsMemoryBytes =
      ConfigSettingId._(name: 'ContractCostParamsMemoryBytes', value: 7);
  static const contractDataKeySizeBytes =
      ConfigSettingId._(name: 'ContractDataKeySizeBytes', value: 8);
  static const contractDataEntrySizeBytes =
      ConfigSettingId._(name: 'ContractDataEntrySizeBytes', value: 9);
  static const stateArchival =
      ConfigSettingId._(name: 'StateArchival', value: 10);
  static const contractExecutionLanes =
      ConfigSettingId._(name: 'ContractExecutionLanes', value: 11);
  static const bucketlistSizeWindow =
      ConfigSettingId._(name: 'BucketlistSizeWindow', value: 12);
  static const evictionIterator =
      ConfigSettingId._(name: 'EvictionIterator', value: 13);
  static const List<ConfigSettingId> values = [
    contractMaxSizeBytes,
    contractComputeV0,
    contractLedgerCostV0,
    contractHistoricalDataV0,
    contractEventsV0,
    contractBandwidthV0,
    contractCostParamsCpuInstructions,
    contractCostParamsMemoryBytes,
    contractDataKeySizeBytes,
    contractDataEntrySizeBytes,
    stateArchival,
    contractExecutionLanes,
    bucketlistSizeWindow,
    evictionIterator
  ];
  static ConfigSettingId fromValue(int? value) {
    return values.firstWhere(
      (e) => e.value == value,
      orElse: () => throw DartStellarPlugingException(
          "ConfigSettingId not found.",
          details: {
            "value": value,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ConfigSettingId.$name";
  }
}

abstract class ConfigSettingEntry extends LedgerEntryData {
  final ConfigSettingId settingId;
  const ConfigSettingEntry(this.settingId)
      : super(LedgerEntryType.configSetting);
}

class ConfigSettingContractComputeV0 extends ConfigSettingEntry {
  final BigInt ledgerMaxInstructions;
  final BigInt txMaxInstructions;
  final BigInt feeRatePerInstructionsIncrement;
  final int txMemoryLimit;
  ConfigSettingContractComputeV0({
    required BigInt ledgerMaxInstructions,
    required BigInt txMaxInstructions,
    required BigInt feeRatePerInstructionsIncrement,
    required int txMemoryLimit,
  })  : ledgerMaxInstructions = ledgerMaxInstructions.asInt64,
        txMaxInstructions = txMaxInstructions.asInt64,
        feeRatePerInstructionsIncrement =
            feeRatePerInstructionsIncrement.asInt64,
        txMemoryLimit = txMemoryLimit.asUint32,
        super(ConfigSettingId.contractComputeV0);
}

class ConfigSettingContractLedgerCostV0 extends ConfigSettingEntry {
  final int ledgerMaxReadLedgerEntries;
  final int ledgerMaxReadBytes;
  final int ledgerMaxWriteLedgerEntries;
  final int ledgerMaxWriteBytes;
  final int txMaxReadLedgerEntries;
  final int txMaxReadBytes;
  final int txMaxWriteLedgerEntries;
  final int txMaxWriteBytes;
  final BigInt feeReadLedgerEntry;
  final BigInt feeWriteLedgerEntry;
  final BigInt feeRead1Kb;
  final BigInt bucketListTargetSizeBytes;
  final BigInt writeFee1KbBucketListLow;
  final BigInt writeFee1KbBucketListHigh;
  final int bucketListWriteFeeGrowthFactor;
  ConfigSettingContractLedgerCostV0({
    required int ledgerMaxReadLedgerEntries,
    required int ledgerMaxReadBytes,
    required int ledgerMaxWriteLedgerEntries,
    required int ledgerMaxWriteBytes,
    required int txMaxReadLedgerEntries,
    required int txMaxReadBytes,
    required int txMaxWriteLedgerEntries,
    required int txMaxWriteBytes,
    required BigInt feeReadLedgerEntry,
    required BigInt feeWriteLedgerEntry,
    required BigInt feeRead1Kb,
    required BigInt bucketListTargetSizeBytes,
    required BigInt writeFee1KbBucketListLow,
    required BigInt writeFee1KbBucketListHigh,
    required int bucketListWriteFeeGrowthFactor,
  })  : ledgerMaxReadLedgerEntries = ledgerMaxReadLedgerEntries.asUint32,
        ledgerMaxReadBytes = ledgerMaxReadBytes.asUint32,
        ledgerMaxWriteLedgerEntries = ledgerMaxWriteLedgerEntries.asUint32,
        ledgerMaxWriteBytes = ledgerMaxWriteBytes.asUint32,
        txMaxReadLedgerEntries = txMaxReadLedgerEntries.asUint32,
        txMaxReadBytes = txMaxReadBytes.asUint32,
        txMaxWriteLedgerEntries = txMaxWriteLedgerEntries.asUint32,
        txMaxWriteBytes = txMaxWriteBytes.asUint32,
        feeReadLedgerEntry = feeReadLedgerEntry.asInt64,
        feeWriteLedgerEntry = feeWriteLedgerEntry.asInt64,
        feeRead1Kb = feeRead1Kb.asInt64,
        bucketListTargetSizeBytes = bucketListTargetSizeBytes.asInt64,
        writeFee1KbBucketListLow = writeFee1KbBucketListLow.asInt64,
        writeFee1KbBucketListHigh = writeFee1KbBucketListHigh.asInt64,
        bucketListWriteFeeGrowthFactor =
            bucketListWriteFeeGrowthFactor.asUint32,
        super(ConfigSettingId.contractLedgerCostV0);
}

class ConfigSettingContractHistoricalDataV0 extends ConfigSettingEntry {
  final BigInt feeHistorical1Kb;
  ConfigSettingContractHistoricalDataV0(BigInt feeHistorical1Kb)
      : feeHistorical1Kb = feeHistorical1Kb.asInt64,
        super(ConfigSettingId.contractHistoricalDataV0);
}

class ConfigSettingContractEventsV0 extends ConfigSettingEntry {
  final int txMaxContractEventsSizeBytes;
  final BigInt feeContractEvents1Kb;
  ConfigSettingContractEventsV0(
      {required int txMaxContractEventsSizeBytes,
      required BigInt feeContractEvents1Kb})
      : txMaxContractEventsSizeBytes = txMaxContractEventsSizeBytes.asUint32,
        feeContractEvents1Kb = feeContractEvents1Kb.asInt64,
        super(ConfigSettingId.contractEventsV0);
}

class ConfigSettingContractBandwidthV0 extends ConfigSettingEntry {
  final int ledgerMaxTxsSizeBytes;
  final int txMaxSizeBytes;
  final BigInt feeTxSize1Kb;
  ConfigSettingContractBandwidthV0(
      {required int ledgerMaxTxsSizeBytes,
      required int txMaxSizeBytes,
      required BigInt feeTxSize1Kb})
      : ledgerMaxTxsSizeBytes = ledgerMaxTxsSizeBytes.asUint32,
        txMaxSizeBytes = txMaxSizeBytes.asUint32,
        feeTxSize1Kb = feeTxSize1Kb.asInt64,
        super(ConfigSettingId.contractBandwidthV0);
}

class ContractCostParamEntry {
  final BigInt constTerm;
  final BigInt linearTerm;
  ContractCostParamEntry(
      {required BigInt constTerm, required BigInt linearTerm})
      : constTerm = constTerm.asInt64,
        linearTerm = linearTerm.asInt64;
}

class ConfingSettingContractCostParamsCpuInstructions
    extends ConfigSettingEntry {
  final List<ContractCostParamEntry> params;
  ConfingSettingContractCostParamsCpuInstructions(
      List<ContractCostParamEntry> params)
      : params = params.immutable,
        super(ConfigSettingId.contractCostParamsCpuInstructions);
}

class ConfingSettingContractCostParamsMemoryBytes extends ConfigSettingEntry {
  final List<ContractCostParamEntry> params;
  ConfingSettingContractCostParamsMemoryBytes(
      List<ContractCostParamEntry> params)
      : params = params.immutable,
        super(ConfigSettingId.contractCostParamsMemoryBytes);
}

class ConfingSettingContractDataKeySizeBytes extends ConfigSettingEntry {
  final int contractDataKeySizeBytes;
  ConfingSettingContractDataKeySizeBytes(int contractDataKeySizeBytes)
      : contractDataKeySizeBytes = contractDataKeySizeBytes.asUint32,
        super(ConfigSettingId.contractDataKeySizeBytes);
}

class ConfingSettingContractDataEnterySizeBytes extends ConfigSettingEntry {
  final int contractDataEnterySizeBytes;
  ConfingSettingContractDataEnterySizeBytes(int contractDataEnterySizeBytes)
      : contractDataEnterySizeBytes = contractDataEnterySizeBytes.asUint32,
        super(ConfigSettingId.contractDataEntrySizeBytes);
}

class StateArchivalSettings {
  final int maxEntryTtl;
  final int minTemporaryTtl;
  final int minPersistentTtl;
  final BigInt persistentRentRateDenominator;
  final BigInt tempRentRateDenominator;
  final int maxEntriesToArchive;
  final int bucketListSizeWindowSampleSize;
  final int bucketListWindowSamplePeriod;
  final int evictionScanSize;
  final int startingEvictionScanLevel;
  StateArchivalSettings({
    required int maxEntryTtl,
    required int minTemporaryTtl,
    required int minPersistentTtl,
    required BigInt persistentRentRateDenominator,
    required BigInt tempRentRateDenominator,
    required int maxEntriesToArchive,
    required int bucketListSizeWindowSampleSize,
    required int bucketListWindowSamplePeriod,
    required int evictionScanSize,
    required int startingEvictionScanLevel,
  })  : maxEntryTtl = maxEntryTtl.asUint32,
        minTemporaryTtl = minTemporaryTtl.asUint32,
        minPersistentTtl = minPersistentTtl.asUint32,
        persistentRentRateDenominator = persistentRentRateDenominator.asInt64,
        tempRentRateDenominator = tempRentRateDenominator.asInt64,
        maxEntriesToArchive = maxEntriesToArchive.asUint32,
        bucketListSizeWindowSampleSize =
            bucketListSizeWindowSampleSize.asUint32,
        bucketListWindowSamplePeriod = bucketListWindowSamplePeriod.asUint32,
        evictionScanSize = evictionScanSize.asUint32,
        startingEvictionScanLevel = startingEvictionScanLevel.asUint32;
}

class ConfigSettingContractStateArchivalSettings extends ConfigSettingEntry {
  final StateArchivalSettings settings;
  ConfigSettingContractStateArchivalSettings(this.settings)
      : super(ConfigSettingId.stateArchival);
}

class ConfigSettingContractExecutionLanesV0 extends ConfigSettingEntry {
  final int ledgerMaxTxCount;
  ConfigSettingContractExecutionLanesV0(int ledgerMaxTxCount)
      : ledgerMaxTxCount = ledgerMaxTxCount.asUint32,
        super(ConfigSettingId.contractExecutionLanes);
}

class ConfigSettingBucketlistSizeWindow extends ConfigSettingEntry {
  ConfigSettingBucketlistSizeWindow(List<BigInt> value)
      : value = value.map((e) => e.asUint64).toList().immutable,
        super(ConfigSettingId.bucketlistSizeWindow);
  final List<BigInt> value;
}

class EvictionIterator {
  final int bucketListLevel;
  final bool isCurrBucket;
  final BigInt bucketFileOffset;
  EvictionIterator(
      {required int bucketListLevel,
      required this.isCurrBucket,
      required BigInt bucketFileOffset})
      : bucketListLevel = bucketListLevel.asUint32,
        bucketFileOffset = bucketFileOffset.asUint64;
}

class ConfigSettingEvictionIterator extends ConfigSettingEntry {
  final EvictionIterator evictionIterator;
  ConfigSettingEvictionIterator(this.evictionIterator)
      : super(ConfigSettingId.evictionIterator);
}

class TtlEntry extends LedgerEntryData {
  final Hash256 keyHash;
  final int liveUntilLedgerSeq;
  TtlEntry({required this.keyHash, required int liveUntilLedgerSeq})
      : liveUntilLedgerSeq = liveUntilLedgerSeq.asUint32,
        super(LedgerEntryType.ttl);
}

class LedgerEntryExtensionV1Ext extends ExtPoint {
  @override
  int get value => 0;
}

class LedgerEntryExtensionV1 {
  final LedgerEntryExtensionV1Ext ext;
  final StellarBaseAddress? sponsoringId;
  LedgerEntryExtensionV1({required this.ext, this.sponsoringId});
}

class LedgerEntryExt extends ExtPoint {
  final LedgerEntryExtensionV1? ext;
  LedgerEntryExt(this.ext);

  @override
  int get value => ext == null ? 0 : 1;
}

class LedgerEntry {
  final int lastModifiedLedgerSeq;
  final LedgerEntryData data;
  final LedgerEntryExt ext;
  LedgerEntry(
      {required int lastModifiedLedgerSeq,
      required this.data,
      required this.ext})
      : lastModifiedLedgerSeq = lastModifiedLedgerSeq.asUint32;
}

abstract class LedgerKey extends XDRVariantSerialization<Map<String, dynamic>> {
  final LedgerEntryType type;
  const LedgerKey(this.type);
  factory LedgerKey.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = LedgerEntryType.fromName(decode.variantName);
    switch (type) {
      case LedgerEntryType.account:
        return LedgerKeyAccount.fromStruct(decode.value);
      case LedgerEntryType.trustline:
        return LedgerKeyTrustLine.fromStruct(decode.value);

      case LedgerEntryType.offer:
        return LedgerKeyOffer.fromStruct(decode.value);
      case LedgerEntryType.data:
        return LedgerKeyData.fromStruct(decode.value);
      case LedgerEntryType.claimableBalance:
        return LedgerKeyClaimableBalance.fromStruct(decode.value);

      case LedgerEntryType.liquidityPool:
        return LedgerKeyLiquidityPool.fromStruct(decode.value);

      case LedgerEntryType.contractData:
        return LedgerKeyContractData.fromStruct(decode.value);

      case LedgerEntryType.contractCode:
        return LedgerKeyContractCode.fromStruct(decode.value);

      case LedgerEntryType.configSetting:
        return LedgerKeyConfigSetting.fromStruct(decode.value);
      case LedgerEntryType.ttl:
        return LedgerKeyTtl.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid LedgerEntry type.");
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be(
        List.generate(LedgerEntryType.values.length, (index) {
          final type = LedgerEntryType.values.elementAt(index);
          switch (type) {
            case LedgerEntryType.account:
              return LazyLayout(
                  layout: LedgerKeyAccount.layout, property: type.name);
            case LedgerEntryType.trustline:
              return LazyLayout(
                  layout: LedgerKeyTrustLine.layout, property: type.name);
            case LedgerEntryType.offer:
              return LazyLayout(
                  layout: LedgerKeyOffer.layout, property: type.name);
            case LedgerEntryType.data:
              return LazyLayout(
                  layout: LedgerKeyData.layout, property: type.name);
            case LedgerEntryType.claimableBalance:
              return LazyLayout(
                  layout: LedgerKeyClaimableBalance.layout,
                  property: type.name);
            case LedgerEntryType.liquidityPool:
              return LazyLayout(
                  layout: LedgerKeyLiquidityPool.layout, property: type.name);
            case LedgerEntryType.contractData:
              return LazyLayout(
                  layout: LedgerKeyContractData.layout, property: type.name);
            case LedgerEntryType.contractCode:
              return LazyLayout(
                  layout: LedgerKeyContractCode.layout, property: type.name);
            case LedgerEntryType.configSetting:
              return LazyLayout(
                  layout: LedgerKeyConfigSetting.layout, property: type.name);
            case LedgerEntryType.ttl:
              return LazyLayout(
                  layout: LedgerKeyTtl.layout, property: type.name);
            default:
              throw DartStellarPlugingException("Invalid LedgerEntry type.");
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class LedgerKeyAccount extends LedgerKey {
  final StellarPublicKey accountId;
  const LedgerKeyAccount(this.accountId) : super(LedgerEntryType.account);
  factory LedgerKeyAccount.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyAccount(json.asMap("accountId"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"accountId": accountId.toLayoutStruct()};
  }
}

class LedgerKeyTrustLine extends LedgerKey {
  final StellarPublicKey accountId;
  final TrustLineAsset asset;
  const LedgerKeyTrustLine({required this.accountId, required this.asset})
      : super(LedgerEntryType.trustline);
  factory LedgerKeyTrustLine.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyTrustLine(
        accountId: json.asMap("accountId"),
        asset: TrustLineAsset.fromStruct(json.asMap("asset")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
      TrustLineAsset.layout(property: "asset")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "accountId": accountId.toLayoutStruct(),
      "asset": asset.toVariantLayoutStruct()
    };
  }
}

class LedgerKeyOffer extends LedgerKey {
  final StellarPublicKey accountId;
  final BigInt offerId;
  LedgerKeyOffer({required this.accountId, required BigInt offerId})
      : offerId = offerId.asInt64,
        super(LedgerEntryType.offer);
  factory LedgerKeyOffer.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyOffer(
        accountId: json.asMap("accountId"), offerId: json.as("offerId"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
      LayoutConst.s64be(property: "offerId")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"accountId": accountId.toLayoutStruct(), "offerId": offerId};
  }
}

class LedgerKeyData extends LedgerKey {
  final StellarPublicKey accountId;
  final String dataName;
  LedgerKeyData({required this.accountId, required String dataName})
      : dataName = dataName.max(64),
        super(LedgerEntryType.data);
  factory LedgerKeyData.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyData(
        accountId: json.asMap("accountId"), dataName: json.as("dataName"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
      LayoutConst.xdrString(property: "dataName")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"accountId": accountId.toLayoutStruct(), "dataName": dataName};
  }
}

class LedgerKeyClaimableBalance extends LedgerKey {
  final ClaimableBalanceId balanceId;
  const LedgerKeyClaimableBalance(this.balanceId)
      : super(LedgerEntryType.claimableBalance);
  factory LedgerKeyClaimableBalance.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyClaimableBalance(
        ClaimableBalanceId.fromStruct(json.asMap("balanceId")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [ClaimableBalanceId.layout(property: "balanceId")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "balanceId": balanceId.toVariantLayoutStruct(),
    };
  }
}

class LedgerKeyLiquidityPool extends LedgerKey {
  final List<int> liquidityPoolId;
  LedgerKeyLiquidityPool(List<int> liquidityPoolId)
      : liquidityPoolId =
            liquidityPoolId.asImmutableBytes.exc(StellarConst.hash256Length),
        super(LedgerEntryType.liquidityPool);
  factory LedgerKeyLiquidityPool.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyLiquidityPool(json.asBytes("liquidityPoolId"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length,
          property: "liquidityPoolId")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"liquidityPoolId": liquidityPoolId};
  }
}

class LedgerKeyContractData extends LedgerKey {
  final ScAddress contract;
  final ScVal key;
  final ContractDataDurability durability;
  const LedgerKeyContractData(
      {required this.contract, required this.key, required this.durability})
      : super(LedgerEntryType.contractData);
  factory LedgerKeyContractData.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyContractData(
        contract: ScAddress.fromStruct(json.asMap("contract")),
        durability: ContractDataDurability.fromValue(json.as("durability")),
        key: ScVal.fromStruct(json.asMap("key")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScAddress.layout(property: "contract"),
      ScVal.layout(property: "key"),
      LayoutConst.s32be(property: "durability")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "contract": contract.toVariantLayoutStruct(),
      "key": key.toVariantLayoutStruct(),
      "durability": durability.value
    };
  }
}

class LedgerKeyContractCode extends LedgerKey {
  final List<int> hash;
  LedgerKeyContractCode(List<int> hash)
      : hash = hash.asImmutableBytes.exc(StellarConst.hash256Length),
        super(LedgerEntryType.contractCode);
  factory LedgerKeyContractCode.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyContractCode(json.asBytes("hash"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "hash")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hash": hash};
  }
}

class LedgerKeyConfigSetting extends LedgerKey {
  final ConfigSettingId configSettingId;
  const LedgerKeyConfigSetting(this.configSettingId)
      : super(LedgerEntryType.configSetting);
  factory LedgerKeyConfigSetting.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyConfigSetting(
        ConfigSettingId.fromValue(json.as("configSettingId")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u32be(property: "configSettingId"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"configSettingId": configSettingId.value};
  }
}

class LedgerKeyTtl extends LedgerKey {
  final List<int> keyHash;
  LedgerKeyTtl(List<int> keyHash)
      : keyHash = keyHash.asImmutableBytes.exc(StellarConst.hash256Length),
        super(LedgerEntryType.ttl);
  factory LedgerKeyTtl.fromStruct(Map<String, dynamic> json) {
    return LedgerKeyTtl(json.asBytes("keyHash"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "keyHash")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"keyHash": keyHash};
  }
}

class LedgerFootprint extends XDRSerialization<Map<String, dynamic>> {
  final List<LedgerKey> readOnly;
  final List<LedgerKey> readWrite;
  LedgerFootprint(
      {required List<LedgerKey> readOnly, required List<LedgerKey> readWrite})
      : readOnly = readOnly.immutable,
        readWrite = readWrite.immutable;
  factory LedgerFootprint.fromStruct(Map<String, dynamic> json) {
    return LedgerFootprint(
      readOnly: json
          .asListOfMap("readOnly")!
          .map((e) => LedgerKey.fromStruct(e))
          .toList(),
      readWrite: json
          .asListOfMap("readWrite")!
          .map((e) => LedgerKey.fromStruct(e))
          .toList(),
    );
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.xdrVec(LedgerKey.layout(), property: "readOnly"),
      LayoutConst.xdrVec(LedgerKey.layout(), property: "readWrite"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "readOnly": readOnly.map((e) => e.toVariantLayoutStruct()).toList(),
      "readWrite": readWrite.map((e) => e.toVariantLayoutStruct()).toList(),
    };
  }
}

class SorobanResources extends XDRSerialization<Map<String, dynamic>> {
  final LedgerFootprint footprint;
  final int instructions;
  final int readBytes;
  final int writeBytes;
  SorobanResources(
      {required this.footprint,
      required int instructions,
      required int readBytes,
      required int writeBytes})
      : instructions = instructions.asUint32,
        readBytes = readBytes.asUint32,
        writeBytes = writeBytes.asUint32;
  factory SorobanResources.fromStruct(Map<String, dynamic> json) {
    return SorobanResources(
        footprint: LedgerFootprint.fromStruct(json.asMap("footprint")),
        instructions: json.as("instructions"),
        readBytes: json.as("readBytes"),
        writeBytes: json.as("writeBytes"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LedgerFootprint.layout(property: "footprint"),
      LayoutConst.u32be(property: "instructions"),
      LayoutConst.u32be(property: "readBytes"),
      LayoutConst.u32be(property: "writeBytes"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "footprint": footprint.toLayoutStruct(),
      "instructions": instructions,
      "readBytes": readBytes,
      "writeBytes": writeBytes
    };
  }
}

class SorobanTransactionData extends XDRSerialization<Map<String, dynamic>> {
  final ExtentionPointVoid ext;
  final SorobanResources resources;
  final BigInt resourceFee;
  SorobanTransactionData(
      {required this.resources,
      required BigInt resourceFee,
      this.ext = const ExtentionPointVoid()})
      : resourceFee = resourceFee.asInt64;
  factory SorobanTransactionData.fromStruct(Map<String, dynamic> json) {
    return SorobanTransactionData(
        resources: SorobanResources.fromStruct(json.asMap("resources")),
        resourceFee: json.as("resourceFee"),
        ext: ExtentionPointVoid.fromStruct(json.as("ext")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ExtentionPointVoid.layout(property: "ext"),
      SorobanResources.layout(property: "resources"),
      LayoutConst.s64be(property: "resourceFee"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "ext": ext.toVariantLayoutStruct(),
      "resources": resources.toLayoutStruct(),
      "resourceFee": resourceFee
    };
  }
}

class TransactionExt extends ExtPoint {
  final SorobanTransactionData? sorobanTransactionData;
  const TransactionExt({this.sorobanTransactionData});

  @override
  int get value => sorobanTransactionData == null ? 0 : 1;
}

class CryptoKeyType {
  final String name;
  final int value;

  const CryptoKeyType._({required this.name, required this.value});

  static const ed25519 = CryptoKeyType._(name: 'Ed25519', value: 0);
  static const preAuthTx = CryptoKeyType._(name: 'PreAuthTx', value: 1);
  static const hashX = CryptoKeyType._(name: 'HashX', value: 2);
  static const ed25519SignedPayload =
      CryptoKeyType._(name: 'Ed25519SignedPayload', value: 3);
  static const muxedEd25519 = CryptoKeyType._(name: 'MuxedEd25519', value: 256);
  static const List<CryptoKeyType> values = [
    ed25519,
    preAuthTx,
    hashX,
    ed25519SignedPayload,
    muxedEd25519
  ];
  static CryptoKeyType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException("Asset type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "CryptoKeyType.$name";
  }
}

abstract class MuxedAccount
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final CryptoKeyType type;
  const MuxedAccount._(this.type);
  factory MuxedAccount(StellarAddress address) {
    if (address.type == XlmAddrTypes.muxed) {
      address as StellarMuxedAddress;
      return MuxedAccountMed25519(
          id: address.accountId, ed25519: address.publicKeyBytes());
    }
    return MuxedAccountEd25519(address.publicKeyBytes());
  }
  factory MuxedAccount.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = CryptoKeyType.fromName(decode.variantName);
    switch (type) {
      case CryptoKeyType.ed25519:
        return MuxedAccountEd25519.fromStruct(decode.value);
      case CryptoKeyType.muxedEd25519:
        return MuxedAccountMed25519.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid MuxedAccount type.",
            details: {"type": type});
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) =>
      LayoutConst.lazyEnumU32Be([
        LazyLayout(
            layout: MuxedAccountEd25519.layout,
            property: CryptoKeyType.ed25519.name),
        ...List.generate(255, (e) => null),
        LazyLayout(
            layout: MuxedAccountMed25519.layout,
            property: CryptoKeyType.muxedEd25519.name),
      ], property: property);

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class MuxedAccountMed25519 extends MuxedAccount {
  final BigInt id;
  final List<int> ed25519;
  MuxedAccountMed25519({required BigInt id, required List<int> ed25519})
      : id = id.asUint64,
        ed25519 = ed25519.asImmutableBytes,
        super._(CryptoKeyType.muxedEd25519);

  factory MuxedAccountMed25519.fromStruct(Map<String, dynamic> json) {
    return MuxedAccountMed25519(
        id: json.as("id"), ed25519: json.asBytes("ed25519"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) =>
      LayoutConst.struct([
        LayoutConst.u64be(property: "id"),
        LayoutConst.fixedBlob32(property: "ed25519"),
      ], property: property);

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"id": id, "ed25519": ed25519};
  }
}

class MuxedAccountEd25519 extends MuxedAccount {
  final List<int> ed25519;
  MuxedAccountEd25519(List<int> ed25519)
      : ed25519 = ed25519.asImmutableBytes,
        super._(CryptoKeyType.ed25519);
  factory MuxedAccountEd25519.fromStruct(Map<String, dynamic> json) {
    return MuxedAccountEd25519(json.asBytes("ed25519"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) =>
      LayoutConst.struct([
        LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "ed25519")
      ], property: property);
  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"ed25519": ed25519};
  }
}

class PreconditionType {
  final String name;
  final int value;

  const PreconditionType._(this.name, this.value);

  static const PreconditionType none = PreconditionType._('None', 0);
  static const PreconditionType time = PreconditionType._('Time', 1);
  static const PreconditionType v2 = PreconditionType._('V2', 2);

  static const List<PreconditionType> values = [none, time, v2];

  static PreconditionType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "Precondition type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }
}

class TimeBounds extends XDRSerialization<Map<String, dynamic>> {
  final BigInt minTime;
  final BigInt maxTime;
  TimeBounds({required BigInt minTime, required BigInt maxTime})
      : minTime = minTime.asUint64,
        maxTime = maxTime.asUint64;
  factory TimeBounds.fromStruct(Map<String, dynamic> json) {
    return TimeBounds(minTime: json.as("minTime"), maxTime: json.as("maxTime"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "minTime"),
      LayoutConst.u64be(property: "maxTime")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"minTime": minTime, "maxTime": maxTime};
  }
}

class LedgerBounds extends XDRSerialization<Map<String, dynamic>> {
  final int minLedger;
  final int maxLedger;
  LedgerBounds({required int minLedger, required int maxLedger})
      : minLedger = minLedger.asUint32,
        maxLedger = maxLedger.asUint32;
  factory LedgerBounds.fromStruct(Map<String, dynamic> json) {
    return LedgerBounds(
        minLedger: json.as("minLedger"), maxLedger: json.as("maxLedger"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u32be(property: "minLedger"),
      LayoutConst.u32be(property: "maxLedger")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"minLedger": minLedger, "maxLedger": maxLedger};
  }
}

class PreconditionsV2 extends XDRSerialization<Map<String, dynamic>> {
  final TimeBounds? timeBounds;
  final LedgerBounds? ledgerBounds;
  final BigInt? minSeqNum;
  final BigInt minSeqAge;
  final int minSeqLedgerGap;
  final List<SignerKey> extraSigners;
  PreconditionsV2(
      {this.timeBounds,
      this.ledgerBounds,
      BigInt? minSeqNum,
      required BigInt minSeqAge,
      required int minSeqLedgerGap,
      required List<SignerKey> extraSigners})
      : minSeqNum = minSeqNum?.asInt64,
        minSeqAge = minSeqAge.asUint64,
        minSeqLedgerGap = minSeqLedgerGap.asUint32,
        extraSigners = extraSigners.immutable.max(2);
  factory PreconditionsV2.fromStruct(Map<String, dynamic> json) {
    return PreconditionsV2(
        timeBounds: json.mybeAs<TimeBounds, Map<String, dynamic>>(
            key: "timeBounds", onValue: (e) => TimeBounds.fromStruct(e)),
        ledgerBounds: json.mybeAs<LedgerBounds, Map<String, dynamic>>(
            key: "ledgerBounds", onValue: (e) => LedgerBounds.fromStruct(e)),
        minSeqNum: json.as("minSeqNum"),
        minSeqAge: json.as("minSeqAge"),
        minSeqLedgerGap: json.as("minSeqLedgerGap"),
        extraSigners: json
            .asListOfMap("extraSigners")!
            .map((e) => SignerKey.fromStruct(e))
            .toList());
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.optionalU32Be(TimeBounds.layout(), property: "timeBounds"),
      LayoutConst.optionalU32Be(LedgerBounds.layout(),
          property: "ledgerBounds"),
      LayoutConst.optionalU32Be(LayoutConst.s64be(), property: "minSeqNum"),
      LayoutConst.u64be(property: "minSeqAge"),
      LayoutConst.u32be(property: "minSeqLedgerGap"),
      LayoutConst.xdrVec(SignerKey.layout(), property: "extraSigners")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "timeBounds": timeBounds?.toLayoutStruct(),
      "ledgerBounds": ledgerBounds?.toLayoutStruct(),
      "minSeqNum": minSeqNum,
      "minSeqAge": minSeqAge,
      "minSeqLedgerGap": minSeqLedgerGap,
      "extraSigners":
          extraSigners.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

abstract class Preconditions
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final PreconditionType type;
  const Preconditions(this.type);
  factory Preconditions.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = PreconditionType.fromName(decode.variantName);
    switch (type) {
      case PreconditionType.none:
        return PrecondNone.fromStruct(decode.value);
      case PreconditionType.time:
        return PrecondTime.fromStruct(decode.value);
      case PreconditionType.v2:
        return PrecondV2.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid Precondition type.",
            details: {"type": type.name});
    }
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be([
      LazyLayout(
          layout: PrecondNone.layout, property: PreconditionType.none.name),
      LazyLayout(
          layout: PrecondTime.layout, property: PreconditionType.time.name),
      LazyLayout(layout: PrecondV2.layout, property: PreconditionType.v2.name)
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class PrecondNone extends Preconditions {
  const PrecondNone() : super(PreconditionType.none);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  factory PrecondNone.fromStruct(Map<String, dynamic> json) {
    return PrecondNone();
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class PrecondTime extends Preconditions {
  final TimeBounds timeBounds;
  const PrecondTime(this.timeBounds) : super(PreconditionType.time);
  factory PrecondTime.fromStruct(Map<String, dynamic> json) {
    return PrecondTime(TimeBounds.fromStruct(json.asMap("timeBounds")));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([TimeBounds.layout(property: "timeBounds")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"timeBounds": timeBounds.toLayoutStruct()};
  }
}

class PrecondV2 extends Preconditions {
  final PreconditionsV2 preconditionsV2;
  const PrecondV2(this.preconditionsV2) : super(PreconditionType.v2);
  factory PrecondV2.fromStruct(Map<String, dynamic> json) {
    return PrecondV2(PreconditionsV2.fromStruct(json.asMap("preconditionsV2")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [PreconditionsV2.layout(property: "preconditionsV2")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"preconditionsV2": preconditionsV2.toLayoutStruct()};
  }
}

abstract class AssetCode extends XDRVariantSerialization<Map<String, dynamic>> {
  final AssetType type;
  final List<int> code;
  const AssetCode({required this.type, required this.code});
  factory AssetCode.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = AssetType.fromName(decode.variantName);
    switch (type) {
      case AssetType.creditAlphanum12:
        return AssetCode12.fromStruct(decode.value);
      case AssetType.creditAlphanum4:
        return AssetCode4.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid AssetCode type",
            details: {"type": type});
    }
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      LayoutConst.none(),
      AssetCode4.layout(property: AssetType.creditAlphanum4.name),
      AssetCode12.layout(property: AssetType.creditAlphanum12.name),
      LayoutConst.none(),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class AssetCode4 extends AssetCode {
  static const int codeLength = 4;
  AssetCode4(List<int> code)
      : super(
            type: AssetType.creditAlphanum4,
            code: code.asImmutableBytes.exc(codeLength));
  factory AssetCode4.fromString(String code) {
    return AssetCode4(
        StellarUtils.toAlphanumAssetCode(code: code, length: codeLength));
  }
  factory AssetCode4.fromStruct(Map<String, dynamic> json) {
    return AssetCode4(json.asBytes("code"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(codeLength, property: "code"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"code": code};
  }
}

class AssetCode12 extends AssetCode {
  static const int codeLength = 12;
  AssetCode12(List<int> code)
      : super(
            type: AssetType.creditAlphanum12,
            code: code.asImmutableBytes.exc(codeLength));
  factory AssetCode12.fromString(String code) {
    return AssetCode12(
        StellarUtils.toAlphanumAssetCode(code: code, length: codeLength));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(codeLength, property: "code"),
    ], property: property);
  }

  factory AssetCode12.fromStruct(Map<String, dynamic> json) {
    return AssetCode12(json.asBytes("code"));
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"code": code};
  }
}

class RevokeSponsorshipType {
  final String name;
  final int value;
  const RevokeSponsorshipType._({required this.name, required this.value});
  static const RevokeSponsorshipType ledgerEntry =
      RevokeSponsorshipType._(name: "LedgerEntry", value: 0);
  static const RevokeSponsorshipType signer =
      RevokeSponsorshipType._(name: "Signer", value: 1);

  static const List<RevokeSponsorshipType> values = [ledgerEntry, signer];
  static RevokeSponsorshipType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "RevokeSponsorship type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "RevokeSponsorshipType.$name";
  }
}

abstract class RevokeSponsorship
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final RevokeSponsorshipType type;
  const RevokeSponsorship(this.type);
  factory RevokeSponsorship.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = RevokeSponsorshipType.fromName(decode.variantName);
    switch (type) {
      case RevokeSponsorshipType.ledgerEntry:
        return RevokeSponsorshipLedgerKey.fromStruct(decode.value);
      case RevokeSponsorshipType.signer:
        return RevokeSponsorshipSigner.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid RevokeSponsorship type.",
            details: {"type": type.name});
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be([
      LazyLayout(
          layout: RevokeSponsorshipLedgerKey.layout,
          property: RevokeSponsorshipType.ledgerEntry.name),
      LazyLayout(
          layout: RevokeSponsorshipSigner.layout,
          property: RevokeSponsorshipType.signer.name),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class RevokeSponsorshipSigner extends RevokeSponsorship {
  final StellarPublicKey accountId;
  final SignerKey signerKey;
  const RevokeSponsorshipSigner(
      {required this.accountId, required this.signerKey})
      : super(RevokeSponsorshipType.signer);
  factory RevokeSponsorshipSigner.fromStruct(Map<String, dynamic> json) {
    return RevokeSponsorshipSigner(
        accountId: StellarPublicKey.fromStruct(json.asMap("accountId")),
        signerKey: SignerKey.fromStruct(json.asMap("signerKey")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
      SignerKey.layout(property: "signerKey")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "accountId": accountId.toLayoutStruct(),
      "signerKey": signerKey.toVariantLayoutStruct(),
    };
  }
}

class RevokeSponsorshipLedgerKey extends RevokeSponsorship {
  final LedgerKey ledgerKey;
  const RevokeSponsorshipLedgerKey(this.ledgerKey)
      : super(RevokeSponsorshipType.ledgerEntry);
  factory RevokeSponsorshipLedgerKey.fromStruct(Map<String, dynamic> json) {
    return RevokeSponsorshipLedgerKey(
        LedgerKey.fromStruct(json.asMap("ledgerKey")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LedgerKey.layout(property: "ledgerKey"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "ledgerKey": ledgerKey.toVariantLayoutStruct(),
    };
  }
}

class HostFunctionType {
  final String name;
  final int value;

  const HostFunctionType._({required this.name, required this.value});

  static const invokeContract =
      HostFunctionType._(name: 'InvokeContract', value: 0);
  static const createContract =
      HostFunctionType._(name: 'CreateContract', value: 1);
  static const uploadContractWasm =
      HostFunctionType._(name: 'UploadContractWasm', value: 2);
  static const List<HostFunctionType> values = [
    invokeContract,
    createContract,
    uploadContractWasm
  ];
  static HostFunctionType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "HostFunction type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "HostFunctionType.$name";
  }
}

abstract class HostFunction
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final HostFunctionType type;
  const HostFunction(this.type);
  factory HostFunction.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = HostFunctionType.fromName(decode.variantName);
    switch (type) {
      case HostFunctionType.invokeContract:
        return HostFunctionTypeInvokeContract.fromStruct(decode.value);
      case HostFunctionType.createContract:
        return HostFunctionTypeCreateContract.fromStruct(decode.value);
      case HostFunctionType.uploadContractWasm:
        return HostFunctionTypeUploadContractWasm.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid HostFunction type.",
            details: {"type": type.name});
    }
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be([
      LazyLayout(
          layout: HostFunctionTypeInvokeContract.layout,
          property: HostFunctionType.invokeContract.name),
      LazyLayout(
          layout: HostFunctionTypeCreateContract.layout,
          property: HostFunctionType.createContract.name),
      LazyLayout(
          layout: HostFunctionTypeUploadContractWasm.layout,
          property: HostFunctionType.uploadContractWasm.name),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class HostFunctionTypeInvokeContract extends HostFunction {
  final InvokeContractArgs args;
  HostFunctionTypeInvokeContract(this.args)
      : super(HostFunctionType.invokeContract);
  factory HostFunctionTypeInvokeContract.fromStruct(Map<String, dynamic> json) {
    return HostFunctionTypeInvokeContract(
        InvokeContractArgs.fromStruct(json.asMap("args")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([InvokeContractArgs.layout(property: "args")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "args": args.toLayoutStruct(),
    };
  }
}

class ContractIdPreimageType {
  final String name;
  final int value;

  const ContractIdPreimageType._({required this.name, required this.value});

  static const fromAddress =
      ContractIdPreimageType._(name: 'FromAddress', value: 0);
  static const fromAsset =
      ContractIdPreimageType._(name: 'FromAsset', value: 1);

  static const List<ContractIdPreimageType> values = [fromAddress, fromAsset];
  static ContractIdPreimageType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "ContractIdPreimage type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "ContractIdPreimageType.$name";
  }
}

abstract class ContractIdPreimage
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final ContractIdPreimageType type;
  const ContractIdPreimage(this.type);
  factory ContractIdPreimage.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = ContractIdPreimageType.fromName(decode.variantName);
    switch (type) {
      case ContractIdPreimageType.fromAddress:
        return ContractIdPreimageFromAddress.fromStruct(decode.value);
      case ContractIdPreimageType.fromAsset:
        return ContractIdPreimageFromAsset.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid ContractIdPreimage type.",
            details: {"type": type.name});
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be([
      LazyLayout(
          layout: ContractIdPreimageFromAddress.layout,
          property: ContractIdPreimageType.fromAddress.name),
      LazyLayout(
          layout: ContractIdPreimageFromAsset.layout,
          property: ContractIdPreimageType.fromAsset.name),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ContractIdPreimageFromAddress extends ContractIdPreimage {
  final ScAddress address;
  final List<int> salt;
  ContractIdPreimageFromAddress(
      {required this.address, required List<int> salt})
      : salt = salt.immutable.exc(StellarConst.hash256Length),
        super(ContractIdPreimageType.fromAddress);
  factory ContractIdPreimageFromAddress.fromStruct(Map<String, dynamic> json) {
    return ContractIdPreimageFromAddress(
      address: ScAddress.fromStruct(json.asMap("address")),
      salt: json.asBytes("salt"),
    );
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScAddress.layout(property: "address"),
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "salt")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"address": address.toVariantLayoutStruct(), "salt": salt};
  }
}

class ContractIdPreimageFromAsset extends ContractIdPreimage {
  final StellarAsset asset;
  ContractIdPreimageFromAsset(this.asset)
      : super(ContractIdPreimageType.fromAsset);
  factory ContractIdPreimageFromAsset.fromStruct(Map<String, dynamic> json) {
    return ContractIdPreimageFromAsset(
      StellarAsset.fromStruct(json.asMap("asset")),
    );
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarAsset.layout(property: "asset"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"asset": asset.toVariantLayoutStruct()};
  }
}

class CreateContractArgs extends XDRSerialization<Map<String, dynamic>> {
  final ContractIdPreimage contractIdPreimage;
  final ContractExecutable executable;
  const CreateContractArgs(
      {required this.contractIdPreimage, required this.executable});
  factory CreateContractArgs.fromStruct(Map<String, dynamic> json) {
    return CreateContractArgs(
        contractIdPreimage:
            ContractIdPreimage.fromStruct(json.as("contractIdPreimage")),
        executable: ContractExecutable.fromStruct(json.as("executable")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ContractIdPreimage.layout(property: "contractIdPreimage"),
      ContractExecutable.layout(property: "executable"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "contractIdPreimage": contractIdPreimage.toVariantLayoutStruct(),
      "executable": executable.toVariantLayoutStruct(),
    };
  }
}

class HostFunctionTypeCreateContract extends HostFunction {
  final CreateContractArgs args;
  const HostFunctionTypeCreateContract(this.args)
      : super(HostFunctionType.createContract);
  factory HostFunctionTypeCreateContract.fromStruct(Map<String, dynamic> json) {
    return HostFunctionTypeCreateContract(
        CreateContractArgs.fromStruct(json.asMap("args")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      CreateContractArgs.layout(property: "args"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"args": args.toLayoutStruct()};
  }
}

class HostFunctionTypeUploadContractWasm extends HostFunction {
  final List<int> wasm;
  HostFunctionTypeUploadContractWasm(List<int> wasm)
      : wasm = wasm.asImmutableBytes,
        super(HostFunctionType.uploadContractWasm);
  factory HostFunctionTypeUploadContractWasm.fromStruct(
      Map<String, dynamic> json) {
    return HostFunctionTypeUploadContractWasm(json.asBytes("wasm"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.xdrVecBytes(property: "wasm"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"wasm": wasm};
  }
}

class SorobanCredentialsType {
  final String name;
  final int value;

  const SorobanCredentialsType._({required this.name, required this.value});

  static const sourceAccount =
      SorobanCredentialsType._(name: 'SourceAccount', value: 0);
  static const address = SorobanCredentialsType._(name: 'Address', value: 1);
  static const List<SorobanCredentialsType> values = [sourceAccount, address];
  static SorobanCredentialsType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "SorobanCredentials type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "SorobanCredentialsType.$name";
  }
}

abstract class SorobanCredentials
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final SorobanCredentialsType type;
  const SorobanCredentials(this.type);
  factory SorobanCredentials.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = SorobanCredentialsType.fromName(decode.variantName);
    switch (type) {
      case SorobanCredentialsType.address:
        return SorobanAddressCredentials.fromStruct(decode.value);
      case SorobanCredentialsType.sourceAccount:
        return SorobanCredentialsSourceAccount.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid SorobanCredentials type.",
            details: {"type": type.name});
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be([
      LazyLayout(
          layout: SorobanCredentialsSourceAccount.layout,
          property: SorobanCredentialsType.sourceAccount.name),
      LazyLayout(
          layout: SorobanAddressCredentials.layout,
          property: SorobanCredentialsType.address.name),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class SorobanAddressCredentials extends SorobanCredentials {
  final ScAddress address;
  final BigInt nonce;
  final int signatureExpirationLedger;
  final ScVal signature;
  SorobanAddressCredentials(
      {required this.address,
      required BigInt nonce,
      required int signatureExpirationLedger,
      required this.signature})
      : nonce = nonce.asInt64,
        signatureExpirationLedger = signatureExpirationLedger.asUint32,
        super(SorobanCredentialsType.address);
  factory SorobanAddressCredentials.fromStruct(Map<String, dynamic> json) {
    return SorobanAddressCredentials(
        address: ScAddress.fromStruct(json.asMap("address")),
        nonce: json.as("nonce"),
        signatureExpirationLedger: json.as("signatureExpirationLedger"),
        signature: ScVal.fromStruct(json.asMap("signature")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScAddress.layout(property: "address"),
      LayoutConst.s64be(property: "nonce"),
      LayoutConst.u32be(property: "signatureExpirationLedger"),
      ScVal.layout(property: "signature")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "address": address.toVariantLayoutStruct(),
      "nonce": nonce,
      "signatureExpirationLedger": signatureExpirationLedger,
      "signature": signature.toVariantLayoutStruct()
    };
  }
}

class SorobanCredentialsSourceAccount extends SorobanCredentials {
  const SorobanCredentialsSourceAccount()
      : super(SorobanCredentialsType.sourceAccount);
  factory SorobanCredentialsSourceAccount.fromStruct(
      Map<String, dynamic> json) {
    return SorobanCredentialsSourceAccount();
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class SorobanAuthorizedFunctionType {
  final String name;
  final int value;

  const SorobanAuthorizedFunctionType._(
      {required this.name, required this.value});

  static const contractFn =
      SorobanAuthorizedFunctionType._(name: 'ContractFn', value: 0);
  static const createContractHostFn =
      SorobanAuthorizedFunctionType._(name: 'CreateContractHostFn', value: 1);
  static const List<SorobanAuthorizedFunctionType> values = [
    contractFn,
    createContractHostFn
  ];
  static SorobanAuthorizedFunctionType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "SorobanAuthorizedFunction type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "SorobanAuthorizedFunctionType.$name";
  }
}

abstract class SorobanAuthorizedFunction
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final SorobanAuthorizedFunctionType type;
  const SorobanAuthorizedFunction(this.type);

  factory SorobanAuthorizedFunction.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = SorobanAuthorizedFunctionType.fromName(decode.variantName);
    switch (type) {
      case SorobanAuthorizedFunctionType.contractFn:
        return SorobanAuthorizedFunctionTypeContractFunction.fromStruct(
            decode.value);
      case SorobanAuthorizedFunctionType.createContractHostFn:
        return SorobanAuthorizedFunctionTypeCreateContractHostFunction
            .fromStruct(decode.value);
      default:
        throw DartStellarPlugingException(
            "Invalid SorobanAuthorizedFunction type.",
            details: {"type": type.name});
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be([
      LazyLayout(
          layout: SorobanAuthorizedFunctionTypeContractFunction.layout,
          property: SorobanAuthorizedFunctionType.contractFn.name),
      LazyLayout(
          layout:
              SorobanAuthorizedFunctionTypeCreateContractHostFunction.layout,
          property: SorobanAuthorizedFunctionType.createContractHostFn.name),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class InvokeContractArgs extends XDRSerialization<Map<String, dynamic>> {
  final ScAddress contractAddress;
  final ScValSymbol functionName;
  final List<ScVal> args;
  InvokeContractArgs(
      {required this.contractAddress,
      required this.functionName,
      required List<ScVal> args})
      : args = args.immutable;
  factory InvokeContractArgs.fromStruct(Map<String, dynamic> json) {
    return InvokeContractArgs(
        contractAddress: ScAddress.fromStruct(json.asMap("contractAddress")),
        functionName: ScValSymbol.fromStruct(json.asMap("functionName")),
        args:
            json.asListOfMap("args")!.map((e) => ScVal.fromStruct(e)).toList());
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScAddress.layout(property: "contractAddress"),
      ScValSymbol.layout(property: "functionName"),
      LayoutConst.xdrVec(ScVal.layout(), property: "args")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  /// should be test
  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "contractAddress": contractAddress.toVariantLayoutStruct(),
      "functionName": functionName.toLayoutStruct(),
      "args": args.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

class SorobanAuthorizedFunctionTypeContractFunction
    extends SorobanAuthorizedFunction {
  final InvokeContractArgs args;
  const SorobanAuthorizedFunctionTypeContractFunction(this.args)
      : super(SorobanAuthorizedFunctionType.contractFn);
  factory SorobanAuthorizedFunctionTypeContractFunction.fromStruct(
      Map<String, dynamic> json) {
    return SorobanAuthorizedFunctionTypeContractFunction(
        InvokeContractArgs.fromStruct(json.asMap("args")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      InvokeContractArgs.layout(property: "args"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"args": args.toLayoutStruct()};
  }
}

class SorobanAuthorizedFunctionTypeCreateContractHostFunction
    extends SorobanAuthorizedFunction {
  final CreateContractArgs args;
  const SorobanAuthorizedFunctionTypeCreateContractHostFunction(this.args)
      : super(SorobanAuthorizedFunctionType.createContractHostFn);

  factory SorobanAuthorizedFunctionTypeCreateContractHostFunction.fromStruct(
      Map<String, dynamic> json) {
    return SorobanAuthorizedFunctionTypeCreateContractHostFunction(
        CreateContractArgs.fromStruct(json.asMap("args")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      CreateContractArgs.layout(property: "args"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"args": args.toLayoutStruct()};
  }
}

class SorobanAuthorizedInvocation
    extends XDRSerialization<Map<String, dynamic>> {
  final SorobanAuthorizedFunction function;
  final List<SorobanAuthorizedInvocation> subInvocations;
  SorobanAuthorizedInvocation(
      {required this.function,
      required List<SorobanAuthorizedInvocation> subInvocations})
      : subInvocations = subInvocations.immutable;
  factory SorobanAuthorizedInvocation.fromStruct(Map<String, dynamic> json) {
    return SorobanAuthorizedInvocation(
        function: SorobanAuthorizedFunction.fromStruct(json.asMap("function")),
        subInvocations: json
            .asListOfMap("subInvocations")!
            .map((e) => SorobanAuthorizedInvocation.fromStruct(e))
            .toList());
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyStruct([
      LazyLayout(
          layout: SorobanAuthorizedFunction.layout, property: "function"),
      LazyLayout(
          layout: SorobanAuthorizedInvocation.layout,
          property: "subInvocations")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "function": function.toVariantLayoutStruct(),
      "subInvocations": subInvocations.map((e) => e.toLayoutStruct()).toList()
    };
  }
}

class SorobanAuthorizationEntry extends XDRSerialization<Map<String, dynamic>> {
  final SorobanCredentials credentials;
  final SorobanAuthorizedInvocation rootInvocation;
  const SorobanAuthorizationEntry(
      {required this.credentials, required this.rootInvocation});
  factory SorobanAuthorizationEntry.fromStruct(Map<String, dynamic> json) {
    return SorobanAuthorizationEntry(
        credentials: SorobanCredentials.fromStruct(json.asMap("credentials")),
        rootInvocation: SorobanAuthorizedInvocation.fromStruct(
            json.asMap("rootInvocation")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      SorobanCredentials.layout(property: "credentials"),
      SorobanAuthorizedInvocation.layout(property: "rootInvocation")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "rootInvocation": rootInvocation.toLayoutStruct(),
      "credentials": credentials.toVariantLayoutStruct()
    };
  }
}

class AuthFlag {
  final String name;
  final int value;

  const AuthFlag._({required this.name, required this.value});

  static const requiredFlag = AuthFlag._(name: 'RequiredFlag', value: 1);
  static const revocableFlag = AuthFlag._(name: 'RevocableFlag', value: 2);
  static const immutableFlag = AuthFlag._(name: 'ImmutableFlag', value: 4);
  static const clawbackEnabledFlag =
      AuthFlag._(name: 'ClawbackEnabledFlag', value: 8);
  static const List<AuthFlag> values = [
    requiredFlag,
    revocableFlag,
    immutableFlag,
    clawbackEnabledFlag
  ];
  @override
  String toString() {
    return "AuthFlag.$name";
  }

  static AuthFlag fromValue(int? flag) {
    return values.firstWhere(
      (e) => e.value == flag,
      orElse: () => throw DartStellarPlugingException("Asset type not found.",
          details: {
            "flag": flag,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }
}

class SorobanTransactionDataExt
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final SorobanTransactionData? sorobanTransactionData;
  const SorobanTransactionDataExt({this.sorobanTransactionData});
  factory SorobanTransactionDataExt.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = ExtensionPointType.fromName(decode.variantName);
    switch (type) {
      case ExtensionPointType.extVoid:
        return SorobanTransactionDataExt();
      case ExtensionPointType.extArgs1:
        return SorobanTransactionDataExt(
            sorobanTransactionData:
                SorobanTransactionData.fromStruct(decode.value));
      default:
        throw DartStellarPlugingException(
            "Invalid SorobanTransactionData extension.");
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be([
      LazyLayout(
          layout: LayoutConst.noArgs,
          property: ExtensionPointType.extVoid.name),
      LazyLayout(
          layout: SorobanTransactionData.layout,
          property: ExtensionPointType.extArgs1.name)
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    if (sorobanTransactionData != null) {
      return SorobanTransactionData.layout(property: property);
    }
    return LayoutConst.noArgs(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return sorobanTransactionData?.toLayoutStruct() ?? {};
  }

  @override
  String get variantName {
    if (sorobanTransactionData == null) return ExtensionPointType.extVoid.name;
    return ExtensionPointType.extArgs1.name;
  }
}

class ExtensionPointType {
  final String name;
  final int value;
  const ExtensionPointType._({required this.name, required this.value});
  static const ExtensionPointType extVoid =
      ExtensionPointType._(name: "extVoid", value: 0);
  static const ExtensionPointType extArgs1 =
      ExtensionPointType._(name: "extArgs1", value: 1);
  static const ExtensionPointType extArgs2 =
      ExtensionPointType._(name: "extArgs2", value: 2);
  static const ExtensionPointType extArgs3 =
      ExtensionPointType._(name: "extArgs3", value: 2);
  static const List<ExtensionPointType> values = [
    extVoid,
    extArgs1,
    extArgs2,
    extArgs3
  ];
  static ExtensionPointType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException("Asset type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }
}

class StellarTransactionV1 extends StellarTransaction {
  final MuxedAccount sourceAccount;
  final int fee;
  final BigInt seqNum;
  final Preconditions cond;
  final StellarMemo memo;
  final List<Operation> operations;
  final SorobanTransactionDataExt sorobanData;

  StellarTransactionV1(
      {required this.sourceAccount,
      required int fee,
      required BigInt seqNum,
      this.cond = const PrecondNone(),
      this.memo = const StellerMemoNone(),
      List<Operation> operations = const [],
      this.sorobanData = const SorobanTransactionDataExt()})
      : operations = operations.immutable
            .max(StellarConst.maxTransactionOperationLength),
        fee = fee.asUint32,
        seqNum = seqNum.asInt64,
        super(EnvelopeType.tx);
  factory StellarTransactionV1.fromStruct(Map<String, dynamic> json) {
    return StellarTransactionV1(
        sourceAccount: MuxedAccount.fromStruct(json.asMap("sourceAccount")),
        fee: json.as("fee"),
        seqNum: json.as("seqNum"),
        cond: Preconditions.fromStruct(json.asMap("cond")),
        memo: StellarMemo.fromStruct(json.asMap("memo")),
        operations: json
            .asListOfMap("operations")!
            .map((e) => Operation.fromStruct(e))
            .toList(),
        sorobanData:
            SorobanTransactionDataExt.fromStruct(json.asMap("sorobanData")));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MuxedAccount.layout(property: "sourceAccount"),
      LayoutConst.u32be(property: "fee"),
      LayoutConst.s64be(property: "seqNum"),
      Preconditions.layout(property: "cond"),
      StellarMemo.layout(property: "memo"),
      LayoutConst.xdrVec(Operation.layout(), property: "operations"),
      SorobanTransactionDataExt.layout(property: "sorobanData")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "sourceAccount": sourceAccount.toVariantLayoutStruct(),
      "fee": fee,
      "seqNum": seqNum,
      "cond": cond.toVariantLayoutStruct(),
      "memo": memo.toVariantLayoutStruct(),
      "operations": operations.map((e) => e.toLayoutStruct()).toList(),
      "sorobanData": sorobanData.toVariantLayoutStruct()
    };
  }
}

class StellarTransactionV0 extends XDRSerialization<Map<String, dynamic>> {
  final StellarPublicKey sourceAccount;
  final int fee;
  final BigInt seqNum;
  final TimeBounds? timeBounds;
  final StellarMemo memo;
  final List<Operation> operations;
  final ExtentionPointVoid ext;

  StellarTransactionV0(
      {required this.sourceAccount,
      required int fee,
      required BigInt seqNum,
      this.timeBounds,
      this.memo = const StellerMemoNone(),
      List<Operation> operations = const [],
      this.ext = const ExtentionPointVoid()})
      : operations = operations.immutable
            .max(StellarConst.maxTransactionOperationLength),
        fee = fee.asUint32,
        seqNum = seqNum.asInt64;

  factory StellarTransactionV0.fromStruct(Map<String, dynamic> json) {
    return StellarTransactionV0(
        sourceAccount:
            StellarPublicKey.fromPublicBytes(json.asBytes("sourceAccount")),
        fee: json.as("fee"),
        seqNum: json.as("seqNum"),
        timeBounds: json.mybeAs<TimeBounds, Map<String, dynamic>>(
            key: "timeBounds", onValue: (e) => TimeBounds.fromStruct(e)),
        memo: StellarMemo.fromStruct(json.asMap("memo")),
        operations: json
            .asListOfMap("operations")!
            .map((e) => Operation.fromStruct(e))
            .toList(),
        ext: ExtentionPointVoid.fromStruct(json.asMap("ext")));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length,
          property: "sourceAccount"),
      LayoutConst.u32be(property: "fee"),
      LayoutConst.s64be(property: "seqNum"),
      LayoutConst.optionalU32Be(TimeBounds.layout(), property: "timeBounds"),
      StellarMemo.layout(property: "memo"),
      LayoutConst.xdrVec(Operation.layout(), property: "operations"),
      ExtentionPointVoid.layout(property: "ext")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "sourceAccount": sourceAccount.toBytes(),
      "fee": fee,
      "seqNum": seqNum,
      "timeBounds": timeBounds?.toLayoutStruct(),
      "memo": memo.toVariantLayoutStruct(),
      "operations": operations.map((e) => e.toLayoutStruct()).toList(),
      "ext": ext.toVariantLayoutStruct()
    };
  }
}

class DecoratedSignature extends XDRSerialization<Map<String, dynamic>> {
  final List<int> hint;
  final List<int> signature;
  DecoratedSignature({required List<int> hint, required List<int> signature})
      : hint = hint.asImmutableBytes.exc(StellarConst.pubkeyHintBytesLength),
        signature =
            signature.asImmutableBytes.exc(StellarConst.ed25519SignatureLength);

  factory DecoratedSignature.fromStruct(Map<String, dynamic> json) {
    return DecoratedSignature(
      hint: json.asBytes("hint"),
      signature: json.asBytes("signature"),
    );
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.pubkeyHintBytesLength,
          property: "hint"),
      LayoutConst.fixedBlobN(StellarConst.ed25519SignatureLength,
          property: "signature"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hint": hint, "signature": signature};
  }
}

class EnvelopeType {
  final String name;
  final int value;
  const EnvelopeType._(this.name, this.value);

  static const EnvelopeType txV0 = EnvelopeType._('txV0', 0);
  static const EnvelopeType scp = EnvelopeType._('scp', 1);
  static const EnvelopeType tx = EnvelopeType._('tx', 2);
  static const EnvelopeType auth = EnvelopeType._('auth', 3);
  static const EnvelopeType scpValue = EnvelopeType._('scpValue', 4);
  static const EnvelopeType txFeeBump = EnvelopeType._('txFeeBump', 5);
  static const EnvelopeType opId = EnvelopeType._('opId', 6);
  static const EnvelopeType poolRevokeOpId =
      EnvelopeType._('poolRevokeOpId', 7);
  static const EnvelopeType contractId = EnvelopeType._('contractId', 8);
  static const EnvelopeType sorobanAuthorization =
      EnvelopeType._('sorobanAuthorization', 9);

  static const List<EnvelopeType> values = [
    txV0,
    scp,
    tx,
    auth,
    scpValue,
    txFeeBump,
    opId,
    poolRevokeOpId,
    contractId,
    sorobanAuthorization,
  ];
  static EnvelopeType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException(
          "Envelope type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "EnvelopeType.$name";
  }
}

abstract class Envelope extends XDRVariantSerialization<Map<String, dynamic>> {
  final EnvelopeType type;
  const Envelope(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be(
        List.generate(EnvelopeType.values.length, (index) {
          final type = EnvelopeType.values.elementAt(index);
          switch (type) {
            case EnvelopeType.txFeeBump:
              return LazyLayout(
                  layout: FeeBumpTransactionEnvelope.layout,
                  property: type.name);
            case EnvelopeType.txV0:
              return LazyLayout(
                  layout: TransactionV0Envelope.layout, property: type.name);
            case EnvelopeType.tx:
              return LazyLayout(
                  layout: TransactionV1Envelope.layout, property: type.name);
            default:
              return LazyLayout(
                  layout: ({property}) => throw DartStellarPlugingException(
                      "Envlop type does not supported.",
                      details: {"type": type.name, "property": property}),
                  property: type.name);
          }
        }),
        property: property);
  }

  factory Envelope.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = EnvelopeType.fromName(decode.variantName);
    switch (type) {
      case EnvelopeType.txV0:
        return TransactionV0Envelope.fromStruct(decode.value);
      case EnvelopeType.tx:
        return TransactionV1Envelope.fromStruct(decode.value);
      case EnvelopeType.txFeeBump:
        return FeeBumpTransactionEnvelope.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Envelope does not supported.",
            details: {"type": type.name});
    }
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;

  T cast<T extends Envelope>() {
    if (this is! T) {
      throw DartStellarPlugingException("Incorrect Envelope casting.",
          details: {"excepted": "$T", "type": "$runtimeType"});
    }
    return this as T;
  }
}

class TransactionV0Envelope extends Envelope {
  final StellarTransactionV0 tx;
  final List<DecoratedSignature> signatures;
  TransactionV0Envelope(
      {required this.tx, required List<DecoratedSignature> signatures})
      : signatures =
            signatures.immutable.max(StellarConst.envlopSignaturesLength),
        super(EnvelopeType.txV0);

  factory TransactionV0Envelope.fromStruct(Map<String, dynamic> json) {
    return TransactionV0Envelope(
      tx: StellarTransactionV0.fromStruct(json.asMap("tx")),
      signatures: json
          .asListOfMap("signatures")!
          .map((e) => DecoratedSignature.fromStruct(e))
          .toList(),
    );
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarTransactionV0.layout(property: "tx"),
      LayoutConst.xdrVec(DecoratedSignature.layout(), property: "signatures"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "tx": tx.toLayoutStruct(),
      "signatures": signatures.map((e) => e.toLayoutStruct()).toList()
    };
  }
}

class TransactionV1Envelope extends Envelope {
  final StellarTransactionV1 tx;
  final List<DecoratedSignature> signatures;
  TransactionV1Envelope(
      {required this.tx, required List<DecoratedSignature> signatures})
      : signatures =
            signatures.immutable.max(StellarConst.envlopSignaturesLength),
        super(EnvelopeType.tx);

  factory TransactionV1Envelope.fromStruct(Map<String, dynamic> json) {
    return TransactionV1Envelope(
      tx: StellarTransactionV1.fromStruct(json.asMap("tx")),
      signatures: json
          .asListOfMap("signatures")!
          .map((e) => DecoratedSignature.fromStruct(e))
          .toList(),
    );
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarTransactionV1.layout(property: "tx"),
      LayoutConst.xdrVec(DecoratedSignature.layout(), property: "signatures"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "tx": tx.toLayoutStruct(),
      "signatures": signatures.map((e) => e.toLayoutStruct()).toList()
    };
  }
}

class StellarFeeBumpTransaction extends StellarTransaction {
  final MuxedAccount feeSource;
  final BigInt fee;
  final TransactionV1Envelope innerTx;
  final ExtentionPointVoid ext;
  StellarFeeBumpTransaction(
      {required this.feeSource,
      required BigInt fee,
      required this.innerTx,
      this.ext = const ExtentionPointVoid()})
      : fee = fee.asInt64,
        super(EnvelopeType.txFeeBump);
  factory StellarFeeBumpTransaction.fromStruct(Map<String, dynamic> json) {
    return StellarFeeBumpTransaction(
        feeSource: MuxedAccount.fromStruct(json.asMap("feeSource")),
        fee: json.as("fee"),
        innerTx: Envelope.fromStruct(json.asMap("innerTx")).cast(),
        ext: ExtentionPointVoid.fromStruct(json.asMap("ext")));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MuxedAccount.layout(property: "feeSource"),
      LayoutConst.s64be(property: "fee"),
      Envelope.layout(property: "innerTx"),
      ExtentionPointVoid.layout(property: "ext")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "feeSource": feeSource.toVariantLayoutStruct(),
      "fee": fee,
      "innerTx": innerTx.toVariantLayoutStruct(),
      "ext": ext.toVariantLayoutStruct()
    };
  }
}

class FeeBumpTransactionEnvelope extends Envelope {
  final StellarFeeBumpTransaction tx;
  final List<DecoratedSignature> signatures;
  FeeBumpTransactionEnvelope(
      {required this.tx, required List<DecoratedSignature> signatures})
      : signatures =
            signatures.immutable.max(StellarConst.envlopSignaturesLength),
        super(EnvelopeType.txFeeBump);

  factory FeeBumpTransactionEnvelope.fromStruct(Map<String, dynamic> json) {
    return FeeBumpTransactionEnvelope(
      tx: StellarFeeBumpTransaction.fromStruct(json.asMap("tx")),
      signatures: json
          .asListOfMap("signatures")!
          .map((e) => DecoratedSignature.fromStruct(e))
          .toList(),
    );
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarFeeBumpTransaction.layout(property: "tx"),
      LayoutConst.xdrVec(DecoratedSignature.layout(), property: "signatures"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "tx": tx.toLayoutStruct(),
      "signatures": signatures.map((e) => e.toLayoutStruct()).toList()
    };
  }
}

abstract class StellarTransaction
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final EnvelopeType type;
  const StellarTransaction(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be(
        List.generate(EnvelopeType.values.length, (index) {
          final type = EnvelopeType.values.elementAt(index);
          switch (type) {
            case EnvelopeType.txFeeBump:
              return LazyLayout(
                  layout: StellarFeeBumpTransaction.layout,
                  property: type.name);
            case EnvelopeType.tx:
              return LazyLayout(
                  layout: StellarTransactionV1.layout, property: type.name);
            default:
              return LazyLayout(
                  layout: ({property}) => throw DartStellarPlugingException(
                      "Transaction type does not supported.",
                      details: {"type": type.name, "property": property}),
                  property: type.name);
          }
        }),
        property: property);
  }

  factory StellarTransaction.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = EnvelopeType.fromName(decode.variantName);
    switch (type) {
      case EnvelopeType.tx:
        return StellarTransactionV1.fromStruct(decode.value);
      case EnvelopeType.txFeeBump:
        return StellarFeeBumpTransaction.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException(
            "Transaction type does not supported.",
            details: {"type": type.name});
    }
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;

  T cast<T extends StellarTransaction>() {
    if (this is! T) {
      throw DartStellarPlugingException("Incorrect StellarTransaction casting.",
          details: {"excepted": "$T", "type": "$runtimeType"});
    }
    return this as T;
  }
}

class TransactionSignaturePayload
    extends XDRSerialization<Map<String, dynamic>> {
  final List<int> networkId;
  final StellarTransaction taggedTransaction;
  TransactionSignaturePayload({
    required List<int> networkId,
    required this.taggedTransaction,
  }) : networkId = networkId.asImmutableBytes.exc(StellarConst.hash256Length);
  factory TransactionSignaturePayload.fromStruct(Map<String, dynamic> json) {
    return TransactionSignaturePayload(
        networkId: json.asBytes("networkId"),
        taggedTransaction:
            StellarTransaction.fromStruct(json.asMap("taggedTransaction")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "networkId"),
      StellarTransaction.layout(property: "taggedTransaction"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "networkId": networkId,
      "taggedTransaction": taggedTransaction.toVariantLayoutStruct()
    };
  }
}
