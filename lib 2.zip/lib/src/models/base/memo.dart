import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/exception/exception.dart';
import 'package:stellar_dart/src/serialization/serialization.dart';
import 'package:stellar_dart/src/utils/validator.dart';

class MemoType {
  final String name;
  final int value;

  const MemoType._(this.name, this.value);

  static const MemoType none = MemoType._('none', 0);
  static const MemoType text = MemoType._('text', 1);
  static const MemoType id = MemoType._('id', 2);
  static const MemoType hash = MemoType._('hash', 3);
  static const MemoType returnHash = MemoType._('returnHash', 4);
  static List<MemoType> values = [none, text, id, hash, returnHash];
  static MemoType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartStellarPlugingException("Asset type not found.",
          details: {
            "name": name,
            "values": values.map((e) => e.name).join(", ")
          }),
    );
  }

  @override
  String toString() {
    return "MemoType.$name";
  }
}

abstract class StellarMemo
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final MemoType type;
  const StellarMemo({required this.type});
  factory StellarMemo.fromStruct(Map<String, dynamic> json) {
    final decode = XDRVariantSerialization.toVariantDecodeResult(json);
    final type = MemoType.fromName(decode.variantName);
    switch (type) {
      case MemoType.none:
        return StellerMemoNone.fromStruct(decode.value);
      case MemoType.returnHash:
        return StellerReturnHash.fromStruct(decode.value);
      case MemoType.hash:
        return StellerMemoHash.fromStruct(decode.value);
      case MemoType.id:
        return StellerMemoID.fromStruct(decode.value);
      case MemoType.text:
        return StellerMemoText.fromStruct(decode.value);
      default:
        throw DartStellarPlugingException("Invalid Memo type.",
            details: {"type": type.name});
    }
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be([
      LazyLayout(layout: StellerMemoNone.layout, property: MemoType.none.name),
      LazyLayout(layout: StellerMemoText.layout, property: MemoType.text.name),
      LazyLayout(layout: StellerMemoID.layout, property: MemoType.id.name),
      LazyLayout(layout: StellerMemoHash.layout, property: MemoType.hash.name),
      LazyLayout(
          layout: StellerReturnHash.layout, property: MemoType.returnHash.name),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class StellerReturnHash extends StellarMemo {
  final List<int> hash;
  StellerReturnHash(List<int> hash)
      : hash = hash.asImmutableBytes.exc(StellarConst.hash256Length),
        super(type: MemoType.returnHash);
  factory StellerReturnHash.fromStruct(Map<String, dynamic> json) {
    return StellerReturnHash(json.asBytes("hash"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "hash"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hash": hash};
  }
}

class StellerMemoHash extends StellarMemo {
  final List<int> hash;
  StellerMemoHash(List<int> hash)
      : hash = hash.asImmutableBytes.exc(StellarConst.hash256Length),
        super(type: MemoType.hash);
  factory StellerMemoHash.fromStruct(Map<String, dynamic> json) {
    return StellerMemoHash(json.asBytes("hash"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "hash"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hash": hash};
  }
}

class StellerMemoID extends StellarMemo {
  final BigInt id;
  StellerMemoID(BigInt id)
      : id = id.asUint64,
        super(type: MemoType.id);
  factory StellerMemoID.fromStruct(Map<String, dynamic> json) {
    return StellerMemoID(json.as("id"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "id"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"id": id};
  }
}

class StellerMemoText extends StellarMemo {
  final String text;
  StellerMemoText(String text)
      : text = text.max(28),
        super(type: MemoType.text);

  factory StellerMemoText.fromStruct(Map<String, dynamic> json) {
    return StellerMemoText(json.as("text"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.xdrString(property: "text"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"text": text};
  }
}

class StellerMemoNone extends StellarMemo {
  const StellerMemoNone() : super(type: MemoType.none);

  factory StellerMemoNone.fromStruct(Map<String, dynamic> json) {
    return StellerMemoNone();
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}
