// import 'package:blockchain_utils/utils/utils.dart';

// class ConfigSettingContractExecutionLanesV0 {
//   final int ledgerMaxTxCount;

//   const ConfigSettingContractExecutionLanesV0({required this.ledgerMaxTxCount});

//   // Factory constructor for creating an instance from JSON
//   factory ConfigSettingContractExecutionLanesV0.fromJson(
//       Map<String, dynamic> json) {
//     return ConfigSettingContractExecutionLanesV0(
//       ledgerMaxTxCount: IntUtils.parse(json['ledgerMaxTxCount']),
//     );
//   }

//   // Method to convert an instance to JSON
//   Map<String, dynamic> toJson() {
//     return {
//       'ledgerMaxTxCount': ledgerMaxTxCount,
//     };
//   }
// }

// class ConfigSettingContractComputeV0 {
//   final BigInt ledgerMaxInstructions;
//   final BigInt txMaxInstructions;
//   final BigInt feeRatePerInstructionsIncrement;
//   final int txMemoryLimit;

//   const ConfigSettingContractComputeV0(
//       {required this.ledgerMaxInstructions,
//       required this.txMaxInstructions,
//       required this.feeRatePerInstructionsIncrement,
//       required this.txMemoryLimit});

//   // Factory constructor to create an instance from a JSON object
//   factory ConfigSettingContractComputeV0.fromJson(Map<String, dynamic> json) {
//     return ConfigSettingContractComputeV0(
//       ledgerMaxInstructions: BigintUtils.parse(json['ledgerMaxInstructions']),
//       txMaxInstructions: BigintUtils.parse(json['txMaxInstructions']),
//       feeRatePerInstructionsIncrement:
//           BigintUtils.parse(json['feeRatePerInstructionsIncrement']),
//       txMemoryLimit: IntUtils.parse(json['txMemoryLimit']),
//     );
//   }

//   // Method to convert the instance to a JSON object
//   Map<String, dynamic> toJson() {
//     return {
//       'ledgerMaxInstructions': ledgerMaxInstructions.toString(),
//       'txMaxInstructions': txMaxInstructions.toString(),
//       'feeRatePerInstructionsIncrement':
//           feeRatePerInstructionsIncrement.toString(),
//       'txMemoryLimit': txMemoryLimit,
//     };
//   }
// }

// class ConfigSettingContractLedgerCostV0 {
//   /// Maximum number of ledger entry read operations per ledger
//   final int ledgerMaxReadLedgerEntries;

//   /// Maximum number of bytes that can be read per ledger
//   final int ledgerMaxReadBytes;

//   /// Maximum number of ledger entry write operations per ledger
//   final int ledgerMaxWriteLedgerEntries;

//   /// Maximum number of bytes that can be written per ledger
//   final int ledgerMaxWriteBytes;

//   /// Maximum number of ledger entry read operations per transaction
//   final int txMaxReadLedgerEntries;

//   /// Maximum number of bytes that can be read per transaction
//   final int txMaxReadBytes;

//   /// Maximum number of ledger entry write operations per transaction
//   final int txMaxWriteLedgerEntries;

//   /// Maximum number of bytes that can be written per transaction
//   final int txMaxWriteBytes;

//   /// Fee per ledger entry read
//   final BigInt feeReadLedgerEntry;

//   /// Fee per ledger entry write
//   final BigInt feeWriteLedgerEntry;

//   /// Fee for reading 1KB
//   final BigInt feeRead1KB;

//   /// Write fee grows linearly until bucket list reaches this size
//   final BigInt bucketListTargetSizeBytes;

//   /// Fee per 1KB write when the bucket list is empty
//   final BigInt writeFee1KBBucketListLow;

//   /// Fee per 1KB write when the bucket list has reached `bucketListTargetSizeBytes`
//   final BigInt writeFee1KBBucketListHigh;

//   /// Write fee multiplier for any additional data past the first `bucketListTargetSizeBytes`
//   final int bucketListWriteFeeGrowthFactor;

//   ConfigSettingContractLedgerCostV0({
//     required this.ledgerMaxReadLedgerEntries,
//     required this.ledgerMaxReadBytes,
//     required this.ledgerMaxWriteLedgerEntries,
//     required this.ledgerMaxWriteBytes,
//     required this.txMaxReadLedgerEntries,
//     required this.txMaxReadBytes,
//     required this.txMaxWriteLedgerEntries,
//     required this.txMaxWriteBytes,
//     required this.feeReadLedgerEntry,
//     required this.feeWriteLedgerEntry,
//     required this.feeRead1KB,
//     required this.bucketListTargetSizeBytes,
//     required this.writeFee1KBBucketListLow,
//     required this.writeFee1KBBucketListHigh,
//     required this.bucketListWriteFeeGrowthFactor,
//   });

//   /// Factory constructor to create an instance from a JSON object
//   factory ConfigSettingContractLedgerCostV0.fromJson(
//       Map<String, dynamic> json) {
//     return ConfigSettingContractLedgerCostV0(
//       ledgerMaxReadLedgerEntries:
//           IntUtils.parse(json['ledgerMaxReadLedgerEntries']),
//       ledgerMaxReadBytes: IntUtils.parse(json['ledgerMaxReadBytes']),
//       ledgerMaxWriteLedgerEntries:
//           IntUtils.parse(json['ledgerMaxWriteLedgerEntries']),
//       ledgerMaxWriteBytes: IntUtils.parse(json['ledgerMaxWriteBytes']),
//       txMaxReadLedgerEntries: IntUtils.parse(json['txMaxReadLedgerEntries']),
//       txMaxReadBytes: IntUtils.parse(json['txMaxReadBytes']),
//       txMaxWriteLedgerEntries: IntUtils.parse(json['txMaxWriteLedgerEntries']),
//       txMaxWriteBytes: IntUtils.parse(json['txMaxWriteBytes']),
//       feeReadLedgerEntry: BigintUtils.parse(json['feeReadLedgerEntry']),
//       feeWriteLedgerEntry: BigintUtils.parse(json['feeWriteLedgerEntry']),
//       feeRead1KB: BigintUtils.parse(json['feeRead1KB']),
//       bucketListTargetSizeBytes:
//           BigintUtils.parse(json['bucketListTargetSizeBytes']),
//       writeFee1KBBucketListLow:
//           BigintUtils.parse(json['writeFee1KBBucketListLow']),
//       writeFee1KBBucketListHigh:
//           BigintUtils.parse(json['writeFee1KBBucketListHigh']),
//       bucketListWriteFeeGrowthFactor:
//           IntUtils.parse(json['bucketListWriteFeeGrowthFactor']),
//     );
//   }

//   /// Method to convert the instance to a JSON object
//   Map<String, dynamic> toJson() {
//     return {
//       'ledgerMaxReadLedgerEntries': ledgerMaxReadLedgerEntries,
//       'ledgerMaxReadBytes': ledgerMaxReadBytes,
//       'ledgerMaxWriteLedgerEntries': ledgerMaxWriteLedgerEntries,
//       'ledgerMaxWriteBytes': ledgerMaxWriteBytes,
//       'txMaxReadLedgerEntries': txMaxReadLedgerEntries,
//       'txMaxReadBytes': txMaxReadBytes,
//       'txMaxWriteLedgerEntries': txMaxWriteLedgerEntries,
//       'txMaxWriteBytes': txMaxWriteBytes,
//       'feeReadLedgerEntry': feeReadLedgerEntry.toString(),
//       'feeWriteLedgerEntry': feeWriteLedgerEntry.toString(),
//       'feeRead1KB': feeRead1KB.toString(),
//       'bucketListTargetSizeBytes': bucketListTargetSizeBytes.toString(),
//       'writeFee1KBBucketListLow': writeFee1KBBucketListLow.toString(),
//       'writeFee1KBBucketListHigh': writeFee1KBBucketListHigh.toString(),
//       'bucketListWriteFeeGrowthFactor': bucketListWriteFeeGrowthFactor,
//     };
//   }
// }

// class ConfigSettingContractHistoricalDataV0 {
//   /// Fee for storing 1KB in archives
//   final BigInt feeHistorical1KB;

//   ConfigSettingContractHistoricalDataV0({required this.feeHistorical1KB});

//   /// Factory constructor to create an instance from a JSON object
//   factory ConfigSettingContractHistoricalDataV0.fromJson(
//       Map<String, dynamic> json) {
//     return ConfigSettingContractHistoricalDataV0(
//         feeHistorical1KB: BigintUtils.parse(json['feeHistorical1KB']));
//   }

//   /// Method to convert the instance to a JSON object
//   Map<String, dynamic> toJson() {
//     return {
//       'feeHistorical1KB': feeHistorical1KB.toString(),
//     };
//   }
// }

// class ConfigSettingContractEventsV0 {
//   /// Maximum size of events that a contract call can emit
//   final int txMaxContractEventsSizeBytes;

//   /// Fee for generating 1KB of contract events
//   final BigInt feeContractEvents1KB;

//   ConfigSettingContractEventsV0(
//       {required this.txMaxContractEventsSizeBytes,
//       required this.feeContractEvents1KB});

//   /// Factory constructor to create an instance from a JSON object
//   factory ConfigSettingContractEventsV0.fromJson(Map<String, dynamic> json) {
//     return ConfigSettingContractEventsV0(
//       txMaxContractEventsSizeBytes:
//           IntUtils.parse(json['txMaxContractEventsSizeBytes']),
//       feeContractEvents1KB: BigintUtils.parse(json['feeContractEvents1KB']),
//     );
//   }

//   /// Method to convert the instance to a JSON object
//   Map<String, dynamic> toJson() {
//     return {
//       'txMaxContractEventsSizeBytes': txMaxContractEventsSizeBytes,
//       'feeContractEvents1KB': feeContractEvents1KB.toString(),
//     };
//   }
// }

// class ConfigSettingContractBandwidthV0 {
//   /// Maximum sum of all transaction sizes in the ledger in bytes
//   final int ledgerMaxTxsSizeBytes;

//   /// Maximum size in bytes for a transaction
//   final int txMaxSizeBytes;

//   /// Fee for 1 KB of transaction size
//   final BigInt feeTxSize1KB;

//   ConfigSettingContractBandwidthV0(
//       {required this.ledgerMaxTxsSizeBytes,
//       required this.txMaxSizeBytes,
//       required this.feeTxSize1KB});

//   /// Factory constructor to create an instance from a JSON object
//   factory ConfigSettingContractBandwidthV0.fromJson(Map<String, dynamic> json) {
//     return ConfigSettingContractBandwidthV0(
//       ledgerMaxTxsSizeBytes: IntUtils.parse(json['ledgerMaxTxsSizeBytes']),
//       txMaxSizeBytes: IntUtils.parse(json['txMaxSizeBytes']),
//       feeTxSize1KB: BigintUtils.parse(json['feeTxSize1KB']),
//     );
//   }

//   /// Method to convert the instance to a JSON object
//   Map<String, dynamic> toJson() {
//     return {
//       'ledgerMaxTxsSizeBytes': ledgerMaxTxsSizeBytes,
//       'txMaxSizeBytes': txMaxSizeBytes,
//       'feeTxSize1KB': feeTxSize1KB.toString(),
//     };
//   }
// }

// class ContractCostType {
//   final int value;

//   const ContractCostType._(this.value);

//   // Cost of running 1 wasm instruction
//   static const ContractCostType wasmInsnExec = ContractCostType._(0);

//   // Cost of allocating a slice of memory (in bytes)
//   static const ContractCostType memAlloc = ContractCostType._(1);

//   // Cost of copying a slice of bytes into a pre-allocated memory
//   static const ContractCostType memCpy = ContractCostType._(2);

//   // Cost of comparing two slices of memory
//   static const ContractCostType memCmp = ContractCostType._(3);

//   // Cost of a host function dispatch
//   static const ContractCostType dispatchHostFunction = ContractCostType._(4);

//   // Cost of visiting a host object
//   static const ContractCostType visitObject = ContractCostType._(5);

//   // Cost of serializing an xdr object to bytes
//   static const ContractCostType valSer = ContractCostType._(6);

//   // Cost of deserializing an xdr object from bytes
//   static const ContractCostType valDeser = ContractCostType._(7);

//   // Cost of computing the sha256 hash from bytes
//   static const ContractCostType computeSha256Hash = ContractCostType._(8);

//   // Cost of computing the ed25519 pubkey from bytes
//   static const ContractCostType computeEd25519PubKey = ContractCostType._(9);

//   // Cost of verifying ed25519 signature of a payload
//   static const ContractCostType verifyEd25519Sig = ContractCostType._(10);

//   // Cost of instantiating a VM from wasm bytecode
//   static const ContractCostType vmInstantiation = ContractCostType._(11);

//   // Cost of instantiating a VM from a cached state
//   static const ContractCostType vmCachedInstantiation = ContractCostType._(12);

//   // Cost of invoking a function on the VM
//   static const ContractCostType invokeVmFunction = ContractCostType._(13);

//   // Cost of computing a keccak256 hash from bytes
//   static const ContractCostType computeKeccak256Hash = ContractCostType._(14);

//   // Cost of decoding an ECDSA signature (curve secp256k1, secp256r1)
//   static const ContractCostType decodeEcdsaCurve256Sig = ContractCostType._(15);

//   // Cost of recovering an ECDSA secp256k1 key from a signature
//   static const ContractCostType recoverEcdsaSecp256k1Key =
//       ContractCostType._(16);

//   // Cost of int256 addition and subtraction
//   static const ContractCostType int256AddSub = ContractCostType._(17);

//   // Cost of int256 multiplication
//   static const ContractCostType int256Mul = ContractCostType._(18);

//   // Cost of int256 division
//   static const ContractCostType int256Div = ContractCostType._(19);

//   // Cost of int256 power
//   static const ContractCostType int256Pow = ContractCostType._(20);

//   // Cost of int256 shift (shl, shr)
//   static const ContractCostType int256Shift = ContractCostType._(21);

//   // Cost of drawing random bytes using a ChaCha20 PRNG
//   static const ContractCostType chaCha20DrawBytes = ContractCostType._(22);

//   // Cost of parsing wasm instructions
//   static const ContractCostType parseWasmInstructions = ContractCostType._(23);

//   // Cost of parsing wasm functions
//   static const ContractCostType parseWasmFunctions = ContractCostType._(24);

//   // Cost of parsing wasm globals
//   static const ContractCostType parseWasmGlobals = ContractCostType._(25);

//   // Cost of parsing wasm table entries
//   static const ContractCostType parseWasmTableEntries = ContractCostType._(26);

//   // Cost of parsing wasm types
//   static const ContractCostType parseWasmTypes = ContractCostType._(27);

//   // Cost of parsing wasm data segments
//   static const ContractCostType parseWasmDataSegments = ContractCostType._(28);

//   // Cost of parsing wasm element segments
//   static const ContractCostType parseWasmElemSegments = ContractCostType._(29);

//   // Cost of parsing wasm imports
//   static const ContractCostType parseWasmImports = ContractCostType._(30);

//   // Cost of parsing wasm exports
//   static const ContractCostType parseWasmExports = ContractCostType._(31);

//   // Cost of parsing wasm data segment bytes
//   static const ContractCostType parseWasmDataSegmentBytes =
//       ContractCostType._(32);

//   // Cost of instantiating wasm instructions
//   static const ContractCostType instantiateWasmInstructions =
//       ContractCostType._(33);

//   // Cost of instantiating wasm functions
//   static const ContractCostType instantiateWasmFunctions =
//       ContractCostType._(34);

//   // Cost of instantiating wasm globals
//   static const ContractCostType instantiateWasmGlobals = ContractCostType._(35);

//   // Cost of instantiating wasm table entries
//   static const ContractCostType instantiateWasmTableEntries =
//       ContractCostType._(36);

//   // Cost of instantiating wasm types
//   static const ContractCostType instantiateWasmTypes = ContractCostType._(37);

//   // Cost of instantiating wasm data segments
//   static const ContractCostType instantiateWasmDataSegments =
//       ContractCostType._(38);

//   // Cost of instantiating wasm element segments
//   static const ContractCostType instantiateWasmElemSegments =
//       ContractCostType._(39);

//   // Cost of instantiating wasm imports
//   static const ContractCostType instantiateWasmImports = ContractCostType._(40);

//   // Cost of instantiating wasm exports
//   static const ContractCostType instantiateWasmExports = ContractCostType._(41);

//   // Cost of instantiating wasm data segment bytes
//   static const ContractCostType instantiateWasmDataSegmentBytes =
//       ContractCostType._(42);

//   // Cost of decoding an SEC-1 uncompressed point on a 256-bit elliptic curve
//   static const ContractCostType sec1DecodePointUncompressed =
//       ContractCostType._(43);

//   // Cost of verifying an ECDSA Secp256r1 signature
//   static const ContractCostType verifyEcdsaSecp256r1Sig =
//       ContractCostType._(44);

//   /// Get all values as a list
//   static List<ContractCostType> get values => [
//         wasmInsnExec,
//         memAlloc,
//         memCpy,
//         memCmp,
//         dispatchHostFunction,
//         visitObject,
//         valSer,
//         valDeser,
//         computeSha256Hash,
//         computeEd25519PubKey,
//         verifyEd25519Sig,
//         vmInstantiation,
//         vmCachedInstantiation,
//         invokeVmFunction,
//         computeKeccak256Hash,
//         decodeEcdsaCurve256Sig,
//         recoverEcdsaSecp256k1Key,
//         int256AddSub,
//         int256Mul,
//         int256Div,
//         int256Pow,
//         int256Shift,
//         chaCha20DrawBytes,
//         parseWasmInstructions,
//         parseWasmFunctions,
//         parseWasmGlobals,
//         parseWasmTableEntries,
//         parseWasmTypes,
//         parseWasmDataSegments,
//         parseWasmElemSegments,
//         parseWasmImports,
//         parseWasmExports,
//         parseWasmDataSegmentBytes,
//         instantiateWasmInstructions,
//         instantiateWasmFunctions,
//         instantiateWasmGlobals,
//         instantiateWasmTableEntries,
//         instantiateWasmTypes,
//         instantiateWasmDataSegments,
//         instantiateWasmElemSegments,
//         instantiateWasmImports,
//         instantiateWasmExports,
//         instantiateWasmDataSegmentBytes,
//         sec1DecodePointUncompressed,
//         verifyEcdsaSecp256r1Sig,
//       ];
// }

// class ExtensionPoint {
//   // Define properties for ExtensionPoint if needed
//   // This is a placeholder, adjust as necessary
//   final int someProperty;

//   const ExtensionPoint(this.someProperty);

//   factory ExtensionPoint.fromJson(Map<String, dynamic> json) {
//     return ExtensionPoint(json['someProperty']);
//   }

//   Map<String, dynamic> toJson() {
//     return {'someProperty': someProperty};
//   }
// }

// class ContractCostParamEntry {
//   final ExtensionPoint ext;
//   final BigInt constTerm;
//   final BigInt linearTerm;

//   const ContractCostParamEntry({
//     required this.ext,
//     required this.constTerm,
//     required this.linearTerm,
//   });

//   factory ContractCostParamEntry.fromJson(Map<String, dynamic> json) {
//     return ContractCostParamEntry(
//       ext: ExtensionPoint.fromJson(json['ext']),
//       constTerm: BigintUtils.parse(json['constTerm']),
//       linearTerm: BigintUtils.parse(json['linearTerm']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'ext': ext.toJson(),
//       'constTerm': constTerm.toString(),
//       'linearTerm': linearTerm.toString(),
//     };
//   }
// }

// class StateArchivalSettings {
//   /// Maximum entry TTL (time-to-live)
//   final int maxEntryTTL;

//   /// Minimum temporary TTL
//   final int minTemporaryTTL;

//   /// Minimum persistent TTL
//   final int minPersistentTTL;

//   /// Rent fee = wfee_rate_average / rent_rate_denominator_for_type
//   final BigInt persistentRentRateDenominator;

//   /// Rent fee = wfee_rate_average / rent_rate_denominator_for_type
//   final BigInt tempRentRateDenominator;

//   /// Max number of entries that emit archival meta in a single ledger
//   final int maxEntriesToArchive;

//   /// Number of snapshots to use when calculating average BucketList size
//   final int bucketListSizeWindowSampleSize;

//   /// How often to sample the BucketList size for the average, in ledgers
//   final int bucketListWindowSamplePeriod;

//   /// Maximum number of bytes that we scan for eviction per ledger
//   final int evictionScanSize;

//   /// Lowest BucketList level to be scanned to evict entries
//   final int startingEvictionScanLevel;

//   const StateArchivalSettings({
//     required this.maxEntryTTL,
//     required this.minTemporaryTTL,
//     required this.minPersistentTTL,
//     required this.persistentRentRateDenominator,
//     required this.tempRentRateDenominator,
//     required this.maxEntriesToArchive,
//     required this.bucketListSizeWindowSampleSize,
//     required this.bucketListWindowSamplePeriod,
//     required this.evictionScanSize,
//     required this.startingEvictionScanLevel,
//   });

//   factory StateArchivalSettings.fromJson(Map<String, dynamic> json) {
//     return StateArchivalSettings(
//       maxEntryTTL: json['maxEntryTTL'],
//       minTemporaryTTL: json['minTemporaryTTL'],
//       minPersistentTTL: json['minPersistentTTL'],
//       persistentRentRateDenominator:
//           BigintUtils.parse(json['persistentRentRateDenominator']),
//       tempRentRateDenominator:
//           BigintUtils.parse(json['tempRentRateDenominator']),
//       maxEntriesToArchive: json['maxEntriesToArchive'],
//       bucketListSizeWindowSampleSize: json['bucketListSizeWindowSampleSize'],
//       bucketListWindowSamplePeriod: json['bucketListWindowSamplePeriod'],
//       evictionScanSize: json['evictionScanSize'],
//       startingEvictionScanLevel: json['startingEvictionScanLevel'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'maxEntryTTL': maxEntryTTL,
//       'minTemporaryTTL': minTemporaryTTL,
//       'minPersistentTTL': minPersistentTTL,
//       'persistentRentRateDenominator': persistentRentRateDenominator.toString(),
//       'tempRentRateDenominator': tempRentRateDenominator.toString(),
//       'maxEntriesToArchive': maxEntriesToArchive,
//       'bucketListSizeWindowSampleSize': bucketListSizeWindowSampleSize,
//       'bucketListWindowSamplePeriod': bucketListWindowSamplePeriod,
//       'evictionScanSize': evictionScanSize,
//       'startingEvictionScanLevel': startingEvictionScanLevel,
//     };
//   }
// }

// class EvictionIterator {
//   /// Bucket list level
//   final int bucketListLevel;

//   /// Indicates if the current bucket is active
//   final bool isCurrBucket;

//   /// Offset in the bucket file
//   final BigInt bucketFileOffset;

//   const EvictionIterator({
//     required this.bucketListLevel,
//     required this.isCurrBucket,
//     required this.bucketFileOffset,
//   });

//   factory EvictionIterator.fromJson(Map<String, dynamic> json) {
//     return EvictionIterator(
//       bucketListLevel: json['bucketListLevel'],
//       isCurrBucket: json['isCurrBucket'],
//       bucketFileOffset: BigintUtils.parse(json['bucketFileOffset']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'bucketListLevel': bucketListLevel,
//       'isCurrBucket': isCurrBucket,
//       'bucketFileOffset': bucketFileOffset.toString(),
//     };
//   }
// }

// class ConfigSettingID {
//   final int value;

//   // Private constructor
//   const ConfigSettingID._(this.value);

//   /// Config setting for maximum contract size in bytes
//   static const ConfigSettingID contractMaxSizeBytes = ConfigSettingID._(0);

//   /// Config setting for contract compute version 0
//   static const ConfigSettingID contractComputeV0 = ConfigSettingID._(1);

//   /// Config setting for contract ledger cost version 0
//   static const ConfigSettingID contractLedgerCostV0 = ConfigSettingID._(2);

//   /// Config setting for contract historical data version 0
//   static const ConfigSettingID contractHistoricalDataV0 = ConfigSettingID._(3);

//   /// Config setting for contract events version 0
//   static const ConfigSettingID contractEventsV0 = ConfigSettingID._(4);

//   /// Config setting for contract bandwidth version 0
//   static const ConfigSettingID contractBandwidthV0 = ConfigSettingID._(5);

//   /// Config setting for contract cost parameters CPU instructions
//   static const ConfigSettingID contractCostParamsCpuInstructions =
//       ConfigSettingID._(6);

//   /// Config setting for contract cost parameters memory bytes
//   static const ConfigSettingID contractCostParamsMemoryBytes =
//       ConfigSettingID._(7);

//   /// Config setting for contract data key size in bytes
//   static const ConfigSettingID contractDataKeySizeBytes = ConfigSettingID._(8);

//   /// Config setting for contract data entry size in bytes
//   static const ConfigSettingID contractDataEntrySizeBytes =
//       ConfigSettingID._(9);

//   /// Config setting for state archival
//   static const ConfigSettingID stateArchival = ConfigSettingID._(10);

//   /// Config setting for contract execution lanes
//   static const ConfigSettingID contractExecutionLanes = ConfigSettingID._(11);

//   /// Config setting for bucket list size window
//   static const ConfigSettingID bucketListSizeWindow = ConfigSettingID._(12);

//   /// Config setting for eviction iterator
//   static const ConfigSettingID evictionIterator = ConfigSettingID._(13);

//   /// List of all ConfigSettingID values
//   static const List<ConfigSettingID> values = [
//     contractMaxSizeBytes,
//     contractComputeV0,
//     contractLedgerCostV0,
//     contractHistoricalDataV0,
//     contractEventsV0,
//     contractBandwidthV0,
//     contractCostParamsCpuInstructions,
//     contractCostParamsMemoryBytes,
//     contractDataKeySizeBytes,
//     contractDataEntrySizeBytes,
//     stateArchival,
//     contractExecutionLanes,
//     bucketListSizeWindow,
//     evictionIterator,
//   ];
// }
