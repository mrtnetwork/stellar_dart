// import 'dart:convert';

// const int SC_SPEC_DOC_LIMIT = 1024;

// class SCSpecType {
//   final int value;

//   const SCSpecType._(this.value);

//   static const SCSpecType val = SCSpecType._(0);
//   static const SCSpecType boolType = SCSpecType._(1);
//   static const SCSpecType voidType = SCSpecType._(2);
//   static const SCSpecType error = SCSpecType._(3);
//   static const SCSpecType u32 = SCSpecType._(4);
//   static const SCSpecType i32 = SCSpecType._(5);
//   static const SCSpecType u64 = SCSpecType._(6);
//   static const SCSpecType i64 = SCSpecType._(7);
//   static const SCSpecType timepoint = SCSpecType._(8);
//   static const SCSpecType duration = SCSpecType._(9);
//   static const SCSpecType u128 = SCSpecType._(10);
//   static const SCSpecType i128 = SCSpecType._(11);
//   static const SCSpecType u256 = SCSpecType._(12);
//   static const SCSpecType i256 = SCSpecType._(13);
//   static const SCSpecType bytes = SCSpecType._(14);
//   static const SCSpecType stringType = SCSpecType._(16);
//   static const SCSpecType symbol = SCSpecType._(17);
//   static const SCSpecType address = SCSpecType._(19);

//   static const SCSpecType option = SCSpecType._(1000);
//   static const SCSpecType result = SCSpecType._(1001);
//   static const SCSpecType vec = SCSpecType._(1002);
//   static const SCSpecType map = SCSpecType._(1004);
//   static const SCSpecType tuple = SCSpecType._(1005);
//   static const SCSpecType bytesN = SCSpecType._(1006);
//   static const SCSpecType udt = SCSpecType._(2000);

//   static const List<SCSpecType> values = [
//     val,
//     boolType,
//     voidType,
//     error,
//     u32,
//     i32,
//     u64,
//     i64,
//     timepoint,
//     duration,
//     u128,
//     i128,
//     u256,
//     i256,
//     bytes,
//     stringType,
//     symbol,
//     address,
//     option,
//     result,
//     vec,
//     map,
//     tuple,
//     bytesN,
//     udt,
//   ];
// }

// class SCSpecTypeOption {
//   final SCSpecType valueType;

//   const SCSpecTypeOption({
//     required this.valueType,
//   });

//   factory SCSpecTypeOption.fromJson(Map<String, dynamic> json) {
//     return SCSpecTypeOption(
//       valueType: SCSpecType.values
//           .firstWhere((type) => type.value == json['valueType']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'valueType': valueType.value,
//     };
//   }
// }

// class SCSpecTypeResult {
//   final SCSpecType okType;
//   final SCSpecType errorType;

//   const SCSpecTypeResult({
//     required this.okType,
//     required this.errorType,
//   });

//   factory SCSpecTypeResult.fromJson(Map<String, dynamic> json) {
//     return SCSpecTypeResult(
//       okType:
//           SCSpecType.values.firstWhere((type) => type.value == json['okType']),
//       errorType: SCSpecType.values
//           .firstWhere((type) => type.value == json['errorType']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'okType': okType.value,
//       'errorType': errorType.value,
//     };
//   }
// }

// class SCSpecTypeVec {
//   final SCSpecType elementType;

//   const SCSpecTypeVec({
//     required this.elementType,
//   });

//   factory SCSpecTypeVec.fromJson(Map<String, dynamic> json) {
//     return SCSpecTypeVec(
//       elementType: SCSpecType.values
//           .firstWhere((type) => type.value == json['elementType']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'elementType': elementType.value,
//     };
//   }
// }

// class SCSpecTypeMap {
//   final SCSpecType keyType;
//   final SCSpecType valueType;

//   const SCSpecTypeMap({
//     required this.keyType,
//     required this.valueType,
//   });

//   factory SCSpecTypeMap.fromJson(Map<String, dynamic> json) {
//     return SCSpecTypeMap(
//       keyType:
//           SCSpecType.values.firstWhere((type) => type.value == json['keyType']),
//       valueType: SCSpecType.values
//           .firstWhere((type) => type.value == json['valueType']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'keyType': keyType.value,
//       'valueType': valueType.value,
//     };
//   }
// }

// class SCSpecTypeTuple {
//   final List<SCSpecType> valueTypes;

//   const SCSpecTypeTuple({
//     required this.valueTypes,
//   });

//   factory SCSpecTypeTuple.fromJson(Map<String, dynamic> json) {
//     return SCSpecTypeTuple(
//       valueTypes: (json['valueTypes'] as List)
//           .map((e) => SCSpecType.values.firstWhere((type) => type.value == e))
//           .toList(),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'valueTypes': valueTypes.map((type) => type.value).toList(),
//     };
//   }
// }

// class SCSpecTypeBytesN {
//   final int n;

//   const SCSpecTypeBytesN({
//     required this.n,
//   });

//   factory SCSpecTypeBytesN.fromJson(Map<String, dynamic> json) {
//     return SCSpecTypeBytesN(
//       n: json['n'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'n': n,
//     };
//   }
// }

// class SCSpecTypeUDT {
//   final String name;

//   const SCSpecTypeUDT({
//     required this.name,
//   });

//   factory SCSpecTypeUDT.fromJson(Map<String, dynamic> json) {
//     return SCSpecTypeUDT(
//       name: json['name'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'name': name,
//     };
//   }
// }

// class SCSpecTypeDef {
//   final SCSpecType type;
//   final SCSpecTypeOption? option;
//   final SCSpecTypeResult? result;
//   final SCSpecTypeVec? vec;
//   final SCSpecTypeMap? map;
//   final SCSpecTypeTuple? tuple;
//   final SCSpecTypeBytesN? bytesN;
//   final SCSpecTypeUDT? udt;

//   const SCSpecTypeDef._({
//     required this.type,
//     this.option,
//     this.result,
//     this.vec,
//     this.map,
//     this.tuple,
//     this.bytesN,
//     this.udt,
//   });

//   factory SCSpecTypeDef.fromJson(Map<String, dynamic> json) {
//     final type = SCSpecType.values.firstWhere((t) => t.value == json['type']);
//     switch (type.value) {
//       case 1000:
//         return SCSpecTypeDef._(
//           type: type,
//           option: SCSpecTypeOption.fromJson(json['option']),
//         );
//       case 1001:
//         return SCSpecTypeDef._(
//           type: type,
//           result: SCSpecTypeResult.fromJson(json['result']),
//         );
//       case 1002:
//         return SCSpecTypeDef._(
//           type: type,
//           vec: SCSpecTypeVec.fromJson(json['vec']),
//         );
//       case 1004:
//         return SCSpecTypeDef._(
//           type: type,
//           map: SCSpecTypeMap.fromJson(json['map']),
//         );
//       case 1005:
//         return SCSpecTypeDef._(
//           type: type,
//           tuple: SCSpecTypeTuple.fromJson(json['tuple']),
//         );
//       case 1006:
//         return SCSpecTypeDef._(
//           type: type,
//           bytesN: SCSpecTypeBytesN.fromJson(json['bytesN']),
//         );
//       case 2000:
//         return SCSpecTypeDef._(
//           type: type,
//           udt: SCSpecTypeUDT.fromJson(json['udt']),
//         );
//       default:
//         return SCSpecTypeDef._(
//           type: type,
//         );
//     }
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'type': type.value,
//       'option': option?.toJson(),
//       'result': result?.toJson(),
//       'vec': vec?.toJson(),
//       'map': map?.toJson(),
//       'tuple': tuple?.toJson(),
//       'bytesN': bytesN?.toJson(),
//       'udt': udt?.toJson()
//     };
//   }
// }

// class SCSpecUDTStructFieldV0 {
//   final String doc;
//   final String name;
//   final SCSpecTypeDef type;

//   const SCSpecUDTStructFieldV0({
//     required this.doc,
//     required this.name,
//     required this.type,
//   });

//   factory SCSpecUDTStructFieldV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecUDTStructFieldV0(
//       doc: json['doc'],
//       name: json['name'],
//       type: SCSpecTypeDef.fromJson(json['type']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'name': name,
//       'type': type.toJson(),
//     };
//   }
// }

// class SCSpecUDTStructV0 {
//   final String doc;
//   final String lib;
//   final String name;
//   final List<SCSpecUDTStructFieldV0> fields;

//   const SCSpecUDTStructV0({
//     required this.doc,
//     required this.lib,
//     required this.name,
//     required this.fields,
//   });

//   factory SCSpecUDTStructV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecUDTStructV0(
//       doc: json['doc'],
//       lib: json['lib'],
//       name: json['name'],
//       fields: (json['fields'] as List)
//           .map((e) => SCSpecUDTStructFieldV0.fromJson(e))
//           .toList(),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'lib': lib,
//       'name': name,
//       'fields': fields.map((e) => e.toJson()).toList(),
//     };
//   }
// }

// class SCSpecUDTUnionCaseVoidV0 {
//   final String doc;
//   final String name;

//   const SCSpecUDTUnionCaseVoidV0({
//     required this.doc,
//     required this.name,
//   });

//   factory SCSpecUDTUnionCaseVoidV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecUDTUnionCaseVoidV0(
//       doc: json['doc'],
//       name: json['name'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'name': name,
//     };
//   }
// }

// class SCSpecUDTUnionCaseTupleV0 {
//   final String doc;
//   final String name;
//   final List<SCSpecTypeDef> type;

//   const SCSpecUDTUnionCaseTupleV0({
//     required this.doc,
//     required this.name,
//     required this.type,
//   });

//   factory SCSpecUDTUnionCaseTupleV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecUDTUnionCaseTupleV0(
//       doc: json['doc'],
//       name: json['name'],
//       type:
//           (json['type'] as List).map((e) => SCSpecTypeDef.fromJson(e)).toList(),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'name': name,
//       'type': type.map((e) => e.toJson()).toList(),
//     };
//   }
// }

// class SCSpecUDTUnionV0 {
//   final String doc;
//   final String lib;
//   final String name;
//   final List<SCSpecUDTUnionCaseV0> cases;

//   const SCSpecUDTUnionV0({
//     required this.doc,
//     required this.lib,
//     required this.name,
//     required this.cases,
//   });

//   factory SCSpecUDTUnionV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecUDTUnionV0(
//       doc: json['doc'],
//       lib: json['lib'],
//       name: json['name'],
//       cases: (json['cases'] as List)
//           .map((e) => SCSpecUDTUnionCaseV0.fromJson(e))
//           .toList(),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'lib': lib,
//       'name': name,
//       'cases': cases.map((e) => e.toJson()).toList(),
//     };
//   }
// }

// class SCSpecUDTEnumCaseV0 {
//   final String doc;
//   final String name;
//   final int value;

//   const SCSpecUDTEnumCaseV0({
//     required this.doc,
//     required this.name,
//     required this.value,
//   });

//   factory SCSpecUDTEnumCaseV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecUDTEnumCaseV0(
//       doc: json['doc'],
//       name: json['name'],
//       value: json['value'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'name': name,
//       'value': value,
//     };
//   }
// }

// class SCSpecUDTEnumV0 {
//   final String doc;
//   final String lib;
//   final String name;
//   final List<SCSpecUDTEnumCaseV0> cases;

//   const SCSpecUDTEnumV0({
//     required this.doc,
//     required this.lib,
//     required this.name,
//     required this.cases,
//   });

//   factory SCSpecUDTEnumV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecUDTEnumV0(
//       doc: json['doc'],
//       lib: json['lib'],
//       name: json['name'],
//       cases: (json['cases'] as List)
//           .map((e) => SCSpecUDTEnumCaseV0.fromJson(e))
//           .toList(),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'lib': lib,
//       'name': name,
//       'cases': cases.map((e) => e.toJson()).toList(),
//     };
//   }
// }

// class SCSpecUDTErrorEnumCaseV0 {
//   final String doc;
//   final String name;
//   final int value;

//   const SCSpecUDTErrorEnumCaseV0({
//     required this.doc,
//     required this.name,
//     required this.value,
//   });

//   factory SCSpecUDTErrorEnumCaseV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecUDTErrorEnumCaseV0(
//       doc: json['doc'],
//       name: json['name'],
//       value: json['value'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'name': name,
//       'value': value,
//     };
//   }
// }

// class SCSpecUDTErrorEnumV0 {
//   final String doc;
//   final String lib;
//   final String name;
//   final List<SCSpecUDTErrorEnumCaseV0> cases;

//   const SCSpecUDTErrorEnumV0({
//     required this.doc,
//     required this.lib,
//     required this.name,
//     required this.cases,
//   });

//   factory SCSpecUDTErrorEnumV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecUDTErrorEnumV0(
//       doc: json['doc'],
//       lib: json['lib'],
//       name: json['name'],
//       cases: (json['cases'] as List)
//           .map((e) => SCSpecUDTErrorEnumCaseV0.fromJson(e))
//           .toList(),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'lib': lib,
//       'name': name,
//       'cases': cases.map((e) => e.toJson()).toList(),
//     };
//   }
// }

// class SCSpecFunctionInputV0 {
//   final String doc;
//   final String name;
//   final SCSpecTypeDef type;

//   const SCSpecFunctionInputV0({
//     required this.doc,
//     required this.name,
//     required this.type,
//   });

//   factory SCSpecFunctionInputV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecFunctionInputV0(
//       doc: json['doc'],
//       name: json['name'],
//       type: SCSpecTypeDef.fromJson(json['type']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'name': name,
//       'type': type.toJson(),
//     };
//   }
// }

// class SCSpecFunctionV0 {
//   final String doc;
//   final String name;
//   final List<SCSpecFunctionInputV0> inputs;
//   final SCSpecTypeDef outputs;

//   const SCSpecFunctionV0({
//     required this.doc,
//     required this.name,
//     required this.inputs,
//     required this.outputs,
//   });

//   factory SCSpecFunctionV0.fromJson(Map<String, dynamic> json) {
//     return SCSpecFunctionV0(
//       doc: json['doc'],
//       name: json['name'],
//       inputs: (json['inputs'] as List)
//           .map((e) => SCSpecFunctionInputV0.fromJson(e))
//           .toList(),
//       outputs: SCSpecTypeDef.fromJson(json['outputs']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'doc': doc,
//       'name': name,
//       'inputs': inputs.map((e) => e.toJson()).toList(),
//       'outputs': outputs.toJson(),
//     };
//   }
// }

// class SCSpecEntryKind {
//   final int value;

//   const SCSpecEntryKind._(this.value);

//   static const SCSpecEntryKind functionV0 = SCSpecEntryKind._(0);
//   static const SCSpecEntryKind udtStructV0 = SCSpecEntryKind._(1);
//   static const SCSpecEntryKind udtUnionV0 = SCSpecEntryKind._(2);
//   static const SCSpecEntryKind udtEnumV0 = SCSpecEntryKind._(3);
//   static const SCSpecEntryKind udtErrorEnumV0 = SCSpecEntryKind._(4);

//   static const List<SCSpecEntryKind> values = [
//     functionV0,
//     udtStructV0,
//     udtUnionV0,
//     udtEnumV0,
//     udtErrorEnumV0,
//   ];
// }

// class SCSpecEntry {
//   final SCSpecEntryKind kind;
//   final SCSpecFunctionV0? functionV0;
//   final SCSpecUDTStructV0? udtStructV0;
//   final SCSpecUDTUnionV0? udtUnionV0;
//   final SCSpecUDTEnumV0? udtEnumV0;
//   final SCSpecUDTErrorEnumV0? udtErrorEnumV0;

//   const SCSpecEntry._({
//     required this.kind,
//     this.functionV0,
//     this.udtStructV0,
//     this.udtUnionV0,
//     this.udtEnumV0,
//     this.udtErrorEnumV0,
//   });

//   factory SCSpecEntry.fromJson(Map<String, dynamic> json) {
//     final kind =
//         SCSpecEntryKind.values.firstWhere((k) => k.value == json['kind']);
//     switch (kind.value) {
//       case 0:
//         return SCSpecEntry._(
//           kind: kind,
//           functionV0: SCSpecFunctionV0.fromJson(json['functionV0']),
//         );
//       case 1:
//         return SCSpecEntry._(
//           kind: kind,
//           udtStructV0: SCSpecUDTStructV0.fromJson(json['udtStructV0']),
//         );
//       case 2:
//         return SCSpecEntry._(
//           kind: kind,
//           udtUnionV0: SCSpecUDTUnionV0.fromJson(json['udtUnionV0']),
//         );
//       case 3:
//         return SCSpecEntry._(
//           kind: kind,
//           udtEnumV0: SCSpecUDTEnumV0.fromJson(json['udtEnumV0']),
//         );
//       case 4:
//         return SCSpecEntry._(
//           kind: kind,
//           udtErrorEnumV0: SCSpecUDTErrorEnumV0.fromJson(json['udtErrorEnumV0']),
//         );
//       default:
//         throw ArgumentError('Unknown SCSpecEntryKind value: ${kind.value}');
//     }
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'kind': kind.value,
//       'functionV0': functionV0?.toJson(),
//       'udtStructV0': udtStructV0?.toJson(),
//       'udtUnionV0': udtUnionV0?.toJson(),
//       'udtEnumV0': udtEnumV0?.toJson(),
//       'udtErrorEnumV0': udtErrorEnumV0?.toJson()
//     };
//   }
// }
