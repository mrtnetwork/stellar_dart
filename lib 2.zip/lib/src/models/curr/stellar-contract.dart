// import 'dart:typed_data';

// // Define SCValType Enum
// class SCValType {
//   final int value;

//   const SCValType._(this.value);

//   static const SCValType bool = SCValType._(0);
//   static const SCValType voidType = SCValType._(1);
//   static const SCValType error = SCValType._(2);
//   static const SCValType u32 = SCValType._(3);
//   static const SCValType i32 = SCValType._(4);
//   static const SCValType u64 = SCValType._(5);
//   static const SCValType i64 = SCValType._(6);
//   static const SCValType timepoint = SCValType._(7);
//   static const SCValType duration = SCValType._(8);
//   static const SCValType u128 = SCValType._(9);
//   static const SCValType i128 = SCValType._(10);
//   static const SCValType u256 = SCValType._(11);
//   static const SCValType i256 = SCValType._(12);
//   static const SCValType bytes = SCValType._(13);
//   static const SCValType string = SCValType._(14);
//   static const SCValType symbol = SCValType._(15);
//   static const SCValType vec = SCValType._(16);
//   static const SCValType map = SCValType._(17);
//   static const SCValType address = SCValType._(18);
//   static const SCValType contractInstance = SCValType._(19);
//   static const SCValType ledgerKeyContractInstance = SCValType._(20);
//   static const SCValType ledgerKeyNonce = SCValType._(21);

//   static const List<SCValType> values = [
//     bool,
//     voidType,
//     error,
//     u32,
//     i32,
//     u64,
//     i64,
//     timepoint,
//     duration,
//     u128,
//     i128,
//     u256,
//     i256,
//     bytes,
//     string,
//     symbol,
//     vec,
//     map,
//     address,
//     contractInstance,
//     ledgerKeyContractInstance,
//     ledgerKeyNonce
//   ];
// }

// // Define SCErrorType Enum
// class SCErrorType {
//   final int tag;

//   const SCErrorType._(this.tag);

//   static const SCErrorType contract = SCErrorType._(0);
//   static const SCErrorType wasmVm = SCErrorType._(1);
//   static const SCErrorType context = SCErrorType._(2);
//   static const SCErrorType storage = SCErrorType._(3);
//   static const SCErrorType object = SCErrorType._(4);
//   static const SCErrorType crypto = SCErrorType._(5);
//   static const SCErrorType events = SCErrorType._(6);
//   static const SCErrorType budget = SCErrorType._(7);
//   static const SCErrorType value = SCErrorType._(8);
//   static const SCErrorType auth = SCErrorType._(9);

//   static const List<SCErrorType> values = [
//     contract,
//     wasmVm,
//     context,
//     storage,
//     object,
//     crypto,
//     events,
//     budget,
//     value,
//     auth
//   ];
// }

// // Define SCErrorCode Enum
// class SCErrorCode {
//   final int value;

//   const SCErrorCode._(this.value);

//   static const SCErrorCode arithDomain = SCErrorCode._(0);
//   static const SCErrorCode indexBounds = SCErrorCode._(1);
//   static const SCErrorCode invalidInput = SCErrorCode._(2);
//   static const SCErrorCode missingValue = SCErrorCode._(3);
//   static const SCErrorCode existingValue = SCErrorCode._(4);
//   static const SCErrorCode exceededLimit = SCErrorCode._(5);
//   static const SCErrorCode invalidAction = SCErrorCode._(6);
//   static const SCErrorCode internalError = SCErrorCode._(7);
//   static const SCErrorCode unexpectedType = SCErrorCode._(8);
//   static const SCErrorCode unexpectedSize = SCErrorCode._(9);

//   static const List<SCErrorCode> values = [
//     arithDomain,
//     indexBounds,
//     invalidInput,
//     missingValue,
//     existingValue,
//     exceededLimit,
//     invalidAction,
//     internalError,
//     unexpectedType,
//     unexpectedSize
//   ];
// }

// // Define SCError Union
// class SCError {
//   final SCErrorType type;
//   final int? contractCode;
//   final SCErrorCode? code;

//   SCError.contract(this.contractCode)
//       : type = SCErrorType.contract,
//         code = null;
//   SCError.defaultError(this.code)
//       : type = SCErrorType.values.firstWhere((e) => e.tag == code!.value),
//         contractCode = null;

//   factory SCError.fromJson(Map<String, dynamic> json) {
//     final type = SCErrorType.values.firstWhere((e) => e.tag == json['type']);
//     switch (type.tag) {
//       case 0:
//         return SCError.contract(json['contractCode']);
//       default:
//         return SCError.defaultError(
//             SCErrorCode.values.firstWhere((e) => e.value == json['code']));
//     }
//   }

//   Map<String, dynamic> toJson() {
//     return {'type': type.tag, 'contractCode': contractCode, 'code': code};
//   }
// }

// // Define Structs and Unions
// class UInt128Parts {
//   final int hi;
//   final int lo;

//   UInt128Parts(this.hi, this.lo);

//   factory UInt128Parts.fromJson(Map<String, dynamic> json) {
//     return UInt128Parts(json['hi'], json['lo']);
//   }

//   Map<String, dynamic> toJson() {
//     return {'hi': hi, 'lo': lo};
//   }
// }

// class Int128Parts {
//   final int hi;
//   final int lo;

//   Int128Parts(this.hi, this.lo);

//   factory Int128Parts.fromJson(Map<String, dynamic> json) {
//     return Int128Parts(json['hi'], json['lo']);
//   }

//   Map<String, dynamic> toJson() {
//     return {'hi': hi, 'lo': lo};
//   }
// }

// class UInt256Parts {
//   final int hiHi;
//   final int hiLo;
//   final int loHi;
//   final int loLo;

//   UInt256Parts(this.hiHi, this.hiLo, this.loHi, this.loLo);

//   factory UInt256Parts.fromJson(Map<String, dynamic> json) {
//     return UInt256Parts(json['hiHi'], json['hiLo'], json['loHi'], json['loLo']);
//   }

//   Map<String, dynamic> toJson() {
//     return {'hiHi': hiHi, 'hiLo': hiLo, 'loHi': loHi, 'loLo': loLo};
//   }
// }

// class Int256Parts {
//   final int hiHi;
//   final int hiLo;
//   final int loHi;
//   final int loLo;

//   Int256Parts(this.hiHi, this.hiLo, this.loHi, this.loLo);

//   factory Int256Parts.fromJson(Map<String, dynamic> json) {
//     return Int256Parts(json['hiHi'], json['hiLo'], json['loHi'], json['loLo']);
//   }

//   Map<String, dynamic> toJson() {
//     return {'hiHi': hiHi, 'hiLo': hiLo, 'loHi': loHi, 'loLo': loLo};
//   }
// }

// // Define ContractExecutableType Enum
// class ContractExecutableType {
//   final int value;

//   const ContractExecutableType._(this.value);

//   static const ContractExecutableType wasm = ContractExecutableType._(0);
//   static const ContractExecutableType stellarAsset =
//       ContractExecutableType._(1);

//   static const List<ContractExecutableType> values = [wasm, stellarAsset];
// }

// // Define ContractExecutable Union
// class ContractExecutable {
//   final ContractExecutableType type;
//   final String? wasmHash;

//   ContractExecutable.wasm(this.wasmHash) : type = ContractExecutableType.wasm;
//   ContractExecutable.stellarAsset()
//       : type = ContractExecutableType.stellarAsset,
//         wasmHash = null;

//   factory ContractExecutable.fromJson(Map<String, dynamic> json) {
//     final type = ContractExecutableType.values
//         .firstWhere((e) => e.value == json['type']);
//     if (type == ContractExecutableType.wasm) {
//       return ContractExecutable.wasm(json['wasmHash']);
//     } else {
//       return ContractExecutable.stellarAsset();
//     }
//   }

//   Map<String, dynamic> toJson() {
//     return {'type': type.value, 'wasmHash': wasmHash};
//   }
// }

// // Define SCAddressType Enum
// class SCAddressType {
//   final int value;

//   const SCAddressType._(this.value);

//   static const SCAddressType account = SCAddressType._(0);
//   static const SCAddressType contract = SCAddressType._(1);

//   static const List<SCAddressType> values = [account, contract];
// }

// // Define SCAddress Union
// class SCAddress {
//   final SCAddressType type;
//   final String? accountId;
//   final String? contractId;

//   SCAddress.account(this.accountId)
//       : type = SCAddressType.account,
//         contractId = null;
//   SCAddress.contract(this.contractId)
//       : type = SCAddressType.contract,
//         accountId = null;

//   factory SCAddress.fromJson(Map<String, dynamic> json) {
//     final type =
//         SCAddressType.values.firstWhere((e) => e.value == json['type']);
//     if (type == SCAddressType.account) {
//       return SCAddress.account(json['accountId']);
//     } else {
//       return SCAddress.contract(json['contractId']);
//     }
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'type': type.value,
//       'accountId': accountId,
//       'contractId': contractId
//     };
//   }
// }

// // Define SCVal
// class SCVal {
//   final SCValType type;
//   final bool? b;
//   final int? u32;
//   final int? i32;
//   final int? u64;
//   final int? i64;
//   final String? timepoint;
//   final String? duration;
//   final UInt128Parts? u128;
//   final Int128Parts? i128;
//   final UInt256Parts? u256;
//   final Int256Parts? i256;
//   final Uint8List? bytes;
//   final String? str;
//   final String? sym;
//   final List<SCVal>? vec;
//   final Map<SCVal, SCVal>? map;
//   final SCAddress? address;
//   final SCContractInstance? instance;
//   final SCNonceKey? nonceKey;
//   final SCError? error;

//   SCVal(
//       {required this.type,
//       this.b,
//       this.u32,
//       this.i32,
//       this.u64,
//       this.i64,
//       this.timepoint,
//       this.duration,
//       this.u128,
//       this.i128,
//       this.u256,
//       this.i256,
//       this.bytes,
//       this.str,
//       this.sym,
//       this.vec,
//       this.map,
//       this.address,
//       this.instance,
//       this.nonceKey,
//       this.error});

//   factory SCVal.fromJson(Map<String, dynamic> json) {
//     final type = SCValType.values.firstWhere((e) => e.value == json['type']);
//     switch (type.value) {
//       case 0:
//         return SCVal(type: type, b: json['b']);
//       case 1:
//         return SCVal(type: type);
//       case 2:
//         return SCVal(type: type, error: SCError.fromJson(json['error']));
//       case 3:
//         return SCVal(type: type, u32: json['u32']);
//       case 4:
//         return SCVal(type: type, i32: json['i32']);
//       case 5:
//         return SCVal(type: type, u64: json['u64']);
//       case 6:
//         return SCVal(type: type, i64: json['i64']);
//       case 7:
//         return SCVal(type: type, timepoint: json['timepoint']);
//       case 8:
//         return SCVal(type: type, duration: json['duration']);
//       case 9:
//         return SCVal(type: type, u128: UInt128Parts.fromJson(json['u128']));
//       case 10:
//         return SCVal(type: type, i128: Int128Parts.fromJson(json['i128']));
//       case 11:
//         return SCVal(type: type, u256: UInt256Parts.fromJson(json['u256']));
//       case 12:
//         return SCVal(type: type, i256: Int256Parts.fromJson(json['i256']));
//       case 13:
//         return SCVal(
//             type: type, bytes: Uint8List.fromList(json['bytes'].cast<int>()));
//       case 14:
//         return SCVal(type: type, str: json['str']);
//       case 15:
//         return SCVal(type: type, sym: json['sym']);
//       case 16:
//         return SCVal(
//             type: type,
//             vec: (json['vec'] as List).map((e) => SCVal.fromJson(e)).toList());
//       case 17:
//         return SCVal(
//             type: type,
//             map: (json['map'] as Map).map((k, v) => MapEntry(
//                   SCVal.fromJson(k),
//                   SCVal.fromJson(v),
//                 )));
//       case 18:
//         return SCVal(type: type, address: SCAddress.fromJson(json['address']));
//       case 19:
//         return SCVal(
//             type: type,
//             instance: SCContractInstance.fromJson(json['instance']));
//       case 20:
//         return SCVal(
//             type: type, nonceKey: SCNonceKey.fromJson(json['nonceKey']));
//       default:
//         throw ArgumentError('Unknown SCValType value: ${type.value}');
//     }
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'type': type.value,
//       'b': b,
//       'u32': u32,
//       'i32': i32,
//       'u64': u64,
//       'i64': i64,
//       'timepoint': timepoint,
//       'duration': duration,
//       'u128': u128,
//       'i128': i128,
//       'u256': u256,
//       'i256': i256,
//       'bytes': bytes?.toList(),
//       'str': str,
//       'sym': sym,
//       'vec': vec,
//       'map': map?.map((k, v) => MapEntry(k.toJson(), v.toJson())),
//       'address': address?.toJson(),
//       'instance': instance?.toJson(),
//       'nonceKey': nonceKey?.toJson()
//     };
//   }
// }

// // Define SCMapEntry
// class SCMapEntry {
//   final SCVal key;
//   final SCVal val;

//   SCMapEntry(this.key, this.val);

//   factory SCMapEntry.fromJson(Map<String, dynamic> json) {
//     return SCMapEntry(
//       SCVal.fromJson(json['key']),
//       SCVal.fromJson(json['val']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'key': key.toJson(),
//       'val': val.toJson(),
//     };
//   }
// }

// // Define SCNonceKey
// class SCNonceKey {
//   final int nonce;

//   SCNonceKey(this.nonce);

//   factory SCNonceKey.fromJson(Map<String, dynamic> json) {
//     return SCNonceKey(json['nonce']);
//   }

//   Map<String, dynamic> toJson() {
//     return {'nonce': nonce};
//   }
// }

// // Define SCContractInstance
// class SCContractInstance {
//   final ContractExecutable executable;
//   final Map<String, SCVal>? storage;

//   SCContractInstance(this.executable, this.storage);

//   factory SCContractInstance.fromJson(Map<String, dynamic> json) {
//     return SCContractInstance(
//       ContractExecutable.fromJson(json['executable']),
//       (json['storage'] as Map<String, dynamic>)
//           .map((k, v) => MapEntry(k, SCVal.fromJson(v))),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'executable': executable.toJson(),
//       'storage': storage?.map((k, v) => MapEntry(k, v.toJson())),
//     };
//   }
// }
