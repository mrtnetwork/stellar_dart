import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/utils/validator.dart';

class Hash256 {
  final List<int> bytes;
  Hash256(List<int> bytes)
      : bytes = StellarValidator.validateBytes(
            bytes: bytes, length: StellarConst.hash256Length);
}
