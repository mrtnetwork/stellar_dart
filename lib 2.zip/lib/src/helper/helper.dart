import 'package:blockchain_utils/utils/utils.dart';
import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/exception/exception.dart';
import 'package:stellar_dart/src/models/base/curr.dart';

class StellarHelper {
  static final BigRational _lumenDecimalRational =
      BigRational(BigInt.from(10).pow(StellarConst.lumenDecimal));

  static BigInt toStroop(String ton) {
    final parse = BigRational.parseDecimal(ton);
    return (parse * _lumenDecimalRational).toBigInt();
  }

  static String fromStroop(BigInt nanotons) {
    final parse = BigRational(nanotons);
    return (parse / _lumenDecimalRational)
        .toDecimal(digits: StellarConst.lumenDecimal);
  }

  static String toAssetsCode(List<int> data) {
    int end = data.length - 1;
    while (end >= 0 && data[end] == 0) {
      end--;
    }
    return StringUtils.decode(data.sublist(0, end + 1));
  }

  static StellarPrice approximatePrice(String price) {
    final maxInt = BigRational.from(maxInt32);
    BigRational number = BigRational.parseDecimal(price);
    List<List<BigRational>> fractions = [
      [BigRational.zero, BigRational.one],
      [BigRational.one, BigRational.zero]
    ];

    while (number <= maxInt) {
      final a = number.floor();
      final f = number - a;

      final h = a * fractions.last[0] + fractions[fractions.length - 2][0];
      final k = a * fractions.last[1] + fractions[fractions.length - 2][1];

      if (h > maxInt || k > maxInt) break;

      fractions.add([h, k]);

      if (f.isZero) break;

      number = BigRational.one / f;
    }

    final lastFraction = fractions.last;
    final n = lastFraction.first;
    final d = lastFraction.last;
    if (n == BigRational.zero || d == BigRational.zero) {
      throw DartStellarPlugingException("Couldn't find approximation",
          details: {"price": price});
    }
    return StellarPrice(
        numerator: n.toBigInt().toInt(), denominator: d.toBigInt().toInt());
  }
}
