import 'package:stellar_dart/src/provider/horizon/core/core/core.dart';
import 'package:stellar_dart/src/provider/horizon/core/core/methods.dart';
import 'package:stellar_dart/src/provider/horizon/models/request/request_types.dart';

/// This endpoint returns the effects of a specific transaction.
/// https://developers.stellar.org/docs/data/horizon/api-reference/retrieve-a-transactions-effects
class HorizonRequestTransactionEffects
    extends HorizonRequestParam<Map<String, dynamic>, Map<String, dynamic>> {
  /// Transactions are commands that modify the ledger state and consist of one or more operations.
  final String txId;
  const HorizonRequestTransactionEffects(this.txId,
      {HorizonPaginationParams? paginationParams})
      : super(paginationParams: paginationParams);

  @override
  String get method => StellarHorizonMethods.transactionEffects.url;

  @override
  List<String> get pathParameters => [txId];
}
