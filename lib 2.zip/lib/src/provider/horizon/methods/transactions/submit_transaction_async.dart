import 'package:stellar_dart/src/provider/horizon/core/core/core.dart';
import 'package:stellar_dart/src/provider/horizon/core/core/methods.dart';

/// This endpoint submits transactions to the Stellar network asynchronously.
/// It is designed to allow users to submit transactions without blocking
/// them while waiting for a response from Horizon. At the same time, it also provides
/// clear response status codes from stellar-core to help understand the status of the
/// submitted transaction. You can then use Horizon's GET transaction endpoint to wait
/// for the transaction to be included in a ledger and ingested by Horizon.
/// https://developers.stellar.org/docs/data/horizon/api-reference/submit-async-transaction
class HorizonRequestSubmitTransactionAsynchronously
    extends HorizonPostRequestParam<Map<String, dynamic>,
        Map<String, dynamic>> {
  final String tx;
  const HorizonRequestSubmitTransactionAsynchronously(this.tx);
  @override
  Object get body => tx;

  @override
  String get method =>
      StellarHorizonMethods.submitTransactionAsynchronously.url;
}
