import 'package:stellar_dart/src/provider/horizon/core/core/core.dart';
import 'package:stellar_dart/src/provider/horizon/core/core/methods.dart';
import 'package:stellar_dart/src/provider/horizon/models/request/request_types.dart';

/// This endpoint lists all assets.
/// https://developers.stellar.org/docs/data/horizon/api-reference/list-all-assets
class HorizonRequestAssets
    extends HorizonRequestParam<Map<String, dynamic>, Map<String, dynamic>> {
  /// The code of the asset you would like to filter by.
  final String? assetCode;

  /// The Stellar address of the issuer for the asset you would like to filter by.
  final String? assetIssuer;

  const HorizonRequestAssets({
    this.assetCode,
    this.assetIssuer,
    HorizonPaginationParams? paginationParams,
  }) : super(paginationParams: paginationParams);

  @override
  String get method => StellarHorizonMethods.assets.url;

  @override
  List<String> get pathParameters => [];

  @override
  Map<String, dynamic> get queryParameters =>
      {"asset_code": assetCode, "asset_issuer": assetIssuer};
}
