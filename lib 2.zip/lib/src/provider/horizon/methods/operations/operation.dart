import 'package:stellar_dart/src/provider/horizon/core/core/core.dart';
import 'package:stellar_dart/src/provider/horizon/core/core/methods.dart';

/// The single operation endpoint provides information about a specific operation.
/// https://developers.stellar.org/docs/data/horizon/api-reference/retrieve-an-operation
class HorizonRequestOperation
    extends HorizonRequestParam<Map<String, dynamic>, Map<String, dynamic>> {
  /// The ID number for this operation.
  final String id;

  /// Set to transactions to include the transactions which created each of the operations in the response.
  final Object? join;
  const HorizonRequestOperation(this.id, {this.join});

  @override
  String get method => StellarHorizonMethods.operation.url;

  @override
  List<String> get pathParameters => [id];

  @override
  Map<String, dynamic> get queryParameters => {"join": join};
}
