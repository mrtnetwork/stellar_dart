import 'package:stellar_dart/src/provider/horizon/core/core/core.dart';
import 'package:stellar_dart/src/provider/horizon/core/core/methods.dart';
import 'package:stellar_dart/src/provider/horizon/models/models.dart';

/// This endpoint returns the effects of a specific operation.
/// https://developers.stellar.org/docs/data/horizon/api-reference/retrieve-an-operations-effects
class HorizonRequestOperationEffects
    extends HorizonRequestParam<Map<String, dynamic>, Map<String, dynamic>> {
  /// The ID number for this operation.
  final String id;

  const HorizonRequestOperationEffects(this.id,
      {HorizonPaginationParams? paginationParams})
      : super(paginationParams: paginationParams);

  @override
  String get method => StellarHorizonMethods.operation.url;

  @override
  List<String> get pathParameters => [id];
}
