import 'package:stellar_dart/src/provider/horizon/core/core/core.dart';
import 'package:stellar_dart/src/provider/horizon/core/core/methods.dart';

/// The single offer endpoint provides information on a specific offer.
/// https://developers.stellar.org/docs/data/horizon/api-reference/get-offer-by-offer-id
class HorizonRequestOffer
    extends HorizonRequestParam<Map<String, dynamic>, Map<String, dynamic>> {
  final String offerId;
  const HorizonRequestOffer(this.offerId);

  @override
  String get method => StellarHorizonMethods.offer.url;

  @override
  List<String> get pathParameters => [offerId];
}
