import 'package:stellar_dart/src/provider/horizon/core/core/core.dart';
import 'package:stellar_dart/src/provider/horizon/core/core/methods.dart';

/// The fee stats endpoint provides information about per-operation fee stats over the last 5 ledgers.
/// https://developers.stellar.org/docs/data/horizon/api-reference/retrieve-fee-stats
class HorizonRequestFeeStats
    extends HorizonRequestParam<Map<String, dynamic>, Map<String, dynamic>> {
  const HorizonRequestFeeStats();

  @override
  String get method => StellarHorizonMethods.feeStats.url;

  @override
  Map<String, dynamic> get queryParameters => {};
}
