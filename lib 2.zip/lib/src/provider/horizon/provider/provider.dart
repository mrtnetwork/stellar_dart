import 'package:stellar_dart/src/provider/horizon/core/core.dart';
import 'package:stellar_dart/src/provider/horizon/service/service.dart';

/// Facilitates communication with the stellar horizon api by making requests using a provided [HorizonProvider].
class HorizonProvider {
  /// The underlying horizon service provider used for network communication.
  final HorizonServiceProvider rpc;

  /// Constructs a new [HorizonProvider] instance with the specified [rpc] service provider.
  HorizonProvider(this.rpc);

  int _id = 0;

  static void _findError(dynamic val) {
    // if (val is Map) {
    //   if (val.containsKey("status_code") && val.containsKey("error")) {
    //     final String error = val["error"];
    //     final int statusCode = int.tryParse(val["status_code"].toString()) ?? 0;
    //     final String message = val["message"];
    //     throw Exception(message: message, statusCode: statusCode, error: error);
    //   }
    // }
  }

  /// Sends a request to the stellar network using the specified [request] parameter.
  ///
  /// The [timeout] parameter, if provided, sets the maximum duration for the request.
  /// Whatever is received will be returned
  Future<dynamic> requestDynamic(HorizonRequestParam request,
      [Duration? timeout]) async {
    final id = ++_id;
    final params = request.toRequest(id);
    final data = params.requestType == HTTPRequestType.post
        ? await rpc.post(params, timeout)
        : await rpc.get(params, timeout);
    _findError(data);
    return data;
  }

  /// Sends a request to the stellar network using the specified [request] parameter.
  ///
  /// The [timeout] parameter, if provided, sets the maximum duration for the request.
  Future<T> request<T, E>(HorizonRequestParam<T, E> request,
      [Duration? timeout]) async {
    final data = await requestDynamic(request, timeout);
    final Object result;
    if (E == List<Map<String, dynamic>>) {
      result = (data as List).map((e) => Map<String, dynamic>.from(e)).toList();
    } else {
      result = data;
    }
    return request.onResonse(result as E);
  }
}
