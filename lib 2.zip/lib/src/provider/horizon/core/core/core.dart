import 'package:stellar_dart/src/provider/horizon/models/models.dart';

enum HTTPRequestType { get, post }

abstract class HorizonRequestParams {
  abstract final String method;
}

abstract class HorizonRequestParam<RESULT, RESPONSE>
    implements HorizonRequestParams {
  const HorizonRequestParam({this.paginationParams});
  final HorizonPaginationParams? paginationParams;
  List<String> get pathParameters => [];
  Map<String, dynamic> get queryParameters => {};

  RESULT onResonse(RESPONSE result) {
    return result as RESULT;
  }

  HorizonRequestDetails toRequest(int v) {
    throw UnimplementedError();
    // final pathParams = HorizonProviderUtils.extractParams(method);
    // if (pathParams.length != pathParameters.length) {
    //   throw MessageException("Invalid Path Parameters.", details: {
    //     "pathParams": pathParameters,
    //     "ExceptedPathParametersLength": pathParams.length
    //   });
    // }
    // String params = method;
    // for (int i = 0; i < pathParams.length; i++) {
    //   params = params.replaceFirst(pathParams[i], pathParameters[i]);
    // }
    // if (filter != null) {
    //   params = Uri.parse(params)
    //       .replace(queryParameters: filter!.toJson())
    //       .normalizePath()
    //       .toString();
    // }
    // return HorizonRequestDetails(id: v, pathParams: params);
  }
}

abstract class HorizonPostRequestParam<RESULT, RESPONSE>
    extends HorizonRequestParam<RESULT, RESPONSE> {
  const HorizonPostRequestParam();
  abstract final Object body;

  final Map<String, String>? header = null;

  @override
  HorizonRequestDetails toRequest(int v) {
    final request = super.toRequest(v);
    return request.copyWith(
        body: body, header: header, requestType: HTTPRequestType.post);
  }
}

class HorizonRequestDetails {
  const HorizonRequestDetails(
      {required this.id,
      required this.pathParams,
      this.header = const {},
      this.requestType = HTTPRequestType.get,
      this.body});

  HorizonRequestDetails copyWith({
    int? id,
    String? pathParams,
    HTTPRequestType? requestType,
    Map<String, String>? header,
    Object? body,
  }) {
    return HorizonRequestDetails(
      id: id ?? this.id,
      pathParams: pathParams ?? this.pathParams,
      requestType: requestType ?? this.requestType,
      header: header ?? this.header,
      body: body ?? this.body,
    );
  }

  /// Unique identifier for the request.
  final int id;

  /// URL path parameters
  final String pathParams;

  final HTTPRequestType requestType;

  final Map<String, String> header;

  final Object? body;

  /// Generates the complete request URL by combining the base URI and method-specific URI.
  String url(String uri, String version) {
    String url = uri;
    if (!url.contains(version)) {
      if (url.endsWith("/")) {
        url = url + version;
      } else {
        url = "$url/$version";
      }
    }
    if (url.endsWith("/")) {
      url = url.substring(0, url.length - 1);
    }

    return "$url$pathParams";
  }
}
