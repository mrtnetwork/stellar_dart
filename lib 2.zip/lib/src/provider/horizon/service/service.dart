import 'package:stellar_dart/src/provider/horizon/core/core.dart';

mixin HorizonServiceProvider {
  String get url;
  Future<dynamic> post(HorizonRequestDetails params, [Duration? timeout]);

  Future<dynamic> get(HorizonRequestDetails params, [Duration? timeout]);
}
