class RequestAssetType {
  final String name;
  const RequestAssetType._(this.name);
  static const RequestAssetType native = RequestAssetType._("native");
  static const RequestAssetType creditAlphanum4 =
      RequestAssetType._("credit_alphanum4");
  static const RequestAssetType creditAlphanum12 =
      RequestAssetType._("credit_alphanum12");
  @override
  String toString() {
    return "RequestAssetType.$name";
  }
}

class RequestTradeType {
  final String name;
  const RequestTradeType._(this.name);
  static const RequestTradeType all = RequestTradeType._("all");
  static const RequestTradeType orderbook = RequestTradeType._("orderbook");
  static const RequestTradeType liquidityPools =
      RequestTradeType._("liquidity_pools");
  @override
  String toString() {
    return "RequestTradeType.$name";
  }
}

enum HorizonQueryOrder { asc, desc }

class HorizonPaginationParams {
  /// A number that points to a specific location in a collection of
  /// responses and is pulled from the paging_token value of a record.
  final int? cursor;

  /// A designation of the order in which records should appear.
  /// Options include asc (ascending) or desc (descending).
  /// If this argument isn’t set, it defaults to asc.
  final HorizonQueryOrder? order;

  /// The maximum number of records returned. The limit can range from 1 to 200 -
  /// an upper limit that is hardcoded in Horizon for performance reasons. If this argument isn’t designated, it defaults to 10.
  final int? limit;

  const HorizonPaginationParams(
      {required this.cursor, required this.order, required this.limit});
}

class HorizonTransactionPaginationParams extends HorizonPaginationParams {
  HorizonTransactionPaginationParams(
      {required int? cursor,
      required HorizonQueryOrder? order,
      required int? limit,
      this.includeFailed})
      : super(cursor: cursor, order: order, limit: limit);

  /// Set to true to include failed operations in results. Options include true and false.
  final bool? includeFailed;
}

class HorizonPaymentPaginationParams
    extends HorizonTransactionPaginationParams {
  HorizonPaymentPaginationParams(
      {required int? cursor,
      required HorizonQueryOrder? order,
      required int? limit,
      bool? includeFailed,
      this.join})
      : super(
            cursor: cursor,
            order: order,
            limit: limit,
            includeFailed: includeFailed);

  /// Set to transactions to include the transactions which created each of the operations in the response.
  final Object? join;
}
