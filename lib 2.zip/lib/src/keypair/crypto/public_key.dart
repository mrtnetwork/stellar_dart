import 'package:blockchain_utils/bip/ecc/keys/ed25519_keys.dart';
import 'package:blockchain_utils/layout/constant/constant.dart';
import 'package:blockchain_utils/layout/core/core/core.dart';
import 'package:stellar_dart/src/address/address.dart';
import 'package:stellar_dart/src/exception/exception.dart';
import 'package:stellar_dart/src/serialization/serialization.dart';
import 'package:stellar_dart/src/utils/validator.dart';

class StellarPublicKey extends XDRSerialization<Map<String, dynamic>> {
  final Ed25519PublicKey _publicKey;
  const StellarPublicKey._(this._publicKey);
  factory StellarPublicKey.fromPublicBytes(List<int> bytes) {
    return StellarPublicKey._(Ed25519PublicKey.fromBytes(bytes));
  }
  factory StellarPublicKey.fromAddress(StellarBaseAddress address) {
    return StellarPublicKey.fromPublicBytes(address.publicKeyBytes());
  }
  factory StellarPublicKey.fromXdr(List<int> bytes, {String? property}) {
    final decode = XDRSerialization.deserialize(
        bytes: bytes, layout: layout(property: property));
    return StellarPublicKey.fromStruct(decode);
  }
  factory StellarPublicKey.fromStruct(Map<String, dynamic> json) {
    final int type = json.as("type");
    if (type != 0) {
      throw DartStellarPlugingException("Invalid StellarPublicKey XDR bytes.");
    }
    return StellarPublicKey.fromPublicBytes(json.asBytes("ed25519"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u32be(property: "type"),
      LayoutConst.fixedBlob32(property: "ed25519")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"type": 0, "ed25519": _publicKey.compressed.sublist(1)};
  }

  List<int> toBytes() {
    return _publicKey.compressed.sublist(1);
  }
}
