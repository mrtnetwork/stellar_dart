import 'package:blockchain_utils/bip/address/decoders.dart';
import 'package:blockchain_utils/bip/address/encoders.dart';
import 'package:stellar_dart/src/address/core/address.dart';
import 'package:stellar_dart/src/address/exception/exception.dart';

class StellarBaseAddress extends StellarAddress {
  StellarBaseAddress._({required String address, required XlmAddrTypes type})
      : super(baseAddress: address, type: type);
  factory StellarBaseAddress.fromPublicKey(List<int> publicKey,
      {XlmAddrTypes type = XlmAddrTypes.pubKey}) {
    if (type == XlmAddrTypes.muxed) {
      throw StellarAddressException(
          "Use `StellarMuxedAddress` instead `StellarBaseAddress` for muxed address.");
    }
    try {
      final encode = XlmAddrEncoder().encodeKey(publicKey, {"addr_type": type});
      return StellarBaseAddress._(address: encode, type: type);
    } catch (e) {
      throw StellarAddressException("Invalid publick key.",
          details: {"stack": e.toString()});
    }
  }
  factory StellarBaseAddress(String address, {XlmAddrTypes? type}) {
    try {
      final decode = XlmAddrDecoder().decode(address);
      if (decode.type == XlmAddrTypes.muxed) {
        throw StellarAddressException(
            "Use `StellarMuxedAddress` instead `StellarBaseAddress` for muxed address.");
      } else if (type != null && decode.type != type) {
        throw StellarAddressException("Incorrect address type.", details: {
          "excepted": type.toString(),
          "got": decode.type.toString()
        });
      }
      return StellarBaseAddress._(address: address, type: decode.type);
    } on StellarAddressException {
      rethrow;
    } catch (e) {
      throw StellarAddressException("Invalid stellar base address.",
          details: {"stack": e.toString()});
    }
  }
}
