import 'package:blockchain_utils/helper/extensions/extensions.dart';
import 'package:blockchain_utils/layout/core/core/core.dart';
import 'package:blockchain_utils/utils/binary/utils.dart';
import 'package:stellar_dart/src/exception/exception.dart';
import 'package:stellar_dart/src/utils/validator.dart';

abstract class XDRSerialization<T> {
  static Map<String, dynamic> deserialize(
      {required List<int> bytes,
      required Layout<Map<String, dynamic>> layout}) {
    final decode = layout.deserialize(bytes);
    return decode.value;
  }

  const XDRSerialization();

  Layout<T> createLayout({String? property});
  T toLayoutStruct();
  List<int> toXDR({String? property}) {
    final layout = createLayout(property: property);
    return layout.serialize(toLayoutStruct());
  }

  String toXDRHex() {
    return BytesUtils.toHexString(toXDR());
  }
}

class XDRVariantDecodeResult {
  final Map<String, dynamic> result;
  String get variantName => result["key"];
  Map<String, dynamic> get value => result["value"];
  XDRVariantDecodeResult(Map<String, dynamic> result)
      : result = result.immutable;

  @override
  String toString() {
    return "$variantName: $value";
  }
}

abstract class XDRVariantSerialization<T> extends XDRSerialization<T> {
  const XDRVariantSerialization();
  static XDRVariantDecodeResult toVariantDecodeResult(
      Map<String, dynamic> json) {
    if (json["key"] is! String || !json.containsKey("value")) {
      throw DartStellarPlugingException(
          "Invalid variant layout. only use enum layout to deserialize with `XDRVariantSerialization.deserialize` method.");
    }
    return XDRVariantDecodeResult(json);
  }

  static Map<String, dynamic> deserialize(
      {required List<int> bytes,
      required Layout<Map<String, dynamic>> layout}) {
    final json = layout.deserialize(bytes).value;
    if (json["key"] is! String || !json.containsKey("value")) {
      throw DartStellarPlugingException(
          "Invalid variant layout. only use enum layout to deserialize with `XDRVariantSerialization.deserialize` method.");
    }
    return json;
  }

  String get variantName;
  Layout<Map<String, dynamic>> createVariantLayout({String? property});
  Map<String, dynamic> toVariantLayoutStruct() {
    return {variantName: toLayoutStruct()};
  }

  List<int> toVariantXDR({String? property}) {
    final layout = createVariantLayout(property: property);
    return layout.serialize(toVariantLayoutStruct());
  }

  String toVariantXDRHex() {
    return BytesUtils.toHexString(toVariantXDR());
  }
}
