import 'package:blockchain_utils/layout/core/core/core.dart';
import 'package:blockchain_utils/utils/binary/utils.dart';

abstract class XDRSerialization<T> {
  const XDRSerialization();
  Layout<T> createLayout({String? property});
  T toLayoutStruct();
  List<int> toXDR({String? property}) {
    final layout = createLayout(property: property);
    return layout.serialize(toLayoutStruct());
  }

  String toXDRHex() {
    return BytesUtils.toHexString(toXDR());
  }
}

abstract class XDRVariantSerialization<T> extends XDRSerialization<T> {
  const XDRVariantSerialization();
  String get variantName;
  Layout<Map<String, dynamic>> createVariantLayout({String? property});
  Map<String, dynamic> toVariantLayoutStruct() {
    return {variantName: toLayoutStruct()};
  }

  List<int> toVariantXDR({String? property}) {
    final layout = createVariantLayout(property: property);
    return layout.serialize(toVariantLayoutStruct());
  }

  String toVariantXDRHex() {
    return BytesUtils.toHexString(toVariantXDR());
  }
}
