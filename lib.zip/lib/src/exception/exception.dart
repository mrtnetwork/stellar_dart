import 'package:blockchain_utils/exception/exceptions.dart';

class DartStellarPlugingException extends BlockchainUtilsException {
  const DartStellarPlugingException(this.message, {this.details});
  @override
  final Map<String, dynamic>? details;

  @override
  final String message;
}
