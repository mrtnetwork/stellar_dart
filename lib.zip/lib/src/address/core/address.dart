import 'package:blockchain_utils/blockchain_utils.dart';

abstract class StellarAddress {
  final String baseAddress;
  final XlmAddrTypes type;
  const StellarAddress({required this.baseAddress, required this.type});
  String get address => baseAddress;
  List<int> publicKeyBytes() {
    final decode = XlmAddrDecoder().decode(baseAddress);
    return decode.pubKeyBytes;
  }

  @override
  String toString() {
    return address;
  }
}
