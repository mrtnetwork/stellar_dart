import 'package:blockchain_utils/bip/address/decoders.dart';
import 'package:blockchain_utils/bip/address/encoders.dart';
import 'package:stellar_dart/src/address/core/address.dart';
import 'package:stellar_dart/src/address/exception/exception.dart';

class StellarMuxedAddress extends StellarAddress {
  final BigInt accountId;
  @override
  final String address;
  StellarMuxedAddress._(
      {required String baseAddress,
      required this.address,
      required this.accountId})
      : super(baseAddress: address, type: XlmAddrTypes.muxed);
  factory StellarMuxedAddress.fromPublicKey(
      {required List<int> publicKey, required BigInt accountId}) {
    try {
      final address = XlmAddrEncoder().encodeKey(publicKey,
          {"addr_type": XlmAddrTypes.muxed, "account_id": accountId});
      final baseAddress = XlmAddrEncoder()
          .encodeKey(publicKey, {"addr_type": XlmAddrTypes.pubKey});
      return StellarMuxedAddress._(
          address: address, accountId: accountId, baseAddress: baseAddress);
    } catch (e) {
      throw StellarAddressException("Invalid publick key.",
          details: {"stack": e.toString()});
    }
  }
  factory StellarMuxedAddress(String address) {
    try {
      final decode = XlmAddrDecoder().decode(address);
      if (decode.type != XlmAddrTypes.muxed) {
        throw StellarAddressException(
            "Use `StellarBaseAddress` instead `StellarMuxedAddress` for base address.");
      }
      return StellarMuxedAddress._(
          address: address,
          accountId: decode.accountId!,
          baseAddress: decode.baseAddress);
    } on StellarAddressException {
      rethrow;
    } catch (e) {
      throw StellarAddressException("Invalid stellar Muex address.",
          details: {"stack": e.toString()});
    }
  }
}
