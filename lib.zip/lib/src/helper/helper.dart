import 'package:blockchain_utils/utils/numbers/numbers.dart';
import 'package:stellar_dart/src/constants/constant.dart';

class StellarHelper {
  static final BigRational _lumenDecimalRational =
      BigRational(BigInt.from(10).pow(StellarConst.lumenDecimal));

  static BigInt toStroop(String ton) {
    final parse = BigRational.parseDecimal(ton);
    return (parse * _lumenDecimalRational).toBigInt();
  }

  static String fromStroop(BigInt nanotons) {
    final parse = BigRational(nanotons);
    return (parse / _lumenDecimalRational)
        .toDecimal(digits: StellarConst.lumenDecimal);
  }
}
