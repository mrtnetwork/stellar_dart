import 'package:blockchain_utils/utils/string/string.dart';
import 'package:stellar_dart/src/exception/exception.dart';

class StellarUtils {
  static List<int> toAlphanumAssetCode(
      {required String code, required int length}) {
    final codeBytes = StringUtils.encode(code);
    if (code.length > length) {
      throw DartStellarPlugingException("Invalid asset code length.", details: {
        "excepted": length,
        "length": codeBytes.length,
        "code": code
      });
    }
    final toBytes = List<int>.filled(length, 0);
    toBytes.setAll(0, codeBytes);
    return toBytes;
  }
}
