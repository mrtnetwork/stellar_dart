import 'package:blockchain_utils/helper/extensions/extensions.dart';
import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/exception/exception.dart';

class StellarValidator {
  static List<int> validateBytes(
      {required List<int> bytes, required int length}) {
    if (bytes.length != length) {
      throw DartStellarPlugingException("Incorrect bytes length.",
          details: {"excepted": length, "length": length});
    }
    return bytes.asImmutableBytes;
  }

  static String validateAssetCode(String code, {int? length}) {
    if (!StellarConst.assetCodeRegEx.hasMatch(code)) {
      throw DartStellarPlugingException("Incorrect asset code.",
          details: {"code": code});
    }
    length ??= StellarConst.assetMaximumCodeLength;
    if (code.length > length) {
      throw DartStellarPlugingException("Invalid  assets code length.",
          details: {"maximum": length, "length": code.length, "code": code});
    }
    return code;
  }
}

extension ListValidator<T> on List<T> {
  List<T> max(int length, {String? name}) {
    if (this.length > length) {
      throw DartStellarPlugingException(
          "Incorrect ${name == null ? '' : '$name '}array length.",
          details: {"maximum": length, "length": this.length});
    }
    return this;
  }

  List<T> min(int length, {String? name}) {
    if (this.length < length) {
      throw DartStellarPlugingException(
          "Incorrect ${name == null ? '' : '$name '}array length.",
          details: {"minimum": length, "length": this.length});
    }
    return this;
  }

  List<T> exc(int length, {String? name}) {
    if (this.length != length) {
      throw DartStellarPlugingException(
          "Incorrect ${name == null ? '' : '$name '}array length.",
          details: {"excepted": length, "length": this.length});
    }
    return this;
  }
}

extension StringValidator on String {
  String max(int length, {String? name}) {
    if (this.length > length) {
      throw DartStellarPlugingException(
          "Incorrect ${name == null ? '' : '$name '}array length.",
          details: {"maximum": length, "length": this.length});
    }
    return this;
  }

  String min(int length, {String? name}) {
    if (this.length < length) {
      throw DartStellarPlugingException(
          "Incorrect ${name == null ? '' : '$name '}array length.",
          details: {"minimum": length, "length": this.length});
    }
    return this;
  }

  String exc(int length, {String? name}) {
    if (this.length != length) {
      throw DartStellarPlugingException(
          "Incorrect ${name == null ? '' : '$name '}array length.",
          details: {"excepted": length, "length": this.length});
    }
    return this;
  }
}
