class StellarConst {
  static const int hash256Length = 32;
  static const int payloadLength = 64;
  static const int ed25519PubKeyLength = 32;
  static const int assetMaximumCodeLength = 12;
  static final assetCodeRegEx = RegExp(r'^[a-zA-Z0-9]{1,12}$');
  static const int lumenDecimal = 7;
}
