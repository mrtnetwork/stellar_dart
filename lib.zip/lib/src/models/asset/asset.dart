import 'package:blockchain_utils/layout/constant/constant.dart';
import 'package:blockchain_utils/layout/core/core/core.dart';
import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/exception/exception.dart';
import 'package:stellar_dart/src/keypair/keypair.dart';
import 'package:stellar_dart/src/serialization/serialization.dart';
import 'package:stellar_dart/src/utils/utils.dart';
import 'package:stellar_dart/src/utils/validator.dart';

class _StellarAssetConst {
  static const int creditAlphanum4Length = 4;
  static const int creditAlphanum12Length = 12;
}

class AssetType {
  final int value;
  final String name;
  const AssetType._({required this.value, required this.name});

  static const AssetType native = AssetType._(value: 0, name: "Native");
  static const AssetType creditAlphanum4 =
      AssetType._(name: "CreditAlphanum4", value: 1);
  static const AssetType creditAlphanum12 =
      AssetType._(value: 2, name: "CreditAlphanum12");
  static const AssetType poolShare = AssetType._(value: 3, name: "PoolShare");

  static const List<AssetType> values = [
    native,
    creditAlphanum4,
    creditAlphanum12,
    poolShare
  ];

  @override
  String toString() {
    return "AssetType.$name";
  }
}

abstract class StellarAsset<T> extends XDRVariantSerialization<T> {
  final AssetType type;
  const StellarAsset({required this.type});
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be(
        List.generate(AssetType.values.length, (index) {
          final type = AssetType.values.elementAt(index);
          switch (type) {
            case AssetType.native:
              return StellarAssetNative.layout(property: type.name);
            case AssetType.creditAlphanum12:
              return StellarAssetCreditAlphanum12.layout(property: type.name);
            case AssetType.creditAlphanum4:
              return StellarAssetCreditAlphanum4.layout(property: type.name);
            case AssetType.poolShare:
              return StellarAssetPoolShare.layout(property: type.name);
            default:
              throw DartStellarPlugingException("Invalid AssetType.");
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class StellarAssetCreditAlphanum4 extends StellarAsset<Map<String, dynamic>> {
  StellarAssetCreditAlphanum4._({required this.issuer, required this.code})
      : super(type: AssetType.creditAlphanum4);
  factory StellarAssetCreditAlphanum4(
      {required StellarPublicKey issuer, required String code}) {
    return StellarAssetCreditAlphanum4._(
        issuer: issuer,
        code: StellarValidator.validateAssetCode(code,
            length: _StellarAssetConst.creditAlphanum4Length));
  }
  final StellarPublicKey issuer;
  final String code;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(_StellarAssetConst.creditAlphanum4Length,
          property: "code"),
      StellarPublicKey.layout(property: "issuer"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "issuer": issuer.toLayoutStruct(),
      "code": StellarUtils.toAlphanumAssetCode(
          code: code, length: _StellarAssetConst.creditAlphanum4Length)
    };
  }
}

class StellarAssetCreditAlphanum12 extends StellarAsset<Map<String, dynamic>> {
  StellarAssetCreditAlphanum12._({required this.issuer, required this.code})
      : super(type: AssetType.creditAlphanum12);
  factory StellarAssetCreditAlphanum12(
      {required StellarPublicKey issuer, required String code}) {
    return StellarAssetCreditAlphanum12._(
        issuer: issuer,
        code: StellarValidator.validateAssetCode(code,
            length: _StellarAssetConst.creditAlphanum12Length));
  }
  final StellarPublicKey issuer;
  final String code;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(_StellarAssetConst.creditAlphanum12Length,
          property: "code"),
      StellarPublicKey.layout(property: "issuer"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "issuer": issuer.toLayoutStruct(),
      "code": StellarUtils.toAlphanumAssetCode(
          code: code, length: _StellarAssetConst.creditAlphanum12Length)
    };
  }
}

class StellarAssetNative extends StellarAsset<void> {
  StellarAssetNative() : super(type: AssetType.native);
  final String code = "XLM";
  static Layout<void> layout({String? property}) {
    return LayoutConst.none(property: property);
  }

  @override
  Layout<void> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  void toLayoutStruct() {}
}

/// should not be used in some models
class StellarAssetPoolShare extends StellarAsset<List<int>> {
  final List<int> poolID;
  StellarAssetPoolShare(List<int> poolID)
      : poolID = StellarValidator.validateBytes(
            bytes: poolID, length: StellarConst.hash256Length),
        super(type: AssetType.poolShare);
  static Layout<List<int>> layout({String? property}) {
    return LayoutConst.fixedBlob32(property: property);
  }

  @override
  Layout<List<int>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  List<int> toLayoutStruct() {
    return poolID;
  }
}
