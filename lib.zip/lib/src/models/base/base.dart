// class PreconditionType {
//   final String name;
//   final int value;

//   const PreconditionType._(this.name, this.value);

//   static const PreconditionType precondNone =
//       PreconditionType._('precondNone', 0);
//   static const PreconditionType precondTime =
//       PreconditionType._('precondTime', 1);
//   static const PreconditionType precondV2 = PreconditionType._('precondV2', 2);

//   static const List<PreconditionType> values = [
//     precondNone,
//     precondTime,
//     precondV2
//   ];
// }

// // class ClaimAtomType {
// //   final String name;
// //   final int value;

// //   const ClaimAtomType._(this.name, this.value);

// //   static const ClaimAtomType claimAtomTypeV0 =
// //       ClaimAtomType._('claimAtomTypeV0', 0);
// //   static const ClaimAtomType claimAtomTypeOrderBook =
// //       ClaimAtomType._('claimAtomTypeOrderBook', 1);
// //   static const ClaimAtomType claimAtomTypeLiquidityPool =
// //       ClaimAtomType._('claimAtomTypeLiquidityPool', 2);
// //   static const List<ClaimAtomType> values = [
// //     claimAtomTypeV0,
// //     claimAtomTypeOrderBook,
// //     claimAtomTypeLiquidityPool
// //   ];
// // }
