import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/serialization/serialization.dart';
import 'package:stellar_dart/src/utils/validator.dart';

class SignerKeyType {
  final String name;
  final int value;

  const SignerKeyType._(this.name, this.value);

  static const SignerKeyType ed25519 = SignerKeyType._('ed25519', 0);
  static const SignerKeyType preAuthTx = SignerKeyType._('preAuthTx', 1);
  static const SignerKeyType hashX = SignerKeyType._('hashX', 2);
  static const SignerKeyType ed25519SignedPayload =
      SignerKeyType._('ed25519SignedPayload', 3);
  static const List<SignerKeyType> values = [
    ed25519,
    preAuthTx,
    hashX,
    ed25519SignedPayload
  ];
  @override
  String toString() {
    return "SignerKeyType.$name";
  }
}

abstract class SignerKey<T> extends XDRVariantSerialization<T> {
  final SignerKeyType type;
  const SignerKey({required this.type});
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be(
        List.generate(SignerKeyType.values.length, (index) {
          final type = SignerKeyType.values.elementAt(index);
          switch (type) {
            case SignerKeyType.ed25519:
              return SignerKeyEd25519.layout(property: type.name);
            case SignerKeyType.hashX:
              return SignerKeyHashX.layout(property: type.name);
            case SignerKeyType.preAuthTx:
              return SignerKeyPreAuthTx.layout(property: type.name);
            case SignerKeyType.ed25519SignedPayload:
              return SignerKeyEd25519.layout(property: type.name);
            default:
              throw UnimplementedError("Invalid SignerKeyType.");
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class SignerKeyEd25519SignedPayload extends SignerKey<Map<String, dynamic>> {
  SignerKeyEd25519SignedPayload(
      {required List<int> ed25519, required List<int> payload})
      : ed25519 = StellarValidator.validateBytes(
            bytes: payload, length: StellarConst.ed25519PubKeyLength),
        payload = StellarValidator.validateBytes(
            bytes: payload, length: StellarConst.payloadLength),
        super(type: SignerKeyType.ed25519SignedPayload);
  final List<int> ed25519;
  final List<int> payload;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.ed25519PubKeyLength,
          property: "ed25519"),
      LayoutConst.fixedBlob32(property: "payload"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"ed25519": ed25519, "payload": payload};
  }
}

class SignerKeyEd25519 extends SignerKey<List<int>> {
  SignerKeyEd25519(List<int> data)
      : ed25519 = StellarValidator.validateBytes(
            bytes: data, length: StellarConst.ed25519PubKeyLength),
        super(type: SignerKeyType.ed25519);
  final List<int> ed25519;
  static Layout<List<int>> layout({String? property}) {
    return LayoutConst.fixedBlob32(property: property);
  }

  @override
  Layout<List<int>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  List<int> toLayoutStruct() {
    return ed25519;
  }
}

class SignerKeyPreAuthTx extends SignerKey<List<int>> {
  SignerKeyPreAuthTx(List<int> data)
      : preAuthTx = StellarValidator.validateBytes(
            bytes: data, length: StellarConst.hash256Length),
        super(type: SignerKeyType.preAuthTx);
  final List<int> preAuthTx;
  static Layout<List<int>> layout({String? property}) {
    return LayoutConst.fixedBlob32(property: property);
  }

  @override
  Layout<List<int>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  List<int> toLayoutStruct() {
    return preAuthTx;
  }
}

class SignerKeyHashX extends SignerKey<List<int>> {
  SignerKeyHashX(List<int> hashX)
      : hashX = StellarValidator.validateBytes(
            bytes: hashX, length: StellarConst.hash256Length),
        super(type: SignerKeyType.hashX);
  final List<int> hashX;
  static Layout<List<int>> layout({String? property}) {
    return LayoutConst.fixedBlob32(property: property);
  }

  @override
  Layout<List<int>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  List<int> toLayoutStruct() {
    return hashX;
  }
}

class Signer extends XDRSerialization<Map<String, dynamic>> {
  final SignerKey key;
  final int weight;
  Signer({required this.key, required int weight}) : weight = weight.asUint32;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      SignerKey.layout(property: "key"),
      LayoutConst.u32be(property: "weight")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"key": key.toVariantLayoutStruct(), "weight": weight};
  }
}
