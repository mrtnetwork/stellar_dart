import 'package:blockchain_utils/blockchain_utils.dart';

class MemoType {
  final String name;
  final int value;

  const MemoType._(this.name, this.value);

  static const MemoType memoNone = MemoType._('memoNone', 0);
  static const MemoType memoText = MemoType._('memoText', 1);
  static const MemoType memoId = MemoType._('memoId', 2);
  static const MemoType memoHash = MemoType._('memoHash', 3);
  static const MemoType memoReturn = MemoType._('memoReturn', 4);
  static List<MemoType> values = [
    memoNone,
    memoText,
    memoId,
    memoHash,
    memoReturn
  ];
}
// class Memo {
//   switch(): MemoType;

//   text(value?: string | Buffer): string | Buffer;

//   id(value?: Uint64): Uint64;

//   hash(value?: Buffer): Buffer;

//   retHash(value?: Buffer): Buffer;
abstract class StellarMemo {
  final MemoType type;
  const StellarMemo({required this.type});
}

class StellerReturnHash extends StellarMemo {
  final List<int> data;

  StellerReturnHash(List<int> data)
      : data = BytesUtils.toBytes(data, unmodifiable: true),
        super(type: MemoType.memoReturn);
}

class StellerMemoHash extends StellarMemo {
  final List<int> data;

  StellerMemoHash(List<int> data)
      : data = BytesUtils.toBytes(data, unmodifiable: true),
        super(type: MemoType.memoHash);
}

class StellerMemoID extends StellarMemo {
  final BigInt id;

  const StellerMemoID(this.id) : super(type: MemoType.memoId);
}

class StellerMemoText extends StellarMemo {
  final String text;

  const StellerMemoText(this.text) : super(type: MemoType.memoText);
}
