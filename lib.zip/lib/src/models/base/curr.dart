import 'package:blockchain_utils/bip/address/encoders.dart';
import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:blockchain_utils/helper/helper.dart';
import 'package:blockchain_utils/layout/core/types/lazy_union.dart';
import 'package:stellar_dart/src/address/address.dart';
import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/exception/exception.dart';
import 'package:stellar_dart/src/keypair/keypair.dart';
import 'package:stellar_dart/src/models/asset/asset.dart';
import 'package:stellar_dart/src/models/hash/hash.dart';
import 'package:stellar_dart/src/serialization/serialization.dart';
import 'package:stellar_dart/src/utils/validator.dart';
import 'signer.dart';

class LedgerEntryType {
  final String name;
  final int value;
  const LedgerEntryType._(this.name, this.value);

  static const LedgerEntryType account = LedgerEntryType._('account', 0);
  static const LedgerEntryType trustline = LedgerEntryType._('trustline', 1);
  static const LedgerEntryType offer = LedgerEntryType._('offer', 2);
  static const LedgerEntryType data = LedgerEntryType._('data', 3);
  static const LedgerEntryType claimableBalance =
      LedgerEntryType._('claimableBalance', 4);
  static const LedgerEntryType liquidityPool =
      LedgerEntryType._('liquidityPool', 5);
  static const LedgerEntryType contractData =
      LedgerEntryType._('contractData', 6);
  static const LedgerEntryType contractCode =
      LedgerEntryType._('contractCode', 7);
  static const LedgerEntryType configSetting =
      LedgerEntryType._('configSetting', 8);
  static const LedgerEntryType ttl = LedgerEntryType._('ttl', 9);
  static const List<LedgerEntryType> values = [
    account,
    trustline,
    offer,
    data,
    claimableBalance,
    liquidityPool,
    contractData,
    contractCode,
    configSetting,
    ttl
  ];
  @override
  String toString() {
    return "LedgerEntryType.$name";
  }
}

abstract class LedgerEntryData<T> {
  final LedgerEntryType type;
  const LedgerEntryData(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    throw UnimplementedError();
  }

  // @override
  // Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
  //   throw UnimplementedError();
  // }

  // @override
  // String get variantName => type.name;
}

abstract class ExtPoint {
  abstract final int value;
  const ExtPoint();
}

class Liabilities {
  final BigInt buying;
  final BigInt selling;
  Liabilities({required BigInt buying, required BigInt selling})
      : buying = buying.asInt64,
        selling = selling.asInt64;
}

class AccountEntry extends LedgerEntryData {
  final StellarBaseAddress accountId;
  final BigInt balance;
  final BigInt seqNum;
  final int numSubEntries;
  final StellarBaseAddress? inflationDest;
  final int flags;
  final List<int> homeDomain;
  final List<int> thresholds;
  final List<Signer> signers;
  final AccountEntryExt ext;

  AccountEntry(
      {required this.accountId,
      required BigInt balance,
      required BigInt seqNum,
      required int numSubEntries,
      this.inflationDest,
      required int flags,
      required List<int> homeDomain,
      required List<int> thresholds,
      required List<Signer> signers,
      required this.ext})
      : homeDomain = homeDomain.asImmutableBytes,
        thresholds = thresholds.asImmutableBytes,
        signers = signers.immutable,
        balance = balance.asInt64,
        seqNum = seqNum.asInt64,
        flags = flags.asUint32,
        numSubEntries = numSubEntries.asUint32,
        super(LedgerEntryType.account);
}

abstract class ExtentionPoint<T, E> extends XDRVariantSerialization<T> {
  final int id;
  final E value;
  const ExtentionPoint({required this.id, required this.value});
  @override
  String get variantName => "$id";
}

class ExtentionPointVoid extends ExtentionPoint<Map<String, dynamic>, Null> {
  ExtentionPointVoid() : super(id: 0, value: null);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([LayoutConst.none(property: "0")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return LayoutConst.noArgs(property: "0");
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class AccountEntryExtensionV3 {
  final int seqLedger;
  final BigInt seqTime;
  AccountEntryExtensionV3({
    required this.seqLedger,
    required BigInt seqTime,
  }) : seqTime = seqTime.asUint64;
}

class AccountEntryExtensionV2Ext extends ExtPoint {
  final AccountEntryExtensionV3? ext;
  const AccountEntryExtensionV2Ext(this.ext);

  @override
  int get value => ext == null ? 0 : 3;
}

class AccountEntryExtensionV2 {
  final int numSponsored;
  final int numSponsoring;
  final List<StellarBaseAddress?> signerSponsoringIDs;
  final AccountEntryExtensionV2Ext ext;
  AccountEntryExtensionV2({
    required int numSponsored,
    required int numSponsoring,
    List<StellarBaseAddress?> signerSponsoringIDs = const [],
    required this.ext,
  })  : numSponsored = numSponsored.asUint32,
        numSponsoring = numSponsoring.asUint32,
        signerSponsoringIDs = signerSponsoringIDs.immutable;
}

class AccountEntryExtensionV1Ext extends ExtPoint {
  final AccountEntryExtensionV2? ext;
  const AccountEntryExtensionV1Ext(this.ext);

  @override
  int get value => ext == null ? 0 : 2;
}

class AccountEntryExtensionV1 {
  final Liabilities liabilities;
  final AccountEntryExtensionV1Ext ext;
  const AccountEntryExtensionV1({required this.liabilities, required this.ext});
}

class AccountEntryExt extends ExtPoint {
  final AccountEntryExtensionV1? ext;
  const AccountEntryExt(this.ext);

  @override
  int get value => ext == null ? 0 : 1;
}

class TrustLineEntryExtensionV2Ext extends ExtPoint {
  const TrustLineEntryExtensionV2Ext();
  @override
  int get value => 0;
}
//  class TrustLineEntryExtensionV2 {
//     constructor(attributes: {
//       liquidityPoolUseCount: number;
//       ext: TrustLineEntryExtensionV2Ext;
//     });

class TrustLineEntryExtensionV2 {
  final int liquidityPoolUseCount;
  final TrustLineEntryExtensionV2Ext ext;
  TrustLineEntryExtensionV2(
      {required int liquidityPoolUseCount,
      this.ext = const TrustLineEntryExtensionV2Ext()})
      : liquidityPoolUseCount = liquidityPoolUseCount.asInt32;
}

class TrustLineEntryV1Ext extends ExtPoint {
  final TrustLineEntryExtensionV2? ext;
  const TrustLineEntryV1Ext(this.ext);

  @override
  int get value => ext == null ? 0 : 2;
}

class TrustLineEntryV1 {
  final Liabilities liabilities;
  final TrustLineEntryV1Ext ext;
  const TrustLineEntryV1({required this.liabilities, required this.ext});
}

class TrustLineEntryExt extends ExtPoint {
  final TrustLineEntryV1? ext;
  const TrustLineEntryExt(this.ext);
  @override
  int get value => ext == null ? 0 : 1;
}

/// accept poolId
typedef TrustLineAsset = StellarAsset;

class TrustLineEntry extends LedgerEntryData {
  final StellarPublicKey accountId;
  final TrustLineAsset asset;
  final BigInt balance;
  final BigInt limit;
  final int flags;
  final TrustLineEntryExt ext;
  TrustLineEntry(
      {required this.accountId,
      required this.asset,
      required BigInt balance,
      required BigInt limit,
      required int flags,
      required this.ext})
      : balance = balance.asInt64,
        limit = limit.asInt64,
        flags = flags.asUint32,
        super(LedgerEntryType.trustline);
}

class OfferEntryExt extends ExtPoint {
  @override
  int get value => 0;
}

class StellarPrice extends XDRSerialization<Map<String, dynamic>> {
  final int numerator;
  final int denominator;
  StellarPrice({required int numerator, required int denominator})
      : numerator = numerator.asInt32,
        denominator = denominator.asInt32;

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s32be(property: "numerator"),
      LayoutConst.s32be(property: "denominator"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"numerator": numerator, "denominator": denominator};
  }
}

class OfferEntry extends LedgerEntryData {
  final StellarBaseAddress sellerId;
  final BigInt offerId;
  final StellarAsset selling;
  final StellarAsset buying;
  final BigInt amount;
  final StellarPrice price;
  final int flags;
  final OfferEntryExt ext;
  OfferEntry(
      {required this.sellerId,
      required BigInt offerId,
      required this.selling,
      required this.buying,
      required BigInt amount,
      required this.price,
      required int flags,
      required this.ext})
      : offerId = offerId.asInt64,
        amount = amount.asInt64,
        flags = flags.asUint32,
        super(LedgerEntryType.offer);
}

class DataEntryExt extends ExtPoint {
  @override
  int get value => 0;
}

class DataEntry extends LedgerEntryData {
  final StellarAddress accountId;
  final List<int> dataName;
  final List<int> dataValue;
  final DataEntryExt ext;
  DataEntry(
      {required this.accountId,
      required List<int> dataName,
      required List<int> dataValue,
      required this.ext})
      : dataName = dataName.asImmutableBytes,
        dataValue = dataValue.asImmutableBytes,
        super(LedgerEntryType.data);
}

class ClaimableBalanceEntryExtensionV1Ext extends ExtPoint {
  @override
  int get value => 0;
}

class ClaimableBalanceEntryExtensionV1 {
  final ClaimableBalanceEntryExtensionV1Ext ext;
  final int flags;
  ClaimableBalanceEntryExtensionV1({required this.ext, required int flags})
      : flags = flags.asUint32;
}

class ClaimableBalanceEntryExt extends ExtPoint {
  final ClaimableBalanceEntryExtensionV1? ext;
  const ClaimableBalanceEntryExt(this.ext);

  @override
  int get value => ext == null ? 0 : 1;
}

class ClaimableBalanceIdType {
  final String name;
  final int value;
  const ClaimableBalanceIdType._({required this.name, required this.value});
  static const ClaimableBalanceIdType v0 =
      ClaimableBalanceIdType._(name: "V0", value: 0);
  @override
  String toString() {
    return "ClaimableBalanceIdType.$name";
  }
}

abstract class ClaimableBalanceId<T> extends XDRVariantSerialization<T> {
  final ClaimableBalanceIdType type;
  const ClaimableBalanceId(this.type);
  @override
  String get variantName => type.name;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be(
        [ClaimableBalanceIdV0.layout(property: ClaimableBalanceIdType.v0.name)],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }
}

class ClaimableBalanceIdV0 extends ClaimableBalanceId<Map<String, dynamic>> {
  final List<int> hash;
  ClaimableBalanceIdV0(List<int> hash)
      : hash = hash.asImmutableBytes.exc(StellarConst.hash256Length),
        super(ClaimableBalanceIdType.v0);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "hash")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hash": hash};
  }
}

class ClaimantType {
  final String name;
  final int value;
  const ClaimantType._({required this.name, required this.value});
  static const ClaimantType v0 = ClaimantType._(name: "V0", value: 0);
  @override
  String toString() {
    return "ClaimantType.$name";
  }
}

abstract class Claimant<T> extends XDRVariantSerialization<T> {
  final ClaimantType type;
  const Claimant(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      ClaimantV0.layout(property: ClaimantType.v0.name),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ClaimantV0 extends Claimant<Map<String, dynamic>> {
  final ClaimPredicate predicate;
  const ClaimantV0(this.predicate) : super(ClaimantType.v0);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ClaimPredicate.layout(property: "predicate")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"predicate": predicate.toVariantLayoutStruct()};
  }
}

class ClaimPredicateType {
  final String name;
  final int value;
  const ClaimPredicateType._({required this.name, required this.value});
  static const ClaimPredicateType unconditional =
      ClaimPredicateType._(name: "Unconditional", value: 0);
  static const ClaimPredicateType and =
      ClaimPredicateType._(name: "And", value: 1);
  static const ClaimPredicateType or =
      ClaimPredicateType._(name: "Or", value: 2);
  static const ClaimPredicateType not =
      ClaimPredicateType._(name: "Not", value: 3);
  static const ClaimPredicateType beforeAbsoluteTime =
      ClaimPredicateType._(name: "BeforeAbsoluteTime", value: 4);
  static const ClaimPredicateType beforeRelativeTime =
      ClaimPredicateType._(name: "BeforeRelativeTime", value: 5);
  static const List<ClaimPredicateType> values = [
    unconditional,
    and,
    or,
    not,
    beforeAbsoluteTime,
    beforeRelativeTime
  ];
  @override
  String toString() {
    return "ClaimPredicateType.$name";
  }
}

abstract class ClaimPredicate<T> extends XDRVariantSerialization<T> {
  final ClaimPredicateType type;
  const ClaimPredicate(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnumU32Be(
        List.generate(ClaimPredicateType.values.length, (index) {
          final type = ClaimPredicateType.values.elementAt(index);
          print("come $type");
          switch (type) {
            case ClaimPredicateType.unconditional:
              return LazyLayout(
                  layout: ClaimPredicateUnconditional.layout,
                  property: type.name);
            case ClaimPredicateType.and:
              return LazyLayout(
                  layout: ClaimPredicateAnd.layout, property: type.name);
            case ClaimPredicateType.or:
              return LazyLayout(
                  layout: ClaimPredicateOr.layout, property: type.name);
            case ClaimPredicateType.not:
              return LazyLayout(
                  layout: ClaimPredicateNot.layout, property: type.name);
            case ClaimPredicateType.beforeAbsoluteTime:
              return LazyLayout(
                  layout: ClaimPredicateBeforeAbsoluteTime.layout,
                  property: type.name);
            case ClaimPredicateType.beforeRelativeTime:
              return LazyLayout(
                  layout: ClaimPredicateBeforeRelativeTime.layout,
                  property: type.name);

            default:
              throw DartStellarPlugingException("Invalid ClaimPredicate type.");
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ClaimPredicateUnconditional extends ClaimPredicate<void> {
  const ClaimPredicateUnconditional() : super(ClaimPredicateType.unconditional);

  static Layout<void> layout({String? property}) {
    return LayoutConst.none(property: property);
  }

  @override
  Layout<void> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  void toLayoutStruct() {}
}

class ClaimPredicateAnd extends ClaimPredicate<Map<String, dynamic>> {
  final List<ClaimPredicate> andPredicates;
  ClaimPredicateAnd(List<ClaimPredicate> value)
      : andPredicates = value.immutable.max(2, name: "ClaimPredicate"),
        super(ClaimPredicateType.and);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.xdrVec(ClaimPredicate.layout(), property: "andPredicates")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "andPredicates":
          andPredicates.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

class ClaimPredicateOr extends ClaimPredicate<Map<String, dynamic>> {
  final List<ClaimPredicate> orPredicates;
  ClaimPredicateOr(List<ClaimPredicate> orPredicates)
      : orPredicates = orPredicates.immutable.max(2, name: "ClaimPredicate"),
        super(ClaimPredicateType.or);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [LayoutConst.xdrVec(ClaimPredicate.layout(), property: "orPredicates")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "orPredicates":
          orPredicates.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

class ClaimPredicateNot extends ClaimPredicate {
  final ClaimPredicate? notPredicate;
  ClaimPredicateNot(this.notPredicate) : super(ClaimPredicateType.not);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.optionalU32Be(ClaimPredicate.layout(),
          property: "notPredicate")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"notPredicate": notPredicate?.toVariantLayoutStruct()};
  }
}

class ClaimPredicateBeforeAbsoluteTime extends ClaimPredicate {
  final BigInt absBefore;
  ClaimPredicateBeforeAbsoluteTime(BigInt absBefore)
      : absBefore = absBefore.asInt64,
        super(ClaimPredicateType.beforeAbsoluteTime);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.s64be(property: "absBefore")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"absBefore": absBefore};
  }
}

class ClaimPredicateBeforeRelativeTime extends ClaimPredicate {
  final BigInt relBefore;
  ClaimPredicateBeforeRelativeTime(BigInt relBefore)
      : relBefore = relBefore.asInt64,
        super(ClaimPredicateType.beforeRelativeTime);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.s64be(property: "relBefore")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"relBefore": relBefore};
  }
}

class ClaimableBalanceEntry extends LedgerEntryData {
  final ClaimableBalanceId balanceId;
  final List<Claimant> claimants;
  final StellarAsset asset;
  final BigInt amount;
  final ClaimableBalanceEntryExt ext;
  ClaimableBalanceEntry(
      {required this.balanceId,
      required List<Claimant> claimants,
      required this.asset,
      required BigInt amount,
      required this.ext})
      : claimants = claimants.immutable,
        amount = amount.asInt64,
        super(LedgerEntryType.claimableBalance);
}

class LiquidityPoolType {
  final int value;
  final String name;
  const LiquidityPoolType._({required this.value, required this.name});
  static const LiquidityPoolType liquidityPoolConstantProduct =
      LiquidityPoolType._(name: "liquidityPoolConstantProduct", value: 0);

  @override
  String toString() {
    return "LiquidityPoolType.$name";
  }
}

abstract class LiquidityPoolEntryBody {
  final LiquidityPoolType type;
  const LiquidityPoolEntryBody(this.type);
}

class LiquidityPoolConstantProductParameters {
  final StellarAsset assetA;
  final StellarAsset assetB;
  final int fee;
  LiquidityPoolConstantProductParameters(
      {required this.assetA, required this.assetB, required int fee})
      : fee = fee.asInt32;
}

class LiquidityPoolEntryConstantProduct extends LiquidityPoolEntryBody {
  final LiquidityPoolConstantProductParameters param;
  final BigInt reserveA;
  final BigInt reserveB;
  final BigInt totalPoolShares;
  final BigInt poolSharesTrustLineCount;
  LiquidityPoolEntryConstantProduct(
      {required this.param,
      required BigInt reserveA,
      required BigInt reserveB,
      required BigInt totalPoolShares,
      required BigInt poolSharesTrustLineCount})
      : reserveA = reserveA.asInt64,
        reserveB = reserveB.asInt64,
        totalPoolShares = totalPoolShares.asInt64,
        poolSharesTrustLineCount = poolSharesTrustLineCount.asInt64,
        super(LiquidityPoolType.liquidityPoolConstantProduct);
}

class LiquidityPoolEntry extends LedgerEntryData {
  final Hash256 liquidityPoolId;
  final LiquidityPoolEntryBody body;
  const LiquidityPoolEntry({required this.liquidityPoolId, required this.body})
      : super(LedgerEntryType.liquidityPool);
}

class ScAddressType {
  final String name;
  final int value;
  const ScAddressType._({required this.name, required this.value});
  static const ScAddressType account =
      ScAddressType._(name: "account", value: 0);
  static const ScAddressType contract =
      ScAddressType._(name: "contract", value: 1);
  @override
  String toString() {
    return "ScAddressType.$name";
  }
}

abstract class ScAddress extends XDRVariantSerialization<Map<String, dynamic>> {
  final ScAddressType type;
  const ScAddress(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      ScAddressAccountId.layout(property: ScAddressType.account.name),
      ScAddressContract.layout(property: ScAddressType.contract.name)
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ScAddressAccountId extends ScAddress {
  final StellarPublicKey accountId;
  const ScAddressAccountId(this.accountId) : super(ScAddressType.account);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([StellarPublicKey.layout(property: "accountId")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"accountId": accountId.toLayoutStruct()};
  }
}

class ScAddressContract extends ScAddress {
  final List<int> contractId;
  ScAddressContract(List<int> contractId)
      : contractId =
            contractId.asImmutableBytes.max(StellarConst.hash256Length),
        super(ScAddressType.contract);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "contractId")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"contractId": contractId};
  }
}

class ScValueType {
  final String name;
  final int value;

  const ScValueType._({required this.name, required this.value});

  static const boolType = ScValueType._(name: 'Bool', value: 0);
  static const voidType = ScValueType._(name: 'Void', value: 1);
  static const error = ScValueType._(name: 'Error', value: 2);
  static const u32 = ScValueType._(name: 'U32', value: 3);
  static const i32 = ScValueType._(name: 'I32', value: 4);
  static const u64 = ScValueType._(name: 'U64', value: 5);
  static const i64 = ScValueType._(name: 'I64', value: 6);
  static const timepoint = ScValueType._(name: 'Timepoint', value: 7);
  static const duration = ScValueType._(name: 'Duration', value: 8);
  static const u128 = ScValueType._(name: 'U128', value: 9);
  static const i128 = ScValueType._(name: 'I128', value: 10);
  static const u256 = ScValueType._(name: 'U256', value: 11);
  static const i256 = ScValueType._(name: 'I256', value: 112);
  static const bytes = ScValueType._(name: 'Bytes', value: 13);
  static const string = ScValueType._(name: 'String', value: 14);
  static const symbol = ScValueType._(name: 'Symbol', value: 15);
  static const vec = ScValueType._(name: 'Vec', value: 16);
  static const map = ScValueType._(name: 'Map', value: 17);
  static const address = ScValueType._(name: 'Address', value: 18);
  static const contractInstance =
      ScValueType._(name: 'ContractInstance', value: 19);
  static const ledgerKeyContractInstance =
      ScValueType._(name: 'LedgerKeyContractInstance', value: 20);
  static const ledgerKeyNonce =
      ScValueType._(name: 'LedgerKeyNonce', value: 21);
  static const List<ScValueType> values = [
    boolType,
    voidType,
    error,
    u32,
    i32,
    u64,
    i64,
    timepoint,
    duration,
    u128,
    i128,
    u256,
    i256,
    bytes,
    string,
    symbol,
    vec,
    map,
    address,
    contractInstance,
    ledgerKeyContractInstance
  ];
  @override
  String toString() {
    return "ScValueType.$name";
  }
}

abstract class ScVal<T, E> extends XDRVariantSerialization<E> {
  final ScValueType type;
  final T value;
  const ScVal({required this.type, required this.value});
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be(
        List.generate(ScValueType.values.length, (index) {
          final type = ScValueType.values.elementAt(index);
          switch (type) {
            case ScValueType.boolType:
              return ScValBoolean.layout(property: type.name);
            case ScValueType.voidType:
              return ScValVoid.layout(property: type.name);
            case ScValueType.error:
              return ScValError.layout(property: type.name);
            case ScValueType.u32:
              return ScValU32.layout(property: type.name);
            case ScValueType.i32:
              return ScValI32.layout(property: type.name);
            case ScValueType.u64:
              return ScValU64.layout(property: type.name);
            case ScValueType.i64:
              return ScValI64.layout(property: type.name);
            case ScValueType.timepoint:
              return ScValTimePoint.layout(property: type.name);
            case ScValueType.duration:
              return ScValDuration.layout(property: type.name);
            case ScValueType.u128:
              return ScValU128.layout(property: type.name);
            case ScValueType.i128:
              return ScValI128.layout(property: type.name);
            case ScValueType.u256:
              return ScValU256.layout(property: type.name);
            case ScValueType.i256:
              return ScValI256.layout(property: type.name);
            case ScValueType.bytes:
              return ScValBytes.layout(property: type.name);
            case ScValueType.string:
              return ScValString.layout(property: type.name);
            case ScValueType.symbol:
              return ScValSymbol.layout(property: type.name);
            case ScValueType.vec:
              return ScValVec.layout(property: type.name);
            case ScValueType.map:
              return ScValMap.layout(property: type.name);
            case ScValueType.address:
              return ScValAddress.layout(property: type.name);
            case ScValueType.contractInstance:
              return ScValInstance.layout(property: type.name);
            case ScValueType.ledgerKeyContractInstance:
              return ScValKeyContractInstance.layout(property: type.name);
            case ScValueType.ledgerKeyNonce:
              return ScValNonceKey.layout(property: type.name);
            default:
              throw DartStellarPlugingException("Invalid ScVal type.");
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ScErrorType {
  final String name;
  final int value;

  const ScErrorType._({required this.name, required this.value});

  static const contract = ScErrorType._(name: 'Contract', value: 0);
  static const wasmVm = ScErrorType._(name: 'WasmVm', value: 1);
  static const context = ScErrorType._(name: 'Context', value: 2);
  static const storage = ScErrorType._(name: 'Storage', value: 3);
  static const object = ScErrorType._(name: 'Object', value: 4);
  static const crypto = ScErrorType._(name: 'Crypto', value: 5);
  static const events = ScErrorType._(name: 'Events', value: 6);
  static const budget = ScErrorType._(name: 'Budget', value: 7);
  static const valueType = ScErrorType._(name: 'Value', value: 8);
  static const auth = ScErrorType._(name: 'Auth', value: 9);
  static const List<ScErrorType> values = [
    contract,
    wasmVm,
    context,
    storage,
    object,
    crypto,
    events,
    budget,
    valueType,
    auth
  ];
  @override
  String toString() {
    return "ScErrorType.$name";
  }
}

abstract class ScError<T> extends XDRVariantSerialization<T> {
  final ScErrorType type;
  const ScError(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be(
        List.generate(ScErrorType.values.length, (index) {
          final type = ScErrorType.values.elementAt(index);
          switch (type) {
            case ScErrorType.contract:
              return ScErrorContract.layout(property: type.name);
            default:
              return ScErrorCode.layout(property: type.name);
          }
        }),
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Layout<T> createLayout({String? property}) {
    return LayoutConst.none(property: property) as Layout<T>;
  }

  @override
  String get variantName => type.name;
}

class ScErrorContract extends ScError<Map<String, dynamic>> {
  ScErrorContract(int contractCode)
      : contractCode = contractCode.asUint32,
        super(ScErrorType.contract);
  final int contractCode;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u32be(property: "contractCode"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"contractCode": contractCode};
  }
}

class ScErrorCode extends ScError<void> {
  ScErrorCode._(ScErrorType code) : super(code);
  factory ScErrorCode(ScErrorType code) {
    if (code == ScErrorType.contract) {
      throw DartStellarPlugingException(
          "Use `ScErrorContract` instead `ScErrorCode` for user-defined error code.");
    }
    return ScErrorCode._(code);
  }

  static Layout<void> layout({String? property}) {
    return LayoutConst.none(property: property);
  }

  @override
  Layout<void> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  void toLayoutStruct() {}
}

class ScValBoolean extends ScVal<bool, Map<String, dynamic>> {
  ScValBoolean(bool bool) : super(type: ScValueType.boolType, value: bool);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.boolean(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValError extends ScVal<ScError, Map<String, dynamic>> {
  ScValError(ScError value) : super(type: ScValueType.error, value: value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ScError.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "value": value.toVariantLayoutStruct(),
    };
  }
}

class ScValU32 extends ScVal<int, Map<String, dynamic>> {
  ScValU32(int value) : super(type: ScValueType.u32, value: value.asUint32);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u32be(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValI32 extends ScVal<int, Map<String, dynamic>> {
  ScValI32(int value) : super(type: ScValueType.i32, value: value.asInt32);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s32be(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValU64 extends ScVal<BigInt, Map<String, dynamic>> {
  ScValU64(BigInt value) : super(type: ScValueType.u64, value: value.asUint64);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValI64 extends ScVal<BigInt, Map<String, dynamic>> {
  ScValI64(BigInt value) : super(type: ScValueType.i64, value: value.asInt64);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s64be(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValTimePoint extends ScVal<BigInt, Map<String, dynamic>> {
  ScValTimePoint(BigInt value)
      : super(type: ScValueType.timepoint, value: value.asUint64);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class UInt128Parts extends XDRSerialization<Map<String, dynamic>> {
  final BigInt hi;
  final BigInt lo;
  UInt128Parts({required BigInt hi, required BigInt lo})
      : hi = hi.asUint64,
        lo = lo.asUint64;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "hi"),
      LayoutConst.u64be(property: "lo"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hi": hi, "lo": lo};
  }
}

class Int128Parts extends XDRSerialization<Map<String, dynamic>> {
  final BigInt hi;
  final BigInt lo;
  Int128Parts({required BigInt hi, required BigInt lo})
      : hi = hi.asInt64,
        lo = lo.asUint64;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s64be(property: "hi"),
      LayoutConst.u64be(property: "lo"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hi": hi, "lo": lo};
  }
}

class UInt256Parts extends XDRSerialization<Map<String, dynamic>> {
  final BigInt hiHi;
  final BigInt hiLo;
  final BigInt loHi;
  final BigInt loLo;
  UInt256Parts({
    required BigInt hiHi,
    required BigInt hiLo,
    required BigInt loHi,
    required BigInt loLo,
  })  : hiHi = hiHi.asUint64,
        hiLo = hiLo.asUint64,
        loHi = loHi.asUint64,
        loLo = loLo.asUint64;

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u64be(property: "hiHi"),
      LayoutConst.u64be(property: "hiLo"),
      LayoutConst.s64be(property: "loHi"),
      LayoutConst.u64be(property: "loLo"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hiHi": hiHi, "hiLo": hiLo, "loHi": loHi, "loLo": loLo};
  }
}

class Int256Parts extends XDRSerialization<Map<String, dynamic>> {
  final BigInt hiHi;
  final BigInt hiLo;
  final BigInt loHi;
  final BigInt loLo;
  Int256Parts({
    required BigInt hiHi,
    required BigInt hiLo,
    required BigInt loHi,
    required BigInt loLo,
  })  : hiHi = hiHi.asInt64,
        hiLo = hiLo.asUint64,
        loHi = loHi.asUint64,
        loLo = loLo.asUint64;

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s64be(property: "hiHi"),
      LayoutConst.u64be(property: "hiLo"),
      LayoutConst.s64be(property: "loHi"),
      LayoutConst.u64be(property: "loLo"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hiHi": hiHi, "hiLo": hiLo, "loHi": loHi, "loLo": loLo};
  }
}

class ScValDuration extends ScVal<BigInt, Map<String, dynamic>> {
  ScValDuration(BigInt value)
      : super(type: ScValueType.duration, value: value.asUint64);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.u64be(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValU128 extends ScVal<UInt128Parts, Map<String, dynamic>> {
  ScValU128(UInt128Parts value) : super(type: ScValueType.u128, value: value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([UInt128Parts.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValI128 extends ScVal<Int128Parts, Map<String, dynamic>> {
  ScValI128(Int128Parts value) : super(type: ScValueType.i128, value: value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([Int128Parts.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValU256 extends ScVal<UInt256Parts, Map<String, dynamic>> {
  ScValU256(UInt256Parts value) : super(type: ScValueType.u256, value: value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([UInt256Parts.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValI256 extends ScVal<Int256Parts, Map<String, dynamic>> {
  ScValI256(Int256Parts value) : super(type: ScValueType.i256, value: value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([Int256Parts.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValBytes extends ScVal<List<int>, Map<String, dynamic>> {
  ScValBytes(List<int> bytes)
      : super(type: ScValueType.bytes, value: bytes.asImmutableBytes);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.xdrVecBytes(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValString extends ScVal<String, Map<String, dynamic>> {
  ScValString(String str) : super(type: ScValueType.string, value: str);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.xdrString(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScValSymbol extends ScVal<String, Map<String, dynamic>> {
  ScValSymbol(String sym) : super(type: ScValueType.symbol, value: sym.max(32));
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.xdrString(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value};
  }
}

class ScMapEntry<K extends ScVal, V extends ScVal>
    extends XDRSerialization<Map<String, dynamic>> {
  final K key;
  final V value;
  const ScMapEntry(this.key, this.value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScVal.layout(property: "key"),
      ScVal.layout(property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "key": key.toVariantLayoutStruct(),
      "value": value.toVariantLayoutStruct()
    };
  }
}

class ScNonceKey extends XDRSerialization<Map<String, dynamic>> {
  final BigInt nonce;
  ScNonceKey(BigInt nonce) : nonce = nonce.asInt64;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([LayoutConst.s64be(property: "nonce")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"nonce": nonce};
  }
}

class ScValVec extends ScVal<List<ScVal>?, Map<String, dynamic>> {
  ScValVec({List<ScVal>? value})
      : super(type: ScValueType.vec, value: value?.immutable);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.xdrVec(ScVal.layout(), property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "value": value?.map((e) => e.toVariantLayoutStruct()).toList() ?? const []
    };
  }
}

class ScValMap extends ScVal<List<ScMapEntry>?, Map<String, dynamic>> {
  ScValMap({List<ScMapEntry>? value})
      : super(type: ScValueType.map, value: value?.immutable);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.xdrVec(ScMapEntry.layout(), property: "value"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "value": value?.map((e) => e.toLayoutStruct()).toList() ?? const [],
    };
  }
}

class ScValAddress extends ScVal<ScAddress, Map<String, dynamic>> {
  ScValAddress(ScAddress value)
      : super(type: ScValueType.address, value: value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ScAddress.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toVariantLayoutStruct()};
  }
}

class ScValNonceKey extends ScVal<ScNonceKey, Map<String, dynamic>> {
  ScValNonceKey(ScNonceKey value)
      : super(type: ScValueType.ledgerKeyNonce, value: value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ScNonceKey.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValInstance extends ScVal<ScContractInstance, Map<String, dynamic>> {
  ScValInstance(ScContractInstance value)
      : super(type: ScValueType.contractInstance, value: value);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ScContractInstance.layout(property: "value")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"value": value.toLayoutStruct()};
  }
}

class ScValVoid extends ScVal<void, void> {
  ScValVoid() : super(type: ScValueType.voidType, value: null);
  static Layout<void> layout({String? property}) {
    return LayoutConst.none(property: property);
  }

  @override
  Layout<void> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  void toLayoutStruct() {}
}

class ScValKeyContractInstance extends ScVal<void, void> {
  ScValKeyContractInstance()
      : super(type: ScValueType.ledgerKeyContractInstance, value: null);
  static Layout<void> layout({String? property}) {
    return LayoutConst.none(property: property);
  }

  @override
  Layout<void> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  void toLayoutStruct() {}
}

class ContractExecutableType {
  final String name;
  final int value;
  const ContractExecutableType._({required this.name, required this.value});
  static const ContractExecutableType executableWasm =
      ContractExecutableType._(name: "ExecutableWasm", value: 0);
  static const ContractExecutableType executableStellarAsset =
      ContractExecutableType._(name: "ExecutableStellarAsset", value: 1);
  static const List<ContractExecutableType> values = [
    executableWasm,
    executableStellarAsset
  ];
  @override
  String toString() {
    return "ContractExecutableType.$name";
  }
}

abstract class ContractExecutable<T> extends XDRVariantSerialization<T> {
  final ContractExecutableType type;
  const ContractExecutable(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      ContractExecutableWasmHash.layout(
          property: ContractExecutableType.executableWasm.name),
      ContractExecutableStellarAsset.layout(
          property: ContractExecutableType.executableStellarAsset.name)
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ContractExecutableWasmHash
    extends ContractExecutable<Map<String, dynamic>> {
  final List<int> hash;
  ContractExecutableWasmHash(List<int> hash)
      : hash = hash.asImmutableBytes.max(StellarConst.hash256Length),
        super(ContractExecutableType.executableWasm);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: property),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hash": hash};
  }
}

class ContractExecutableStellarAsset extends ContractExecutable<void> {
  ContractExecutableStellarAsset()
      : super(ContractExecutableType.executableStellarAsset);
  static Layout<void> layout({String? property}) {
    return LayoutConst.none(property: property);
  }

  @override
  Layout<void> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  void toLayoutStruct() {}
}

class ScContractInstance extends XDRSerialization<Map<String, dynamic>> {
  final ContractExecutable executable;
  final List<ScMapEntry>? storage;
  ScContractInstance({required this.executable, List<ScMapEntry>? storage})
      : storage = storage?.immutable;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ContractExecutable.layout(property: "executable"),
      LayoutConst.xdrVec(ScMapEntry.layout(), property: "storage"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "executable": executable.toVariantLayoutStruct(),
      "storage": storage?.map((e) => e.toLayoutStruct()).toList(),
    };
  }
}

class ContractDataDurability {
  final String name;
  final int value;
  const ContractDataDurability._({required this.name, required this.value});
  static const ContractDataDurability temporary =
      ContractDataDurability._(name: "temporary", value: 0);
  static const ContractDataDurability persistent =
      ContractDataDurability._(name: "persistent", value: 1);
  @override
  String toString() {
    return "ContractDataDurability.$name";
  }
}

class ContractDataEntry extends LedgerEntryData {
  final ScAddress contract;
  final ScVal key;
  final ContractDataDurability durability;
  final ScVal val;
  const ContractDataEntry(
      {required this.contract,
      required this.key,
      required this.durability,
      required this.val})
      : super(LedgerEntryType.contractData);
}

class ContractCodeCostInputs {
  final int nInstructions;
  final int nFunctions;
  final int nGlobals;
  final int nTableEntries;
  final int nTypes;
  final int nDataSegments;
  final int nElemSegments;
  final int nImports;
  final int nExports;
  final int nDataSegmentBytes;
  ContractCodeCostInputs({
    required int nInstructions,
    required int nFunctions,
    required int nGlobals,
    required int nTableEntries,
    required int nTypes,
    required int nDataSegments,
    required int nElemSegments,
    required int nImports,
    required int nExports,
    required int nDataSegmentBytes,
  })  : nInstructions = nInstructions.asUint32,
        nFunctions = nFunctions.asUint32,
        nGlobals = nGlobals.asUint32,
        nTableEntries = nTableEntries.asUint32,
        nTypes = nTypes.asUint32,
        nDataSegments = nDataSegments.asUint32,
        nElemSegments = nElemSegments.asUint32,
        nImports = nImports.asUint32,
        nExports = nExports.asUint32,
        nDataSegmentBytes = nDataSegmentBytes.asUint32;
}

class ContractCodeEntryV1 {
  final ContractCodeCostInputs costInputs;
  const ContractCodeEntryV1({required this.costInputs});
}
// class ContractCodeEntryExt {
//   switch(): number;

//   v1(value?: ContractCodeEntryV1): ContractCodeEntryV1;

//   static 0(): ContractCodeEntryExt;

//   static 1(value: ContractCodeEntryV1): ContractCodeEntryExt;
class ContractCodeEntryExt extends ExtPoint {
  final ContractCodeEntryV1? ext;
  const ContractCodeEntryExt(this.ext);

  @override
  int get value => ext == null ? 0 : 1;
}

class ContractCodeEntry extends LedgerEntryData {
  final ContractCodeEntryExt ext;
  final List<int> hash;
  final List<int> code;
  ContractCodeEntry(
      {required this.ext, required List<int> hash, required List<int> code})
      : code = code.asImmutableBytes,
        hash = hash.asImmutableBytes,
        super(LedgerEntryType.contractCode);
}

class ConfigSettingId {
  final String name;
  final int value;

  const ConfigSettingId._({required this.name, required this.value});

  static const contractMaxSizeBytes =
      ConfigSettingId._(name: 'ContractMaxSizeBytes', value: 0);
  static const contractComputeV0 =
      ConfigSettingId._(name: 'ContractComputeV0', value: 1);
  static const contractLedgerCostV0 =
      ConfigSettingId._(name: 'ContractLedgerCostV0', value: 2);
  static const contractHistoricalDataV0 =
      ConfigSettingId._(name: 'ContractHistoricalDataV0', value: 3);
  static const contractEventsV0 =
      ConfigSettingId._(name: 'ContractEventsV0', value: 4);
  static const contractBandwidthV0 =
      ConfigSettingId._(name: 'ContractBandwidthV0', value: 5);
  static const contractCostParamsCpuInstructions =
      ConfigSettingId._(name: 'ContractCostParamsCpuInstructions', value: 6);
  static const contractCostParamsMemoryBytes =
      ConfigSettingId._(name: 'ContractCostParamsMemoryBytes', value: 7);
  static const contractDataKeySizeBytes =
      ConfigSettingId._(name: 'ContractDataKeySizeBytes', value: 8);
  static const contractDataEntrySizeBytes =
      ConfigSettingId._(name: 'ContractDataEntrySizeBytes', value: 9);
  static const stateArchival =
      ConfigSettingId._(name: 'StateArchival', value: 10);
  static const contractExecutionLanes =
      ConfigSettingId._(name: 'ContractExecutionLanes', value: 11);
  static const bucketlistSizeWindow =
      ConfigSettingId._(name: 'BucketlistSizeWindow', value: 12);
  static const evictionIterator =
      ConfigSettingId._(name: 'EvictionIterator', value: 13);
  @override
  String toString() {
    return "ConfigSettingId.$name";
  }
}

abstract class ConfigSettingEntry extends LedgerEntryData {
  final ConfigSettingId settingId;
  const ConfigSettingEntry(this.settingId)
      : super(LedgerEntryType.configSetting);
}

class ConfigSettingContractComputeV0 extends ConfigSettingEntry {
  final BigInt ledgerMaxInstructions;
  final BigInt txMaxInstructions;
  final BigInt feeRatePerInstructionsIncrement;
  final int txMemoryLimit;
  ConfigSettingContractComputeV0({
    required BigInt ledgerMaxInstructions,
    required BigInt txMaxInstructions,
    required BigInt feeRatePerInstructionsIncrement,
    required int txMemoryLimit,
  })  : ledgerMaxInstructions = ledgerMaxInstructions.asInt64,
        txMaxInstructions = txMaxInstructions.asInt64,
        feeRatePerInstructionsIncrement =
            feeRatePerInstructionsIncrement.asInt64,
        txMemoryLimit = txMemoryLimit.asUint32,
        super(ConfigSettingId.contractComputeV0);
}

class ConfigSettingContractLedgerCostV0 extends ConfigSettingEntry {
  final int ledgerMaxReadLedgerEntries;
  final int ledgerMaxReadBytes;
  final int ledgerMaxWriteLedgerEntries;
  final int ledgerMaxWriteBytes;
  final int txMaxReadLedgerEntries;
  final int txMaxReadBytes;
  final int txMaxWriteLedgerEntries;
  final int txMaxWriteBytes;
  final BigInt feeReadLedgerEntry;
  final BigInt feeWriteLedgerEntry;
  final BigInt feeRead1Kb;
  final BigInt bucketListTargetSizeBytes;
  final BigInt writeFee1KbBucketListLow;
  final BigInt writeFee1KbBucketListHigh;
  final int bucketListWriteFeeGrowthFactor;
  ConfigSettingContractLedgerCostV0({
    required int ledgerMaxReadLedgerEntries,
    required int ledgerMaxReadBytes,
    required int ledgerMaxWriteLedgerEntries,
    required int ledgerMaxWriteBytes,
    required int txMaxReadLedgerEntries,
    required int txMaxReadBytes,
    required int txMaxWriteLedgerEntries,
    required int txMaxWriteBytes,
    required BigInt feeReadLedgerEntry,
    required BigInt feeWriteLedgerEntry,
    required BigInt feeRead1Kb,
    required BigInt bucketListTargetSizeBytes,
    required BigInt writeFee1KbBucketListLow,
    required BigInt writeFee1KbBucketListHigh,
    required int bucketListWriteFeeGrowthFactor,
  })  : ledgerMaxReadLedgerEntries = ledgerMaxReadLedgerEntries.asUint32,
        ledgerMaxReadBytes = ledgerMaxReadBytes.asUint32,
        ledgerMaxWriteLedgerEntries = ledgerMaxWriteLedgerEntries.asUint32,
        ledgerMaxWriteBytes = ledgerMaxWriteBytes.asUint32,
        txMaxReadLedgerEntries = txMaxReadLedgerEntries.asUint32,
        txMaxReadBytes = txMaxReadBytes.asUint32,
        txMaxWriteLedgerEntries = txMaxWriteLedgerEntries.asUint32,
        txMaxWriteBytes = txMaxWriteBytes.asUint32,
        feeReadLedgerEntry = feeReadLedgerEntry.asInt64,
        feeWriteLedgerEntry = feeWriteLedgerEntry.asInt64,
        feeRead1Kb = feeRead1Kb.asInt64,
        bucketListTargetSizeBytes = bucketListTargetSizeBytes.asInt64,
        writeFee1KbBucketListLow = writeFee1KbBucketListLow.asInt64,
        writeFee1KbBucketListHigh = writeFee1KbBucketListHigh.asInt64,
        bucketListWriteFeeGrowthFactor =
            bucketListWriteFeeGrowthFactor.asUint32,
        super(ConfigSettingId.contractLedgerCostV0);
}

class ConfigSettingContractHistoricalDataV0 extends ConfigSettingEntry {
  final BigInt feeHistorical1Kb;
  ConfigSettingContractHistoricalDataV0(BigInt feeHistorical1Kb)
      : feeHistorical1Kb = feeHistorical1Kb.asInt64,
        super(ConfigSettingId.contractHistoricalDataV0);
}

class ConfigSettingContractEventsV0 extends ConfigSettingEntry {
  final int txMaxContractEventsSizeBytes;
  final BigInt feeContractEvents1Kb;
  ConfigSettingContractEventsV0(
      {required int txMaxContractEventsSizeBytes,
      required BigInt feeContractEvents1Kb})
      : txMaxContractEventsSizeBytes = txMaxContractEventsSizeBytes.asUint32,
        feeContractEvents1Kb = feeContractEvents1Kb.asInt64,
        super(ConfigSettingId.contractEventsV0);
}

class ConfigSettingContractBandwidthV0 extends ConfigSettingEntry {
  final int ledgerMaxTxsSizeBytes;
  final int txMaxSizeBytes;
  final BigInt feeTxSize1Kb;
  ConfigSettingContractBandwidthV0(
      {required int ledgerMaxTxsSizeBytes,
      required int txMaxSizeBytes,
      required BigInt feeTxSize1Kb})
      : ledgerMaxTxsSizeBytes = ledgerMaxTxsSizeBytes.asUint32,
        txMaxSizeBytes = txMaxSizeBytes.asUint32,
        feeTxSize1Kb = feeTxSize1Kb.asInt64,
        super(ConfigSettingId.contractBandwidthV0);
}

class ContractCostParamEntry {
  final BigInt constTerm;
  final BigInt linearTerm;
  ContractCostParamEntry(
      {required BigInt constTerm, required BigInt linearTerm})
      : constTerm = constTerm.asInt64,
        linearTerm = linearTerm.asInt64;
}

class ConfingSettingContractCostParamsCpuInstructions
    extends ConfigSettingEntry {
  final List<ContractCostParamEntry> params;
  ConfingSettingContractCostParamsCpuInstructions(
      List<ContractCostParamEntry> params)
      : params = params.immutable,
        super(ConfigSettingId.contractCostParamsCpuInstructions);
}

class ConfingSettingContractCostParamsMemoryBytes extends ConfigSettingEntry {
  final List<ContractCostParamEntry> params;
  ConfingSettingContractCostParamsMemoryBytes(
      List<ContractCostParamEntry> params)
      : params = params.immutable,
        super(ConfigSettingId.contractCostParamsMemoryBytes);
}

class ConfingSettingContractDataKeySizeBytes extends ConfigSettingEntry {
  final int contractDataKeySizeBytes;
  ConfingSettingContractDataKeySizeBytes(int contractDataKeySizeBytes)
      : contractDataKeySizeBytes = contractDataKeySizeBytes.asUint32,
        super(ConfigSettingId.contractDataKeySizeBytes);
}

class ConfingSettingContractDataEnterySizeBytes extends ConfigSettingEntry {
  final int contractDataEnterySizeBytes;
  ConfingSettingContractDataEnterySizeBytes(int contractDataEnterySizeBytes)
      : contractDataEnterySizeBytes = contractDataEnterySizeBytes.asUint32,
        super(ConfigSettingId.contractDataEntrySizeBytes);
}

class StateArchivalSettings {
  final int maxEntryTtl;
  final int minTemporaryTtl;
  final int minPersistentTtl;
  final BigInt persistentRentRateDenominator;
  final BigInt tempRentRateDenominator;
  final int maxEntriesToArchive;
  final int bucketListSizeWindowSampleSize;
  final int bucketListWindowSamplePeriod;
  final int evictionScanSize;
  final int startingEvictionScanLevel;
  StateArchivalSettings({
    required int maxEntryTtl,
    required int minTemporaryTtl,
    required int minPersistentTtl,
    required BigInt persistentRentRateDenominator,
    required BigInt tempRentRateDenominator,
    required int maxEntriesToArchive,
    required int bucketListSizeWindowSampleSize,
    required int bucketListWindowSamplePeriod,
    required int evictionScanSize,
    required int startingEvictionScanLevel,
  })  : maxEntryTtl = maxEntryTtl.asUint32,
        minTemporaryTtl = minTemporaryTtl.asUint32,
        minPersistentTtl = minPersistentTtl.asUint32,
        persistentRentRateDenominator = persistentRentRateDenominator.asInt64,
        tempRentRateDenominator = tempRentRateDenominator.asInt64,
        maxEntriesToArchive = maxEntriesToArchive.asUint32,
        bucketListSizeWindowSampleSize =
            bucketListSizeWindowSampleSize.asUint32,
        bucketListWindowSamplePeriod = bucketListWindowSamplePeriod.asUint32,
        evictionScanSize = evictionScanSize.asUint32,
        startingEvictionScanLevel = startingEvictionScanLevel.asUint32;
}

class ConfigSettingContractStateArchivalSettings extends ConfigSettingEntry {
  final StateArchivalSettings settings;
  ConfigSettingContractStateArchivalSettings(this.settings)
      : super(ConfigSettingId.stateArchival);
}

class ConfigSettingContractExecutionLanesV0 extends ConfigSettingEntry {
  final int ledgerMaxTxCount;
  ConfigSettingContractExecutionLanesV0(int ledgerMaxTxCount)
      : ledgerMaxTxCount = ledgerMaxTxCount.asUint32,
        super(ConfigSettingId.contractExecutionLanes);
}

class ConfigSettingBucketlistSizeWindow extends ConfigSettingEntry {
  ConfigSettingBucketlistSizeWindow(List<BigInt> value)
      : value = value.map((e) => e.asUint64).toList().immutable,
        super(ConfigSettingId.bucketlistSizeWindow);
  final List<BigInt> value;
}

class EvictionIterator {
  final int bucketListLevel;
  final bool isCurrBucket;
  final BigInt bucketFileOffset;
  EvictionIterator(
      {required int bucketListLevel,
      required this.isCurrBucket,
      required BigInt bucketFileOffset})
      : bucketListLevel = bucketListLevel.asUint32,
        bucketFileOffset = bucketFileOffset.asUint64;
}

class ConfigSettingEvictionIterator extends ConfigSettingEntry {
  final EvictionIterator evictionIterator;
  ConfigSettingEvictionIterator(this.evictionIterator)
      : super(ConfigSettingId.evictionIterator);
}

class TtlEntry extends LedgerEntryData {
  final Hash256 keyHash;
  final int liveUntilLedgerSeq;
  TtlEntry({required this.keyHash, required int liveUntilLedgerSeq})
      : liveUntilLedgerSeq = liveUntilLedgerSeq.asUint32,
        super(LedgerEntryType.ttl);
}

class LedgerEntryExtensionV1Ext extends ExtPoint {
  @override
  int get value => 0;
}

class LedgerEntryExtensionV1 {
  final LedgerEntryExtensionV1Ext ext;
  final StellarBaseAddress? sponsoringId;
  LedgerEntryExtensionV1({required this.ext, this.sponsoringId});
}

class LedgerEntryExt extends ExtPoint {
  final LedgerEntryExtensionV1? ext;
  LedgerEntryExt(this.ext);

  @override
  int get value => ext == null ? 0 : 1;
}

class LedgerEntry {
  final int lastModifiedLedgerSeq;
  final LedgerEntryData data;
  final LedgerEntryExt ext;
  LedgerEntry(
      {required int lastModifiedLedgerSeq,
      required this.data,
      required this.ext})
      : lastModifiedLedgerSeq = lastModifiedLedgerSeq.asUint32;
}

abstract class LedgerKey<T> extends XDRVariantSerialization<T> {
  final LedgerEntryType type;
  const LedgerKey(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be(
        List.generate(LedgerEntryType.values.length, (index) {
      final type = LedgerEntryType.values.elementAt(index);
      switch (type) {
        case LedgerEntryType.account:
          return LedgerKeyAccount.layout(property: type.name);
        case LedgerEntryType.trustline:
          return LedgerKeyTrustLine.layout(property: type.name);
        case LedgerEntryType.offer:
          return LedgerKeyOffer.layout(property: type.name);
        case LedgerEntryType.data:
          return LedgerKeyData.layout(property: type.name);
        case LedgerEntryType.claimableBalance:
          return LedgerKeyClaimableBalance.layout(property: type.name);
        case LedgerEntryType.liquidityPool:
          return LedgerKeyLiquidityPool.layout(property: type.name);
        case LedgerEntryType.contractData:
          return LedgerKeyContractData.layout(property: type.name);
        case LedgerEntryType.contractCode:
          return LedgerKeyContractCode.layout(property: type.name);
        case LedgerEntryType.configSetting:
          return LedgerKeyConfigSetting.layout(property: type.name);
        case LedgerEntryType.ttl:
          return LedgerKeyTtl.layout(property: type.name);
        default:
          throw DartStellarPlugingException("Invalid LedgerEntry type.");
      }
    }));
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class LedgerKeyAccount extends LedgerKey<Map<String, dynamic>> {
  final StellarPublicKey accountId;
  const LedgerKeyAccount(this.accountId) : super(LedgerEntryType.account);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"accountId": accountId.toLayoutStruct()};
  }
}

class LedgerKeyTrustLine extends LedgerKey<Map<String, dynamic>> {
  final StellarPublicKey accountId;
  final TrustLineAsset asset;
  const LedgerKeyTrustLine({required this.accountId, required this.asset})
      : super(LedgerEntryType.trustline);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
      TrustLineAsset.layout(property: "asset")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "accountId": accountId.toLayoutStruct(),
      "asset": asset.toVariantLayoutStruct()
    };
  }
}

class LedgerKeyOffer extends LedgerKey<Map<String, dynamic>> {
  final StellarPublicKey accountId;
  final BigInt offerId;
  LedgerKeyOffer({required this.accountId, required BigInt offerId})
      : offerId = offerId.asInt64,
        super(LedgerEntryType.offer);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
      LayoutConst.s64be(property: "offerId")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"accountId": accountId.toLayoutStruct(), "offerId": offerId};
  }
}

class LedgerKeyData extends LedgerKey<Map<String, dynamic>> {
  final StellarPublicKey accountId;
  final String dataName;
  LedgerKeyData({required this.accountId, required String dataName})
      : dataName = dataName.max(64),
        super(LedgerEntryType.data);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
      LayoutConst.xdrString(property: "dataName")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"accountId": accountId.toLayoutStruct(), "dataName": dataName};
  }
}

class LedgerKeyClaimableBalance extends LedgerKey<Map<String, dynamic>> {
  final ClaimableBalanceId balanceId;
  const LedgerKeyClaimableBalance(this.balanceId)
      : super(LedgerEntryType.claimableBalance);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [ClaimableBalanceId.layout(property: "balanceId")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "balanceId": balanceId.toVariantLayoutStruct(),
    };
  }
}

class LedgerKeyLiquidityPool extends LedgerKey<Map<String, dynamic>> {
  final List<int> liquidityPoolId;
  LedgerKeyLiquidityPool(List<int> liquidityPoolId)
      : liquidityPoolId =
            liquidityPoolId.asImmutableBytes.exc(StellarConst.hash256Length),
        super(LedgerEntryType.liquidityPool);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length,
          property: "liquidityPoolId")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"liquidityPoolId": liquidityPoolId};
  }
}

class LedgerKeyContractData extends LedgerKey<Map<String, dynamic>> {
  final ScAddress contract;
  final ScVal key;
  final ContractDataDurability durability;
  const LedgerKeyContractData(
      {required this.contract, required this.key, required this.durability})
      : super(LedgerEntryType.contractData);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScAddress.layout(property: "contract"),
      ScVal.layout(property: "key"),
      LayoutConst.s32be(property: "durability")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "contract": contract.toVariantLayoutStruct(),
      "key": key.toVariantLayoutStruct(),
      "durability": durability.value
    };
  }
}

class LedgerKeyContractCode extends LedgerKey<Map<String, dynamic>> {
  final List<int> hash;
  LedgerKeyContractCode(List<int> hash)
      : hash = hash.asImmutableBytes.max(StellarConst.hash256Length),
        super(LedgerEntryType.contractCode);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "hash")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"hash": hash};
  }
}

class LedgerKeyConfigSetting extends LedgerKey<Map<String, dynamic>> {
  final ConfigSettingId configSettingId;
  const LedgerKeyConfigSetting(this.configSettingId)
      : super(LedgerEntryType.configSetting);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u32be(property: "configSettingId"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"configSettingId": configSettingId.value};
  }
}

class LedgerKeyTtl extends LedgerKey<Map<String, dynamic>> {
  final List<int> keyHash;
  LedgerKeyTtl(List<int> keyHash)
      : keyHash = keyHash.asImmutableBytes.max(StellarConst.hash256Length),
        super(LedgerEntryType.ttl);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "keyHash")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"keyHash": keyHash};
  }
}

class LedgerFootprint {
  final List<LedgerKey> readOnly;
  final List<LedgerKey> readWrite;
  LedgerFootprint(
      {required List<LedgerKey> readOnly, required List<LedgerKey> readWrite})
      : readOnly = readOnly.immutable,
        readWrite = readWrite.immutable;
}

class SorobanResources {
  final LedgerFootprint footprint;
  final int instructions;
  final int readBytes;
  final int writeBytes;
  SorobanResources(
      {required this.footprint,
      required int instructions,
      required int readBytes,
      required int writeBytes})
      : instructions = instructions.asUint32,
        readBytes = readBytes.asUint32,
        writeBytes = writeBytes.asUint32;
}

class SorobanTransactionData {
  final SorobanResources resources;
  final BigInt resourceFee;
  SorobanTransactionData({required this.resources, required BigInt resourceFee})
      : resourceFee = resourceFee.asInt64;
}

class TransactionExt extends ExtPoint {
  final SorobanTransactionData? sorobanTransactionData;
  const TransactionExt({this.sorobanTransactionData});

  @override
  int get value => sorobanTransactionData == null ? 0 : 1;
}

class CryptoKeyType {
  final String name;
  final int value;

  const CryptoKeyType._({required this.name, required this.value});

  static const ed25519 = CryptoKeyType._(name: 'Ed25519', value: 0);
  static const preAuthTx = CryptoKeyType._(name: 'PreAuthTx', value: 1);
  static const hashX = CryptoKeyType._(name: 'HashX', value: 2);
  static const ed25519SignedPayload =
      CryptoKeyType._(name: 'Ed25519SignedPayload', value: 3);
  static const muxedEd25519 = CryptoKeyType._(name: 'MuxedEd25519', value: 256);
  @override
  String toString() {
    return "CryptoKeyType.$name";
  }
}

// mixin StelarrSerialization {
//   List<int> serialize();
// }

abstract class MuxedAccount<T> extends XDRVariantSerialization<T> {
  final CryptoKeyType type;
  const MuxedAccount._(this.type);
  factory MuxedAccount(StellarAddress address) {
    if (address.type == XlmAddrTypes.muxed) {
      address as StellarMuxedAddress;
      return MuxedAccountMed25519(
          id: address.accountId,
          ed25519: address.publicKeyBytes()) as MuxedAccount<T>;
    }
    return MuxedAccountEd25519(address.publicKeyBytes()) as MuxedAccount<T>;
  }
  static Layout<Map<String, dynamic>> layout({String? property}) =>
      LayoutConst.rustEnumU32Be([
        MuxedAccountEd25519.layout(property: CryptoKeyType.ed25519.name),
        ...List.generate(254, (e) => LayoutConst.none()),
        MuxedAccountMed25519.layout(property: CryptoKeyType.muxedEd25519.name),
      ], property: property);

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class MuxedAccountMed25519 extends MuxedAccount<Map<String, dynamic>> {
  final BigInt id;
  final List<int> ed25519;
  MuxedAccountMed25519({required BigInt id, required List<int> ed25519})
      : id = id.asUint64,
        ed25519 = ed25519.asImmutableBytes,
        super._(CryptoKeyType.muxedEd25519);

  static Layout<Map<String, dynamic>> layout({String? property}) =>
      LayoutConst.struct([
        LayoutConst.u64(property: "id"),
        LayoutConst.fixedBlob32(property: "ed25519"),
      ], property: property);

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"id": id, "ed25519": ed25519};
  }
}

class MuxedAccountEd25519 extends MuxedAccount<List<int>> {
  final List<int> ed25519;
  MuxedAccountEd25519(List<int> ed25519)
      : ed25519 = ed25519.immutable,
        super._(CryptoKeyType.ed25519);

  static Layout<List<int>> layout({String? property}) =>
      LayoutConst.fixedBlob32(property: property);
  @override
  Layout<List<int>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  List<int> toLayoutStruct() {
    return ed25519;
  }
}

class PreconditionType {
  final String name;
  final int value;

  const PreconditionType._(this.name, this.value);

  static const PreconditionType none = PreconditionType._('None', 0);
  static const PreconditionType time = PreconditionType._('Time', 1);
  static const PreconditionType v2 = PreconditionType._('V2', 2);

  static const List<PreconditionType> values = [none, time, v2];
}

class TimeBounds {
  final BigInt minTime;
  final BigInt maxTime;
  TimeBounds({required BigInt minTime, required BigInt maxTime})
      : minTime = minTime.asUint64,
        maxTime = maxTime.asUint64;
}

class LedgerBounds {
  final int minLedger;
  final int maxLedger;
  LedgerBounds({required int minLedger, required int maxLedger})
      : minLedger = minLedger.asUint32,
        maxLedger = maxLedger.asUint32;
}

class PreconditionsV2 {
  final TimeBounds? timeBounds;
  final LedgerBounds? ledgerBounds;
  final BigInt? minSeqNum;
  final BigInt minSeqAge;
  final int minSeqLedgerGap;
  final List<SignerKey> extraSigners;
  PreconditionsV2(
      {this.timeBounds,
      this.ledgerBounds,
      BigInt? minSeqNum,
      required BigInt minSeqAge,
      required int minSeqLedgerGap,
      required List<SignerKey> extraSigners})
      : minSeqNum = minSeqNum?.asInt64,
        minSeqAge = minSeqAge.asUint64,
        minSeqLedgerGap = minSeqLedgerGap.asUint32,
        extraSigners = extraSigners.immutable;
}

abstract class Preconditions {
  final PreconditionType type;
  const Preconditions(this.type);
}

class PrecondNone extends Preconditions {
  const PrecondNone() : super(PreconditionType.none);
}

class PrecondTime extends Preconditions {
  final TimeBounds timeBounds;
  const PrecondTime(this.timeBounds) : super(PreconditionType.time);
}

class PrecondV2 extends Preconditions {
  final PreconditionsV2 preconditionsV2;
  const PrecondV2(this.preconditionsV2) : super(PreconditionType.v2);
}

abstract class AssetCode<T> extends XDRVariantSerialization<T> {
  final AssetType type;
  final List<int> code;
  const AssetCode({required this.type, required this.code});

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      LayoutConst.none(),
      AssetCode4.layout(property: AssetType.creditAlphanum4.name),
      AssetCode12.layout(property: AssetType.creditAlphanum12.name),
      LayoutConst.none(),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class AssetCode4 extends AssetCode<List<int>> {
  static const int codeLength = 4;
  AssetCode4({required AssetType type, required List<int> code})
      : super(
            type: AssetType.creditAlphanum4,
            code: StellarValidator.validateBytes(
                bytes: code, length: codeLength));
  static Layout<List<int>> layout({String? property}) {
    return LayoutConst.fixedBlobN(codeLength, property: property);
  }

  @override
  Layout<List<int>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  List<int> toLayoutStruct() {
    return code;
  }
}

class AssetCode12 extends AssetCode {
  static const int codeLength = 12;
  AssetCode12({required AssetType type, required List<int> code})
      : super(
            type: AssetType.creditAlphanum12,
            code: StellarValidator.validateBytes(
                bytes: code, length: codeLength));
  static Layout<List<int>> layout({String? property}) {
    return LayoutConst.fixedBlobN(codeLength, property: property);
  }

  @override
  Layout<List<int>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  List<int> toLayoutStruct() {
    return code;
  }
}

class RevokeSponsorshipType {
  final String name;
  final int value;
  const RevokeSponsorshipType._({required this.name, required this.value});
  static const RevokeSponsorshipType ledgerEntry =
      RevokeSponsorshipType._(name: "LedgerEntry", value: 0);
  static const RevokeSponsorshipType signer =
      RevokeSponsorshipType._(name: "Signer", value: 1);
  @override
  String toString() {
    return "RevokeSponsorshipType.$name";
  }
}

abstract class RevokeSponsorship
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final RevokeSponsorshipType type;
  const RevokeSponsorship(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnum([
      RevokeSponsorshipLedgerKey.layout(
          property: RevokeSponsorshipType.ledgerEntry.name),
      RevokeSponsorshipSigner.layout(
          property: RevokeSponsorshipType.signer.name)
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class RevokeSponsorshipSigner extends RevokeSponsorship {
  final StellarPublicKey accountId;
  final SignerKey signerKey;
  const RevokeSponsorshipSigner(
      {required this.accountId, required this.signerKey})
      : super(RevokeSponsorshipType.signer);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "accountId"),
      SignerKey.layout(property: "signerKey")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "accountId": accountId.toLayoutStruct(),
      "signerKey": signerKey.toVariantLayoutStruct(),
    };
  }
}

class RevokeSponsorshipLedgerKey extends RevokeSponsorship {
  final LedgerKey ledgerKey;
  const RevokeSponsorshipLedgerKey(this.ledgerKey)
      : super(RevokeSponsorshipType.ledgerEntry);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LedgerKey.layout(property: "ledgerKey"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "ledgerKey": ledgerKey.toVariantLayoutStruct(),
    };
  }
}

class HostFunctionType {
  final String name;
  final int value;

  const HostFunctionType._({required this.name, required this.value});

  static const invokeContract =
      HostFunctionType._(name: 'InvokeContract', value: 0);
  static const createContract =
      HostFunctionType._(name: 'CreateContract', value: 1);
  static const uploadContractWasm =
      HostFunctionType._(name: 'UploadContractWasm', value: 2);
  @override
  String toString() {
    return "HostFunctionType.$name";
  }
}

abstract class HostFunction
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final HostFunctionType type;
  const HostFunction(this.type);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      HostFunctionTypeInvokeContract.layout(
          property: HostFunctionType.invokeContract.name),
      HostFunctionTypeCreateContract.layout(
          property: HostFunctionType.createContract.name),
      HostFunctionTypeUploadContractWasm.layout(
          property: HostFunctionType.uploadContractWasm.name)
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class HostFunctionTypeInvokeContract extends HostFunction {
  final InvokeContractArgs args;
  HostFunctionTypeInvokeContract(this.args)
      : super(HostFunctionType.invokeContract);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([InvokeContractArgs.layout(property: "args")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "args": args.toLayoutStruct(),
    };
  }
}

class ContractIdPreimageType {
  final String name;
  final int value;

  const ContractIdPreimageType._({required this.name, required this.value});

  static const fromAddress =
      ContractIdPreimageType._(name: 'FromAddress', value: 0);
  static const fromAsset =
      ContractIdPreimageType._(name: 'FromAsset', value: 1);

  @override
  String toString() {
    return "ContractIdPreimageType.$name";
  }
}

abstract class ContractIdPreimage
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final ContractIdPreimageType type;
  const ContractIdPreimage(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      ContractIdPreimageFromAddress.layout(
          property: ContractIdPreimageType.fromAddress.name),
      ContractIdPreimageFromAsset.layout(
          property: ContractIdPreimageType.fromAsset.name)
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class ContractIdPreimageFromAddress extends ContractIdPreimage {
  final ScAddress address;
  final List<int> salt;
  ContractIdPreimageFromAddress(
      {required this.address, required List<int> salt})
      : salt = salt.immutable.max(StellarConst.hash256Length),
        super(ContractIdPreimageType.fromAddress);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScAddress.layout(property: "address"),
      LayoutConst.fixedBlobN(StellarConst.hash256Length, property: "salt")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"address": address.toVariantLayoutStruct(), "salt": salt};
  }
}

class ContractIdPreimageFromAsset extends ContractIdPreimage {
  final StellarAsset asset;
  ContractIdPreimageFromAsset(this.asset)
      : super(ContractIdPreimageType.fromAsset);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarAsset.layout(property: "asset"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"asset": asset.toVariantLayoutStruct()};
  }
}

class CreateContractArgs extends XDRSerialization<Map<String, dynamic>> {
  final ContractIdPreimage contractIdPreimage;
  final ContractExecutable executable;
  const CreateContractArgs(
      {required this.contractIdPreimage, required this.executable});
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ContractIdPreimage.layout(property: "contractIdPreimage"),
      ContractExecutable.layout(property: "executable"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "contractIdPreimage": contractIdPreimage.toVariantLayoutStruct(),
      "executable": executable.toVariantLayoutStruct(),
    };
  }
}

class HostFunctionTypeCreateContract extends HostFunction {
  final CreateContractArgs args;
  const HostFunctionTypeCreateContract(this.args)
      : super(HostFunctionType.createContract);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      CreateContractArgs.layout(property: "args"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"args": args.toLayoutStruct()};
  }
}

class HostFunctionTypeUploadContractWasm extends HostFunction {
  final List<int> data;
  HostFunctionTypeUploadContractWasm(List<int> data)
      : data = data.asImmutableBytes,
        super(HostFunctionType.uploadContractWasm);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.xdrVecBytes(property: "data"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"data": data};
  }
}

class SorobanCredentialsType {
  final String name;
  final int value;

  const SorobanCredentialsType._({required this.name, required this.value});

  static const sourceAccount =
      SorobanCredentialsType._(name: 'SourceAccount', value: 0);
  static const address = SorobanCredentialsType._(name: 'Address', value: 1);
  @override
  String toString() {
    return "SorobanCredentialsType.$name";
  }
}

abstract class SorobanCredentials<T> extends XDRVariantSerialization<T> {
  final SorobanCredentialsType type;
  const SorobanCredentials(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      SorobanCredentialsSourceAccount.layout(
          property: SorobanCredentialsType.sourceAccount.name),
      SorobanAddressCredentials.layout(
          property: SorobanCredentialsType.address.name),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class SorobanAddressCredentials
    extends SorobanCredentials<Map<String, dynamic>> {
  final ScAddress address;
  final BigInt nonce;
  final int signatureExpirationLedger;
  final ScVal signature;
  SorobanAddressCredentials(
      {required this.address,
      required BigInt nonce,
      required int signatureExpirationLedger,
      required this.signature})
      : nonce = nonce.asInt64,
        signatureExpirationLedger = signatureExpirationLedger.asUint32,
        super(SorobanCredentialsType.address);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScAddress.layout(property: "address"),
      LayoutConst.s64be(property: "nonce"),
      LayoutConst.u32be(property: "signatureExpirationLedger"),
      ScVal.layout(property: "signature")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "address": address.toVariantLayoutStruct(),
      "nonce": nonce,
      "signatureExpirationLedger": signatureExpirationLedger,
      "signature": signature.toVariantLayoutStruct()
    };
  }
}

class SorobanCredentialsSourceAccount extends SorobanCredentials<void> {
  const SorobanCredentialsSourceAccount()
      : super(SorobanCredentialsType.sourceAccount);
  static Layout<void> layout({String? property}) {
    return LayoutConst.none(property: property);
  }

  @override
  Layout<void> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  void toLayoutStruct() {}
}

class SorobanAuthorizedFunctionType {
  final String name;
  final int value;

  const SorobanAuthorizedFunctionType._(
      {required this.name, required this.value});

  static const contractFn =
      SorobanAuthorizedFunctionType._(name: 'ContractFn', value: 0);
  static const createContractHostFn =
      SorobanAuthorizedFunctionType._(name: 'CreateContractHostFn', value: 1);
  @override
  String toString() {
    return "SorobanAuthorizedFunctionType.$name";
  }
}

abstract class SorobanAuthorizedFunction
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final SorobanAuthorizedFunctionType type;
  const SorobanAuthorizedFunction(this.type);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.rustEnumU32Be([
      SorobanAuthorizedFunctionTypeContractFunction.layout(
          property: SorobanAuthorizedFunctionType.contractFn.name),
      SorobanAuthorizedFunctionTypeCreateContractHostFunction.layout(
          property: SorobanAuthorizedFunctionType.createContractHostFn.name)
    ]);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
}

class InvokeContractArgs extends XDRSerialization<Map<String, dynamic>> {
  final ScAddress contractAddress;
  final ScValSymbol functionName;
  final List<ScVal> args;
  InvokeContractArgs(
      {required this.contractAddress,
      required this.functionName,
      required List<ScVal> args})
      : args = args.immutable;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ScAddress.layout(property: "contractAddress"),
      ScValSymbol.layout(property: "functionName"),
      LayoutConst.xdrVec(ScVal.layout(), property: "args")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  /// should be test
  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "contractAddress": contractAddress.toVariantLayoutStruct(),
      "functionName": functionName.toLayoutStruct(),
      "args": args.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

class SorobanAuthorizedFunctionTypeContractFunction
    extends SorobanAuthorizedFunction {
  final InvokeContractArgs args;
  const SorobanAuthorizedFunctionTypeContractFunction(this.args)
      : super(SorobanAuthorizedFunctionType.contractFn);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      InvokeContractArgs.layout(property: "args"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"args": args.toLayoutStruct()};
  }
}

class SorobanAuthorizedFunctionTypeCreateContractHostFunction
    extends SorobanAuthorizedFunction {
  final CreateContractArgs args;
  const SorobanAuthorizedFunctionTypeCreateContractHostFunction(this.args)
      : super(SorobanAuthorizedFunctionType.createContractHostFn);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      InvokeContractArgs.layout(property: "args"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"args": args.toLayoutStruct()};
  }
}

class SorobanAuthorizedInvocation
    extends XDRSerialization<Map<String, dynamic>> {
  final SorobanAuthorizedFunction function;
  final List<SorobanAuthorizedInvocation> subInvocations;
  SorobanAuthorizedInvocation(
      {required this.function,
      required List<SorobanAuthorizedInvocation> subInvocations})
      : subInvocations = subInvocations.immutable;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      SorobanAuthorizedFunction.layout(property: "function"),
      LayoutConst.xdrVec(SorobanAuthorizedInvocation.layout(),
          property: "subInvocations")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "function": function.toVariantLayoutStruct(),
      "subInvocations": subInvocations.map((e) => e.toLayoutStruct()).toList()
    };
  }
}

class SorobanAuthorizationEntry extends XDRSerialization<Map<String, dynamic>> {
  final SorobanCredentials credentials;
  final SorobanAuthorizedInvocation rootInvocation;
  const SorobanAuthorizationEntry(
      {required this.credentials, required this.rootInvocation});
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      SorobanCredentials.layout(property: "credentials"),
      SorobanAuthorizedInvocation.layout(property: "rootInvocation")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "rootInvocation": rootInvocation.toLayoutStruct(),
      "credentials": credentials.toVariantLayoutStruct()
    };
  }
}

class AuthFlag {
  final String name;
  final int value;

  const AuthFlag._({required this.name, required this.value});

  static const requiredFlag = AuthFlag._(name: 'RequiredFlag', value: 1);
  static const revocableFlag = AuthFlag._(name: 'RevocableFlag', value: 2);
  static const immutableFlag = AuthFlag._(name: 'ImmutableFlag', value: 4);
  static const clawbackEnabledFlag =
      AuthFlag._(name: 'ClawbackEnabledFlag', value: 8);
  @override
  String toString() {
    return "AuthFlag.$name";
  }
}

class PublicKeyType {
  final String name;
  final int value;

  const PublicKeyType._(this.name, this.value);

  static const PublicKeyType ed25519 = PublicKeyType._('Ed25519', 0);
  @override
  String toString() {
    return "PublicKeyType.$name";
  }
}

// class AccountId extends XDRSerialization {
//   final PublicKeyType type = PublicKeyType.ed25519;
// }
