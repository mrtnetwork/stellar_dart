// import 'dart:typed_data';

// import 'stellar-contract.dart';
// import 'stellar_contract_config_setting.dart';

// // Define Thresholds as a List of 4 opaque bytes
// typedef Thresholds = Uint8List;

// // Define string types with specific lengths
// typedef String32 = String;
// typedef String64 = String;

// // Define SequenceNumber as int64
// typedef SequenceNumber = int;

// // Define DataValue as a List of 64 opaque bytes
// typedef DataValue = Uint8List;

// // Define PoolID as a Hash (SHA256)
// typedef PoolID = List<int>;

// // Define AssetCode4 and AssetCode12 as opaque byte arrays
// typedef AssetCode4 = Uint8List;
// typedef AssetCode12 = Uint8List;

// // Define AssetType Enum
// class AssetType {
//   final int value;

//   const AssetType._(this.value);

//   static const AssetType native = AssetType._(0);
//   static const AssetType creditAlphanum4 = AssetType._(1);
//   static const AssetType creditAlphanum12 = AssetType._(2);
//   static const AssetType poolShare = AssetType._(3);

//   static const List<AssetType> values = [
//     native,
//     creditAlphanum4,
//     creditAlphanum12,
//     poolShare
//   ];
// }

// // Define AssetCode Union
// class AssetCode {
//   final AssetType type;
//   final AssetCode4? assetCode4;
//   final AssetCode12? assetCode12;

//   AssetCode.creditAlphanum4(this.assetCode4)
//       : type = AssetType.creditAlphanum4,
//         assetCode12 = null;
//   AssetCode.creditAlphanum12(this.assetCode12)
//       : type = AssetType.creditAlphanum12,
//         assetCode4 = null;

//   factory AssetCode.fromJson(Map<String, dynamic> json) {
//     final type = AssetType.values.firstWhere((e) => e.value == json['type']);
//     switch (type.value) {
//       case 1:
//         return AssetCode.creditAlphanum4(
//             Uint8List.fromList(json['assetCode4'].cast<int>()));
//       case 2:
//         return AssetCode.creditAlphanum12(
//             Uint8List.fromList(json['assetCode12'].cast<int>()));
//       default:
//         throw ArgumentError('Unknown AssetType value: ${type.value}');
//     }
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'type': type.value,
//       'assetCode4': assetCode4?.toList(),
//       'assetCode12': assetCode12?.toList()
//     };
//   }
// }

// // Define AlphaNum4 and AlphaNum12
// class AlphaNum4 {
//   final AssetCode4 assetCode;
//   final String issuer; // Assuming AccountID is a String

//   AlphaNum4(this.assetCode, this.issuer);

//   factory AlphaNum4.fromJson(Map<String, dynamic> json) {
//     return AlphaNum4(
//       Uint8List.fromList(json['assetCode'].cast<int>()),
//       json['issuer'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'assetCode': assetCode.toList(),
//       'issuer': issuer,
//     };
//   }
// }

// class AlphaNum12 {
//   final AssetCode12 assetCode;
//   final String issuer; // Assuming AccountID is a String

//   AlphaNum12(this.assetCode, this.issuer);

//   factory AlphaNum12.fromJson(Map<String, dynamic> json) {
//     return AlphaNum12(
//       Uint8List.fromList(json['assetCode'].cast<int>()),
//       json['issuer'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'assetCode': assetCode.toList(),
//       'issuer': issuer,
//     };
//   }
// }

// // Define Asset Union
// class Asset {
//   final AssetType type;
//   final AlphaNum4? alphaNum4;
//   final AlphaNum12? alphaNum12;

//   Asset.native()
//       : type = AssetType.native,
//         alphaNum4 = null,
//         alphaNum12 = null;
//   Asset.creditAlphanum4(this.alphaNum4)
//       : type = AssetType.creditAlphanum4,
//         alphaNum12 = null;
//   Asset.creditAlphanum12(this.alphaNum12)
//       : type = AssetType.creditAlphanum12,
//         alphaNum4 = null;

//   factory Asset.fromJson(Map<String, dynamic> json) {
//     final type = AssetType.values.firstWhere((e) => e.value == json['type']);
//     switch (type.value) {
//       case 0:
//         return Asset.native();
//       case 1:
//         return Asset.creditAlphanum4(AlphaNum4.fromJson(json['alphaNum4']));
//       case 2:
//         return Asset.creditAlphanum12(AlphaNum12.fromJson(json['alphaNum12']));
//       default:
//         throw ArgumentError('Unknown AssetType value: ${type.value}');
//     }
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'type': type.value,
//       'alphaNum4': alphaNum4?.toJson(),
//       'alphaNum12': alphaNum12?.toJson()
//     };
//   }
// }

// // Define Price
// class Price {
//   final int numerator;
//   final int denominator;

//   Price(this.numerator, this.denominator);

//   factory Price.fromJson(Map<String, dynamic> json) {
//     return Price(
//       json['n'],
//       json['d'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'n': numerator,
//       'd': denominator,
//     };
//   }
// }

// // Define Liabilities
// class Liabilities {
//   final int buying;
//   final int selling;

//   Liabilities(this.buying, this.selling);

//   factory Liabilities.fromJson(Map<String, dynamic> json) {
//     return Liabilities(
//       json['buying'],
//       json['selling'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'buying': buying,
//       'selling': selling,
//     };
//   }
// }

// // Define ThresholdIndexes Enum
// class ThresholdIndexes {
//   static const int masterWeight = 0;
//   static const int low = 1;
//   static const int med = 2;
//   static const int high = 3;
// }

// // Define LedgerEntryType Enum
// class LedgerEntryType {
//   final int value;

//   const LedgerEntryType._(this.value);

//   static const LedgerEntryType account = LedgerEntryType._(0);
//   static const LedgerEntryType trustline = LedgerEntryType._(1);
//   static const LedgerEntryType offer = LedgerEntryType._(2);
//   static const LedgerEntryType data = LedgerEntryType._(3);
//   static const LedgerEntryType claimableBalance = LedgerEntryType._(4);
//   static const LedgerEntryType liquidityPool = LedgerEntryType._(5);
//   static const LedgerEntryType contractData = LedgerEntryType._(6);
//   static const LedgerEntryType contractCode = LedgerEntryType._(7);
//   static const LedgerEntryType configSetting = LedgerEntryType._(8);
//   static const LedgerEntryType ttl = LedgerEntryType._(9);

//   static const List<LedgerEntryType> values = [
//     account,
//     trustline,
//     offer,
//     data,
//     claimableBalance,
//     liquidityPool,
//     contractData,
//     contractCode,
//     configSetting,
//     ttl
//   ];
// }

// // Define Signer
// class Signer {
//   final String key; // Assuming SignerKey is a String
//   final int weight; // Typically only 1 byte needed

//   Signer(this.key, this.weight);

//   factory Signer.fromJson(Map<String, dynamic> json) {
//     return Signer(
//       json['key'],
//       json['weight'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'key': key,
//       'weight': weight,
//     };
//   }
// }

// // Define AccountFlags Enum
// class AccountFlags {
//   static const int authRequired = 0x1;
//   static const int authRevocable = 0x2;
//   static const int authImmutable = 0x4;
//   static const int authClawbackEnabled = 0x8;

//   static const int mask = 0x7;
//   static const int maskV17 = 0xF;
// }

// // Define MAX_SIGNERS
// const int maxSigners = 20;

// // Define SponsorshipDescriptor as List of Strings (AccountID)
// typedef SponsorshipDescriptor = List<String>;

// // Define AccountEntryExtensionV3
// class AccountEntryExtensionV3 {
//   final int seqLedger;
//   final String seqTime; // Assuming TimePoint is a String

//   AccountEntryExtensionV3(this.seqLedger, this.seqTime);

//   factory AccountEntryExtensionV3.fromJson(Map<String, dynamic> json) {
//     return AccountEntryExtensionV3(
//       json['seqLedger'],
//       json['seqTime'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'seqLedger': seqLedger,
//       'seqTime': seqTime,
//     };
//   }
// }

// // Define AccountEntryExtensionV2
// class AccountEntryExtensionV2 {
//   final int numSponsored;
//   final int numSponsoring;
//   final SponsorshipDescriptor signerSponsoringIDs;

//   final dynamic ext; // Union type

//   AccountEntryExtensionV2(this.numSponsored, this.numSponsoring,
//       this.signerSponsoringIDs, this.ext);

//   factory AccountEntryExtensionV2.fromJson(Map<String, dynamic> json) {
//     return AccountEntryExtensionV2(
//       json['numSponsored'],
//       json['numSponsoring'],
//       (json['signerSponsoringIDs'] as List).cast<String>(),
//       json['ext'], // Handling union could be done based on the value of `ext`
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'numSponsored': numSponsored,
//       'numSponsoring': numSponsoring,
//       'signerSponsoringIDs': signerSponsoringIDs,
//       'ext': ext, // Handling union could be done based on the type of `ext`
//     };
//   }
// }

// // Define AccountEntryExtensionV1
// class AccountEntryExtensionV1 {
//   final Liabilities liabilities;
//   final dynamic ext; // Union type

//   AccountEntryExtensionV1(this.liabilities, this.ext);

//   factory AccountEntryExtensionV1.fromJson(Map<String, dynamic> json) {
//     return AccountEntryExtensionV1(
//       Liabilities.fromJson(json['liabilities']),
//       json['ext'], // Handling union could be done based on the value of `ext`
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'liabilities': liabilities.toJson(),
//       'ext': ext, // Handling union could be done based on the type of `ext`
//     };
//   }
// }

// // Define types
// typedef AccountID = String; // Assuming AccountID is a String

// // Define AccountEntry
// class AccountEntry {
//   final AccountID accountID;
//   final int balance;
//   final SequenceNumber seqNum;
//   final int numSubEntries;
//   final AccountID? inflationDest;
//   final int flags;
//   final String32 homeDomain;
//   final Thresholds thresholds;
//   final List<Signer> signers;
//   final dynamic ext; // Union type

//   AccountEntry(
//       this.accountID,
//       this.balance,
//       this.seqNum,
//       this.numSubEntries,
//       this.inflationDest,
//       this.flags,
//       this.homeDomain,
//       this.thresholds,
//       this.signers,
//       this.ext);

//   factory AccountEntry.fromJson(Map<String, dynamic> json) {
//     final ext = json['ext'] as Map<String, dynamic>?;

//     return AccountEntry(
//       json['accountID'],
//       json['balance'],
//       json['seqNum'],
//       json['numSubEntries'],
//       json['inflationDest'],
//       json['flags'],
//       json['homeDomain'],
//       Uint8List.fromList(json['thresholds'].cast<int>()),
//       (json['signers'] as List).map((e) => Signer.fromJson(e)).toList(),
//       ext != null
//           ? (ext['v'] == 0 ? null : AccountEntryExtensionV1.fromJson(ext))
//           : null,
//     );
//   }

//   Map<String, dynamic> toJson() {
//     final data = {
//       'accountID': accountID,
//       'balance': balance,
//       'seqNum': seqNum,
//       'numSubEntries': numSubEntries,
//       'inflationDest': inflationDest,
//       'flags': flags,
//       'homeDomain': homeDomain,
//       'thresholds': thresholds.toList(),
//       'signers': signers.map((e) => e.toJson()).toList(),
//     };

//     if (ext != null) {
//       data['ext'] = (ext is AccountEntryExtensionV1)
//           ? {'v': 1, ...ext.toJson()}
//           : {'v': 0};
//     }

//     return data;
//   }
// }

// // Define TrustLineFlags
// class TrustLineFlags {
//   static const int authorized = 1;
//   static const int authorizedToMaintainLiabilities = 2;
//   static const int trustlineClawbackEnabled = 4;

//   static const int mask = 1;
//   static const int maskV13 = 3;
//   static const int maskV17 = 7;
// }

// // Define TrustLineAsset
// class TrustLineAsset {
//   final AssetType type;
//   final AlphaNum4? alphaNum4;
//   final AlphaNum12? alphaNum12;
//   final PoolID? liquidityPoolID;

//   TrustLineAsset.native()
//       : type = AssetType.native,
//         alphaNum4 = null,
//         alphaNum12 = null,
//         liquidityPoolID = null;
//   TrustLineAsset.creditAlphanum4(this.alphaNum4)
//       : type = AssetType.creditAlphanum4,
//         alphaNum12 = null,
//         liquidityPoolID = null;
//   TrustLineAsset.creditAlphanum12(this.alphaNum12)
//       : type = AssetType.creditAlphanum12,
//         alphaNum4 = null,
//         liquidityPoolID = null;
//   TrustLineAsset.poolShare(this.liquidityPoolID)
//       : type = AssetType.poolShare,
//         alphaNum4 = null,
//         alphaNum12 = null;

//   factory TrustLineAsset.fromJson(Map<String, dynamic> json) {
//     final type = AssetType.values.firstWhere((e) => e.value == json['type']);
//     switch (type.value) {
//       case 0:
//         return TrustLineAsset.native();
//       case 1:
//         return TrustLineAsset.creditAlphanum4(
//             AlphaNum4.fromJson(json['alphaNum4']));
//       case 2:
//         return TrustLineAsset.creditAlphanum12(
//             AlphaNum12.fromJson(json['alphaNum12']));
//       case 3:
//         return TrustLineAsset.poolShare((json['liquidityPoolID'] as List<int>));
//       default:
//         throw ArgumentError('Unknown AssetType value: ${type.value}');
//     }
//   }

//   Map<String, dynamic> toJson() {
//     final data = {'type': type.value};
//     // switch (type.value) {
//     //   case 1:
//     //     data['alphaNum4'] = alphaNum4?.toJson();
//     //     break;
//     //   case 2:
//     //     data['alphaNum12'] = alphaNum12?.toJson();
//     //     break;
//     //   case 3:
//     //     data['liquidityPoolID'] = liquidityPoolID;
//     //     break;
//     // }
//     return data;
//   }
// }

// class TrustLineEntryExtensionV2 {
//   final int liquidityPoolUseCount;
//   final int ext; // Represents the union case (always 0 in this case).

//   TrustLineEntryExtensionV2(this.liquidityPoolUseCount) : ext = 0;
//   factory TrustLineEntryExtensionV2.fromJson(Map<String, dynamic> json) {
//     return TrustLineEntryExtensionV2(json["liquidityPoolUseCount"]);
//   }
// }

// // Define TrustLineEntry
// class TrustLineEntry {
//   final AccountID accountID;
//   final TrustLineAsset asset;
//   final int balance;
//   final int limit;
//   final int flags;
//   final dynamic ext; // Union type

//   TrustLineEntry(this.accountID, this.asset, this.balance, this.limit,
//       this.flags, this.ext);

//   factory TrustLineEntry.fromJson(Map<String, dynamic> json) {
//     final ext = json['ext'] as Map<String, dynamic>?;

//     return TrustLineEntry(
//       json['accountID'],
//       TrustLineAsset.fromJson(json['asset']),
//       json['balance'],
//       json['limit'],
//       json['flags'],
//       ext != null
//           ? (ext['v'] == 0 ? null : TrustLineEntryExtensionV2.fromJson(ext))
//           : null,
//     );
//   }

//   Map<String, dynamic> toJson() {
//     final data = {
//       'accountID': accountID,
//       'asset': asset.toJson(),
//       'balance': balance,
//       'limit': limit,
//       'flags': flags,
//     };

//     if (ext != null) {
//       data['ext'] = (ext is TrustLineEntryExtensionV2)
//           ? {'v': 1, ...ext.toJson()}
//           : {'v': 0};
//     }

//     return data;
//   }
// }

// // Define OfferEntry
// class OfferEntry {
//   final AccountID sellerID;
//   final int offerID;
//   final Asset selling;
//   final Asset buying;
//   final int amount;
//   final Price price;
//   final int flags;
//   final dynamic ext; // Union type

//   OfferEntry(this.sellerID, this.offerID, this.selling, this.buying,
//       this.amount, this.price, this.flags, this.ext);

//   factory OfferEntry.fromJson(Map<String, dynamic> json) {
//     final ext = json['ext'] as Map<String, dynamic>?;

//     return OfferEntry(
//       json['sellerID'],
//       json['offerID'],
//       Asset.fromJson(json['selling']),
//       Asset.fromJson(json['buying']),
//       json['amount'],
//       Price.fromJson(json['price']),
//       json['flags'],
//       ext?['v'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     final data = {
//       'sellerID': sellerID,
//       'offerID': offerID,
//       'selling': selling.toJson(),
//       'buying': buying.toJson(),
//       'amount': amount,
//       'price': price.toJson(),
//       'flags': flags,
//     };

//     // if (ext != null) {
//     //   data['ext'] = (ext is void) ? {'v': 0} : null;
//     // }

//     return data;
//   }
// }

// // Define DataEntry
// class DataEntry {
//   final AccountID accountID;
//   final String64 dataName;
//   final DataValue dataValue;
//   final dynamic ext; // Union type

//   DataEntry(this.accountID, this.dataName, this.dataValue, this.ext);

//   factory DataEntry.fromJson(Map<String, dynamic> json) {
//     final ext = json['ext'] as Map<String, dynamic>?;

//     return DataEntry(
//       json['accountID'],
//       json['dataName'],
//       Uint8List.fromList(json['dataValue'].cast<int>()),
//       ext?['v'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     final data = {
//       'accountID': accountID,
//       'dataName': dataName,
//       'dataValue': dataValue.toList(),
//     };

//     // if (ext != null) {
//     //   data['ext'] = (ext is void) ? {'v': 0} : null;
//     // }

//     return data;
//   }
// }

// class ClaimPredicateType {
//   final int value;

//   const ClaimPredicateType._(this.value);

//   static const ClaimPredicateType unconditional = ClaimPredicateType._(0);
//   static const ClaimPredicateType andPredicate = ClaimPredicateType._(1);
//   static const ClaimPredicateType orPredicate = ClaimPredicateType._(2);
//   static const ClaimPredicateType notPredicate = ClaimPredicateType._(3);
//   static const ClaimPredicateType beforeAbsoluteTime = ClaimPredicateType._(4);
//   static const ClaimPredicateType beforeRelativeTime = ClaimPredicateType._(5);

//   static const List<ClaimPredicateType> values = [
//     unconditional,
//     andPredicate,
//     orPredicate,
//     notPredicate,
//     beforeAbsoluteTime,
//     beforeRelativeTime
//   ];
// }

// // Define ClaimPredicate
// class ClaimPredicate {
//   final ClaimPredicateType type;
//   final dynamic predicateData;

//   ClaimPredicate.unconditional()
//       : type = ClaimPredicateType.unconditional,
//         predicateData = null;
//   ClaimPredicate.and(List<ClaimPredicate> predicates)
//       : type = ClaimPredicateType.andPredicate,
//         predicateData = predicates;
//   ClaimPredicate.or(List<ClaimPredicate> predicates)
//       : type = ClaimPredicateType.orPredicate,
//         predicateData = predicates;
//   ClaimPredicate.not(ClaimPredicate predicate)
//       : type = ClaimPredicateType.notPredicate,
//         predicateData = predicate;
//   ClaimPredicate.beforeAbsoluteTime(int absBefore)
//       : type = ClaimPredicateType.beforeAbsoluteTime,
//         predicateData = absBefore;
//   ClaimPredicate.beforeRelativeTime(int relBefore)
//       : type = ClaimPredicateType.beforeRelativeTime,
//         predicateData = relBefore;

//   factory ClaimPredicate.fromJson(Map<String, dynamic> json) {
//     final type =
//         ClaimPredicateType.values.firstWhere((e) => e.value == json['type']);
//     switch (type.value) {
//       case 0:
//         return ClaimPredicate.unconditional();
//       case 1:
//         return ClaimPredicate.and((json['andPredicates'] as List)
//             .map((e) => ClaimPredicate.fromJson(e))
//             .toList());
//       case 2:
//         return ClaimPredicate.or((json['orPredicates'] as List)
//             .map((e) => ClaimPredicate.fromJson(e))
//             .toList());
//       case 3:
//         return ClaimPredicate.not(
//             ClaimPredicate.fromJson(json['notPredicate']));
//       case 4:
//         return ClaimPredicate.beforeAbsoluteTime(json['absBefore']);
//       case 5:
//         return ClaimPredicate.beforeRelativeTime(json['relBefore']);
//       default:
//         throw ArgumentError('Unknown ClaimPredicateType value: ${type.value}');
//     }
//   }

//   Map<String, dynamic> toJson() {
//     final data = {'type': type.value};
//     // switch (type.value) {
//     //   case 1:
//     //     data['andPredicates'] = (predicateData as List<ClaimPredicate>).map((e) => e.toJson()).toList();
//     //     break;
//     //   case 2:
//     //     data['orPredicates'] = (predicateData as List<ClaimPredicate>).map((e) => e.toJson()).toList();
//     //     break;
//     //   case 3:
//     //     data['notPredicate'] = (predicateData as ClaimPredicate).toJson();
//     //     break;
//     //   case 4:
//     //     data['absBefore'] = predicateData;
//     //     break;
//     //   case 5:
//     //     data['relBefore'] = predicateData;
//     //     break;
//     // }
//     return data;
//   }
// }

// // Define Claimant
// class Claimant {
//   final ClaimantType type;
//   final AccountID destination;
//   final ClaimPredicate predicate;

//   Claimant.v0(this.destination, this.predicate) : type = ClaimantType();

//   factory Claimant.fromJson(Map<String, dynamic> json) {
//     throw UnimplementedError();
//     // final type = ClaimantType.values.firstWhere((e) => e.value == json['type']);
//     // switch (type.value) {
//     //   case 0:
//     //     return Claimant.v0(
//     //       json['destination'],
//     //       ClaimPredicate.fromJson(json['predicate']),
//     //     );
//     //   default:
//     //     throw ArgumentError('Unknown ClaimantType value: ${type.value}');
//     // }
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       // 'type': type.v,
//       'destination': destination,
//       'predicate': predicate.toJson(),
//     };
//   }
// }

// // Enums
// class ClaimantType {
//   static const int v0 = 0;
// }

// class ClaimableBalanceIDType {
//   static const int v0 = 0;
// }

// class ClaimableBalanceFlags {
//   static const int clawbackEnabledFlag = 0x1;
// }

// class LiquidityPoolType {
//   static const int constantProduct = 0;
// }

// class ContractDataDurability {
//   static const int temporary = 0;
//   static const int persistent = 1;
// }

// class EnvelopeType {
//   static const int txV0 = 0;
//   static const int scp = 1;
//   static const int tx = 2;
//   static const int auth = 3;
//   static const int scpValue = 4;
//   static const int txFeeBump = 5;
//   static const int opId = 6;
//   static const int poolRevokeOpId = 7;
//   static const int contractId = 8;
//   static const int sorobanAuthorization = 9;
// }

// // // Structs
// // class Claimant {
// //   final int type;
// //   final AccountID destination;
// //   final ClaimPredicate predicate;

// //   Claimant.v0(this.destination, this.predicate) : type = ClaimantType.v0;
// // }

// class ClaimableBalanceID {
//   final int type;
//   final Hash v0;

//   ClaimableBalanceID.v0(this.v0) : type = ClaimableBalanceIDType.v0;
// }

// class ClaimableBalanceEntryExtensionV1 {
//   final int ext;
//   final int flags;

//   ClaimableBalanceEntryExtensionV1(this.ext, this.flags);
// }

// class ClaimableBalanceEntry {
//   final ClaimableBalanceID balanceID;
//   final List<Claimant> claimants;
//   final Asset asset;
//   final int amount;
//   final dynamic ext;

//   ClaimableBalanceEntry(
//     this.balanceID,
//     this.claimants,
//     this.asset,
//     this.amount,
//     this.ext,
//   );
// }

// class LiquidityPoolConstantProductParameters {
//   final Asset assetA;
//   final Asset assetB;
//   final int fee;

//   LiquidityPoolConstantProductParameters(this.assetA, this.assetB, this.fee);
// }

// class LiquidityPoolEntry {
//   final PoolID liquidityPoolID;
//   final dynamic body;

//   LiquidityPoolEntry(this.liquidityPoolID, this.body);
// }

// class ContractDataEntry {
//   final ExtensionPoint ext;
//   final SCAddress contract;
//   final SCVal key;
//   final int durability;
//   final SCVal val;

//   ContractDataEntry(
//       this.ext, this.contract, this.key, this.durability, this.val);
// }

// class ContractCodeCostInputs {
//   final ExtensionPoint ext;
//   final int nInstructions;
//   final int nFunctions;
//   final int nGlobals;
//   final int nTableEntries;
//   final int nTypes;
//   final int nDataSegments;
//   final int nElemSegments;
//   final int nImports;
//   final int nExports;
//   final int nDataSegmentBytes;

//   ContractCodeCostInputs(
//     this.ext,
//     this.nInstructions,
//     this.nFunctions,
//     this.nGlobals,
//     this.nTableEntries,
//     this.nTypes,
//     this.nDataSegments,
//     this.nElemSegments,
//     this.nImports,
//     this.nExports,
//     this.nDataSegmentBytes,
//   );
// }

// typedef Hash = PoolID;

// class ContractCodeEntry {
//   final Hash hash;
//   final dynamic ext;

//   ContractCodeEntry(this.hash, this.ext);
// }

// class TTLEntry {
//   final Hash keyHash;
//   final int liveUntilLedgerSeq;

//   TTLEntry(this.keyHash, this.liveUntilLedgerSeq);
// }

// class LedgerEntryExtensionV1 {
//   final SponsorshipDescriptor sponsoringID;
//   final int ext;

//   LedgerEntryExtensionV1(this.sponsoringID, this.ext);
// }

// class LedgerEntry {
//   final int lastModifiedLedgerSeq;
//   final dynamic data;
//   final dynamic ext;

//   LedgerEntry(this.lastModifiedLedgerSeq, this.data, this.ext);
// }

// // Union-like class for LedgerKey
// class LedgerKey {
//   final int type;
//   final dynamic keyData;

//   LedgerKey.account(AccountID accountID)
//       : type = LedgerEntryType.account.value,
//         keyData = accountID;

//   LedgerKey.trustLine(AccountID accountID, TrustLineAsset asset)
//       : type = LedgerEntryType.trustline.value,
//         keyData = {'accountID': accountID, 'asset': asset};

//   LedgerKey.offer(AccountID sellerID, int offerID)
//       : type = LedgerEntryType.offer.value,
//         keyData = {'sellerID': sellerID, 'offerID': offerID};

//   LedgerKey.data(AccountID accountID, String dataName)
//       : type = LedgerEntryType.data.value,
//         keyData = {'accountID': accountID, 'dataName': dataName};

//   LedgerKey.claimableBalance(ClaimableBalanceID balanceID)
//       : type = LedgerEntryType.claimableBalance.value,
//         keyData = balanceID;

//   LedgerKey.liquidityPool(PoolID liquidityPoolID)
//       : type = LedgerEntryType.liquidityPool.value,
//         keyData = liquidityPoolID;

//   LedgerKey.contractData(SCAddress contract, SCVal key, int durability)
//       : type = LedgerEntryType.contractData.value,
//         keyData = {'contract': contract, 'key': key, 'durability': durability};

//   LedgerKey.contractCode(Hash hash)
//       : type = LedgerEntryType.contractCode.value,
//         keyData = hash;

//   LedgerKey.configSetting(ConfigSettingID configSettingID)
//       : type = LedgerEntryType.configSetting.value,
//         keyData = configSettingID;

//   LedgerKey.ttl(Hash keyHash)
//       : type = LedgerEntryType.ttl.value,
//         keyData = keyHash;
// }
