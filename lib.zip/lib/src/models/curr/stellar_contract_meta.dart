// class SCMetaV0 {
//   final String key;
//   final String val;

//   const SCMetaV0({
//     required this.key,
//     required this.val,
//   });

//   factory SCMetaV0.fromJson(Map<String, dynamic> json) {
//     return SCMetaV0(
//       key: json['key'],
//       val: json['val'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {'key': key, 'val': val};
//   }
// }

// class SCMetaKind {
//   final int value;

//   const SCMetaKind._(this.value);

//   static const SCMetaKind metaV0 = SCMetaKind._(0);

//   static const List<SCMetaKind> values = [metaV0];
// }

// class SCMetaEntry {
//   final SCMetaKind kind;
//   final SCMetaV0? v0;

//   const SCMetaEntry._({
//     required this.kind,
//     this.v0,
//   });

//   factory SCMetaEntry.fromJson(Map<String, dynamic> json) {
//     final kind = SCMetaKind.values.firstWhere((k) => k.value == json['kind']);
//     final v0 = kind == SCMetaKind.metaV0 ? SCMetaV0.fromJson(json['v0']) : null;
//     return SCMetaEntry._(kind: kind, v0: v0);
//   }

//   Map<String, dynamic> toJson() {
//     return {'kind': kind.value, 'v0': v0?.toJson()};
//   }
// }
