// import 'package:blockchain_utils/utils/utils.dart';

// class SCEnvMetaKind {
//   final int value;

//   const SCEnvMetaKind._(this.value);

//   static const SCEnvMetaKind interfaceVersion = SCEnvMetaKind._(0);

//   static const List<SCEnvMetaKind> values = [interfaceVersion];
// }

// class SCEnvMetaEntry {
//   final SCEnvMetaKind kind;
//   final BigInt? interfaceVersion;

//   // Private constructor
//   const SCEnvMetaEntry({required this.kind, this.interfaceVersion});

//   factory SCEnvMetaEntry.fromJson(Map<String, dynamic> json) {
//     final kind =
//         SCEnvMetaKind.values.firstWhere((k) => k.value == json['kind']);

//     return SCEnvMetaEntry(
//       kind: kind,
//       interfaceVersion: BigintUtils.tryParse(json['interfaceVersion']),
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'kind': kind.value,
//       'interfaceVersion': interfaceVersion?.toString()
//     };
//   }
// }
