import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:stellar_dart/src/constants/constant.dart';
import 'package:stellar_dart/src/exception/exception.dart';
import 'package:stellar_dart/src/keypair/keypair.dart';
import 'package:stellar_dart/src/models/asset/asset.dart';
import 'package:stellar_dart/src/models/base/curr.dart';
import 'package:stellar_dart/src/models/base/signer.dart';
import 'package:stellar_dart/src/serialization/serialization.dart';
import 'package:stellar_dart/src/utils/validator.dart';

class OperationType {
  final String name;
  final int value;

  const OperationType._({required this.name, required this.value});

  static const createAccount = OperationType._(name: 'CreateAccount', value: 0);
  static const payment = OperationType._(name: 'Payment', value: 1);
  static const pathPaymentStrictReceive =
      OperationType._(name: 'PathPaymentStrictReceive', value: 2);
  static const manageSellOffer =
      OperationType._(name: 'ManageSellOffer', value: 3);
  static const createPassiveSellOffer =
      OperationType._(name: 'CreatePassiveSellOffer', value: 4);
  static const setOptions = OperationType._(name: 'SetOptions', value: 5);
  static const changeTrust = OperationType._(name: 'ChangeTrust', value: 6);
  static const allowTrust = OperationType._(name: 'AllowTrust', value: 7);
  static const accountMerge = OperationType._(name: 'AccountMerge', value: 8);
  static const inflation = OperationType._(name: 'Inflation', value: 9);
  static const manageData = OperationType._(name: 'ManageData', value: 10);
  static const bumpSequence = OperationType._(name: 'BumpSequence', value: 11);
  static const manageBuyOffer =
      OperationType._(name: 'ManageBuyOffer', value: 12);
  static const pathPaymentStrictSend =
      OperationType._(name: 'PathPaymentStrictSend', value: 13);
  static const createClaimableBalance =
      OperationType._(name: 'CreateClaimableBalance', value: 14);
  static const claimClaimableBalance =
      OperationType._(name: 'ClaimClaimableBalance', value: 15);
  static const beginSponsoringFutureReserves =
      OperationType._(name: 'BeginSponsoringFutureReserves', value: 16);

  static const endSponsoringFutureReserves =
      OperationType._(name: 'EndSponsoringFutureReserves', value: 17);
  static const revokeSponsorship =
      OperationType._(name: 'RevokeSponsorship', value: 18);
  static const clawback = OperationType._(name: 'Clawback', value: 19);
  static const clawbackClaimableBalance =
      OperationType._(name: 'ClawbackClaimableBalance', value: 20);
  static const setTrustLineFlags =
      OperationType._(name: 'SetTrustLineFlags', value: 21);
  static const liquidityPoolDeposit =
      OperationType._(name: 'LiquidityPoolDeposit', value: 22);
  static const liquidityPoolWithdraw =
      OperationType._(name: 'LiquidityPoolWithdraw', value: 23);
  static const invokeHostFunction =
      OperationType._(name: 'InvokeHostFunction', value: 24);
  static const extendFootprintTtl =
      OperationType._(name: 'ExtendFootprintTtl', value: 25);
  static const restoreFootprint =
      OperationType._(name: 'RestoreFootprint', value: 26);
  static const List<OperationType> values = [
    createAccount,
    payment,
    pathPaymentStrictReceive,
    manageSellOffer,
    createPassiveSellOffer,
    setOptions,
    changeTrust,
    allowTrust,
    accountMerge,
    inflation,
    manageData,
    bumpSequence,
    manageBuyOffer,
    pathPaymentStrictSend,
    createClaimableBalance,
    claimClaimableBalance,
    beginSponsoringFutureReserves,
    endSponsoringFutureReserves,
    revokeSponsorship,
    clawback,
    clawbackClaimableBalance,
    setTrustLineFlags,
    liquidityPoolDeposit,
    liquidityPoolWithdraw,
    invokeHostFunction,
    extendFootprintTtl,
    restoreFootprint
  ];
}

class Operation<T extends OperationBody>
    extends XDRSerialization<Map<String, dynamic>> {
  final MuxedAccount? sourceAccount;
  final T body;
  const Operation({this.sourceAccount, required this.body});
  Layout<Map<String, dynamic>> layout({String? property}) =>
      LayoutConst.struct([
        LayoutConst.optionalU32Be(MuxedAccount.layout(),
            property: "sourceAccount"),
        OperationBody.layout(property: "body")
      ], property: property);
  Map<String, dynamic> toJson() {
    return {
      "body": body.toVariantLayoutStruct(),
      "sourceAccount": sourceAccount?.toVariantLayoutStruct()
    };
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "body": body.toVariantLayoutStruct(),
      "sourceAccount": sourceAccount?.toVariantLayoutStruct()
    };
  }
}

abstract class OperationBody
    extends XDRVariantSerialization<Map<String, dynamic>> {
  final OperationType operationType;
  const OperationBody(this.operationType);
  static Layout<
      Map<String,
          dynamic>> layout({String? property}) => LayoutConst.rustEnumU32Be(
      List.generate(OperationType.values.length, (i) {
        final type = OperationType.values.elementAt(i);
        switch (type) {
          case OperationType.payment:
            return PaymetOperation.layout(property: type.name);
          case OperationType.setOptions:
            return SetOptionsOperation.layout(property: type.name);
          case OperationType.pathPaymentStrictReceive:
            return PathPaymentStrictReceiveOperation.layout(
                property: type.name);
          case OperationType.createAccount:
            return CreateAccountOperation.layout(property: type.name);
          case OperationType.manageSellOffer:
            return ManageSellOfferOperation.layout(property: type.name);
          case OperationType.createPassiveSellOffer:
            return CreatePassiveSellOfferOperation.layout(property: type.name);
          case OperationType.changeTrust:
            return ChangeTrustOperation.layout(property: type.name);
          case OperationType.allowTrust:
            return AllowTrustOperation.layout(property: type.name);
          case OperationType.accountMerge:
            return AccountMergeOperation.layout(property: type.name);
          case OperationType.inflation:
            return InflationOperation.layout(property: type.name);
          case OperationType.manageData:
            return ManageDataOperation.layout(property: type.name);
          case OperationType.bumpSequence:
            return BumpSequenceOperation.layout(property: type.name);
          case OperationType.manageBuyOffer:
            return ManageBuyOfferOperation.layout(property: type.name);
          case OperationType.pathPaymentStrictSend:
            return PathPaymentStrictSendOperation.layout(property: type.name);
          case OperationType.createClaimableBalance:
            return CreateClaimableBalanceOperation.layout(property: type.name);
          case OperationType.claimClaimableBalance:
            return ClaimClaimableBalanceOperation.layout(property: type.name);
          case OperationType.beginSponsoringFutureReserves:
            return BeginSponsoringFutureReservesOperation.layout(
                property: type.name);
          case OperationType.endSponsoringFutureReserves:
            return EndSponsoringFutureReservesOperation.layout(
                property: type.name);
          case OperationType.revokeSponsorship:
            return RevokeSponsorshipOperation.layout(property: type.name);
          case OperationType.clawback:
            return ClawbackOperation.layout(property: type.name);
          case OperationType.clawbackClaimableBalance:
            return ClawbackClaimableBalanceOperation.layout(
                property: type.name);
          case OperationType.setTrustLineFlags:
            return SetTrustLineFlagsOperation.layout(property: type.name);
          case OperationType.liquidityPoolDeposit:
            return LiquidityPoolDepositOperation.layout(property: type.name);
          case OperationType.liquidityPoolWithdraw:
            return LiquidityPoolWithdrawOperation.layout(property: type.name);
          case OperationType.invokeHostFunction:
            return InvokeHostFunctionOperation.layout(property: type.name);
          case OperationType.extendFootprintTtl:
            return ExtendFootprintTtlOperation.layout(property: type.name);
          case OperationType.restoreFootprint:
            return RestoreFootprintOperation.layout(property: type.name);
          default:
            throw DartStellarPlugingException("Invalid Operation type.");
        }
      }),
      property: property);

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => operationType.name;
}

class PaymetOperation extends OperationBody {
  /// recipient of the payment
  final MuxedAccount destination;

  /// what they end up with
  final StellarAsset asset;

  /// amount they end up with
  final BigInt amount;
  PaymetOperation(
      {required this.destination, required this.asset, required BigInt amount})
      : amount = amount.asInt64,
        super(OperationType.payment);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MuxedAccount.layout(property: "destination"),
      StellarAsset.layout(property: "asset"),
      LayoutConst.s64be(property: "amount")
    ]);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "destination": destination.toVariantLayoutStruct(),
      "asset": asset.toVariantLayoutStruct(),
      "amount": amount
    };
  }
}

class CreateAccountOperation extends OperationBody {
  final StellarPublicKey destination;
  final BigInt startingBalance;
  CreateAccountOperation(
      {required this.destination, required BigInt startingBalance})
      : startingBalance = startingBalance.asInt64,
        super(OperationType.createAccount);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "destination"),
      LayoutConst.s64be(property: "startingBalance")
    ]);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "destination": destination.toLayoutStruct(),
      "startingBalance": startingBalance
    };
  }
}

class PathPaymentStrictReceiveOperation extends OperationBody {
  final StellarAsset sendAsset;
  final BigInt sendMax;
  final MuxedAccount destination;
  final StellarAsset destAsset;
  final BigInt destAmount;
  final List<StellarAsset> path;
  PathPaymentStrictReceiveOperation(
      {required this.sendAsset,
      required BigInt sendMax,
      required this.destination,
      required this.destAsset,
      required BigInt destAmount,
      List<StellarAsset> path = const []})
      : sendMax = sendMax.asInt64,
        destAmount = destAmount.asInt64,
        path = path.immutable.max(5),
        super(OperationType.pathPaymentStrictReceive);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarAsset.layout(property: "sendAsset"),
      LayoutConst.s64be(property: "sendMax"),
      MuxedAccount.layout(property: "destination"),
      StellarAsset.layout(property: "destAsset"),
      LayoutConst.s64be(property: "destAmount"),
      LayoutConst.xdrVec(StellarAsset.layout(), property: "path")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "sendAsset": sendAsset.toVariantLayoutStruct(),
      "sendMax": sendMax,
      "destination": destination.toVariantLayoutStruct(),
      "destAsset": destAsset.toVariantLayoutStruct(),
      "destAmount": destAmount,
      "path": path.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

class ManageSellOfferOperation extends OperationBody {
  final StellarAsset selling;
  final StellarAsset buying;
  final BigInt amount;
  final StellarPrice price;
  final BigInt offerId;
  ManageSellOfferOperation(
      {required this.selling,
      required this.buying,
      required BigInt amount,
      required this.price,
      required BigInt offerId})
      : amount = amount.asInt64,
        offerId = offerId.asInt64,
        super(OperationType.manageSellOffer);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarAsset.layout(property: "selling"),
      StellarAsset.layout(property: "buying"),
      LayoutConst.s64be(property: "amount"),
      StellarPrice.layout(property: "price"),
      LayoutConst.s64be(property: "offerId"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "selling": selling.toVariantLayoutStruct(),
      "buying": buying.toVariantLayoutStruct(),
      "amount": amount,
      "price": price.toLayoutStruct(),
      "offerId": offerId
    };
  }
}

class CreatePassiveSellOfferOperation extends OperationBody {
  final StellarAsset selling;
  final StellarAsset buying;
  final BigInt amount;
  final StellarPrice price;

  CreatePassiveSellOfferOperation({
    required this.selling,
    required this.buying,
    required BigInt amount,
    required this.price,
  })  : amount = amount.asInt64,
        super(OperationType.createPassiveSellOffer);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarAsset.layout(property: "selling"),
      StellarAsset.layout(property: "buying"),
      LayoutConst.s64be(property: "amount"),
      StellarPrice.layout(property: "price"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "selling": selling.toVariantLayoutStruct(),
      "buying": buying.toVariantLayoutStruct(),
      "amount": amount,
      "price": price.toLayoutStruct()
    };
  }
}

class SetOptionsOperation extends OperationBody {
  final StellarPublicKey? inflationDest;
  final AuthFlag? clearFlags;
  final AuthFlag? setFlags;
  final int? masterWeight;
  final int? lowThreshold;
  final int? medThreshold;
  final int? highThreshold;
  final String? homeDomain;
  final Signer? signer;

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.optionalU32Be(StellarPublicKey.layout(),
          property: "inflationDest"),
      LayoutConst.optionalU32Be(LayoutConst.u32be(), property: "clearFlags"),
      LayoutConst.optionalU32Be(LayoutConst.u32be(), property: "setFlags"),
      LayoutConst.optionalU32Be(LayoutConst.u32be(), property: "masterWeight"),
      LayoutConst.optionalU32Be(LayoutConst.u32be(), property: "lowThreshold"),
      LayoutConst.optionalU32Be(LayoutConst.u32be(), property: "medThreshold"),
      LayoutConst.optionalU32Be(LayoutConst.u32be(), property: "highThreshold"),
      LayoutConst.optionalU32Be(LayoutConst.xdrString(),
          property: "homeDomain"),
      LayoutConst.optionalU32Be(Signer.layout(), property: "signer"),
    ], property: property);
  }

  SetOptionsOperation(
      {this.inflationDest,
      this.clearFlags,
      this.setFlags,
      int? masterWeight,
      int? lowThreshold,
      int? medThreshold,
      int? highThreshold,
      this.homeDomain,
      this.signer})
      : masterWeight = masterWeight?.asUint32,
        lowThreshold = lowThreshold?.asUint32,
        medThreshold = medThreshold?.asUint32,
        highThreshold = highThreshold?.asUint32,
        super(OperationType.setOptions);

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "inflationDest": inflationDest?.toLayoutStruct(),
      "clearFlags": clearFlags?.value,
      "setFlags": setFlags?.value,
      "masterWeight": masterWeight,
      "lowThreshold": lowThreshold,
      "medThreshold": medThreshold,
      "highThreshold": highThreshold,
      "homeDomain": homeDomain,
      "signer": signer?.toLayoutStruct()
    };
  }
}

/// with pool asset
typedef ChangeTrustAsset = StellarAsset;

class ChangeTrustOperation extends OperationBody {
  final ChangeTrustAsset asset;
  final BigInt limit;
  ChangeTrustOperation({required this.asset, required BigInt limit})
      : limit = limit.asInt64,
        super(OperationType.changeTrust);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ChangeTrustAsset.layout(property: "asset"),
      LayoutConst.s64be(property: "limit"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"asset": asset.toVariantLayoutStruct(), "limit": limit};
  }
}

class AllowTrustOperation extends OperationBody {
  final StellarPublicKey trustor;
  final AssetCode asset;
  final int authorize;
  AllowTrustOperation(
      {required this.trustor, required this.asset, required int authorize})
      : authorize = authorize.asUint32,
        super(OperationType.allowTrust);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "trustor"),
      AssetCode.layout(property: "asset"),
      LayoutConst.u32be(property: "authorize")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "trustor": trustor.toLayoutStruct(),
      "asset": asset.toVariantLayoutStruct(),
      "authorize": authorize
    };
  }
}

class AccountMergeOperation extends OperationBody {
  final MuxedAccount account;
  AccountMergeOperation(this.account) : super(OperationType.accountMerge);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MuxedAccount.layout(property: "account"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"account": account.toVariantLayoutStruct()};
  }
}

class InflationOperation extends OperationBody {
  InflationOperation() : super(OperationType.inflation);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class ManageDataOperation extends OperationBody {
  final String dataName;
  final List<int>? dataValue;
  ManageDataOperation({required this.dataName, List<int>? dataValue})
      : dataValue = dataValue?.asImmutableBytes,
        super(OperationType.manageData);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.xdrString(property: "dataName"),
      LayoutConst.optionalU32Be(LayoutConst.xdrVecBytes(),
          property: "dataValue"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"dataName": dataName, "dataValue": dataValue};
  }
}

class BumpSequenceOperation extends OperationBody {
  final BigInt bumpTo;
  BumpSequenceOperation(BigInt bumpTo)
      : bumpTo = bumpTo.asInt64,
        super(OperationType.bumpSequence);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.s64be(property: "bumpTo"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"bumpTo": bumpTo};
  }
}

class ManageBuyOfferOperation extends OperationBody {
  final StellarAsset selling;
  final StellarAsset buying;
  final BigInt buyAmount;
  final StellarPrice price;
  final BigInt offerId;
  ManageBuyOfferOperation(
      {required this.selling,
      required this.buying,
      required BigInt buyAmount,
      required this.price,
      required BigInt offerId})
      : buyAmount = buyAmount.asInt64,
        offerId = offerId.asInt64,
        super(OperationType.manageBuyOffer);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarAsset.layout(property: "selling"),
      StellarAsset.layout(property: "buying"),
      LayoutConst.s64be(property: "buyAmount"),
      StellarPrice.layout(property: "price"),
      LayoutConst.s64be(property: "offerId"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "selling": selling.toVariantLayoutStruct(),
      "buying": buying.toVariantLayoutStruct(),
      "buyAmount": buyAmount,
      "price": price.toLayoutStruct(),
      "offerId": offerId
    };
  }
}

class PathPaymentStrictSendOperation extends OperationBody {
  final StellarAsset sendAsset;
  final BigInt sendAmount;
  final MuxedAccount destination;
  final StellarAsset destAsset;
  final BigInt destMin;
  final List<StellarAsset> path;

  PathPaymentStrictSendOperation({
    required this.sendAsset,
    required BigInt sendAmount,
    required this.destination,
    required this.destAsset,
    required BigInt destMin,
    List<StellarAsset> path = const [],
  })  : sendAmount = sendAmount.asInt64,
        destMin = destMin.asInt64,
        path = path.immutable.max(5),
        super(OperationType.pathPaymentStrictSend);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarAsset.layout(property: "sendAsset"),
      LayoutConst.s64be(property: "sendAmount"),
      MuxedAccount.layout(property: "destination"),
      StellarAsset.layout(property: "destAsset"),
      LayoutConst.s64be(property: "destMin"),
      LayoutConst.xdrVec(StellarAsset.layout(), property: "path")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "sendAsset": sendAsset.toVariantLayoutStruct(),
      "sendAmount": sendAmount,
      "destination": destination.toVariantLayoutStruct(),
      "destAsset": destAsset.toVariantLayoutStruct(),
      "destMin": destMin,
      "path": path.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

class CreateClaimableBalanceOperation extends OperationBody {
  final StellarAsset asset;
  final BigInt amount;
  final List<Claimant> claimants;
  CreateClaimableBalanceOperation(
      {required this.asset,
      required BigInt amount,
      required List<Claimant> claimants})
      : amount = amount.asInt64,
        claimants = claimants.immutable.max(10),
        super(OperationType.createClaimableBalance);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarAsset.layout(property: "asset"),
      LayoutConst.s64be(property: "amount"),
      LayoutConst.xdrVec(Claimant.layout(), property: "claimants")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "asset": asset.toVariantLayoutStruct(),
      "amount": amount,
      "claimants": claimants.map((e) => e.toVariantLayoutStruct()).toList()
    };
  }
}

class ClaimClaimableBalanceOperation extends OperationBody {
  final ClaimableBalanceId balanceID;
  ClaimClaimableBalanceOperation(
      {required this.balanceID,
      required BigInt amount,
      required List<Claimant> claimants})
      : super(OperationType.claimClaimableBalance);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [ClaimableBalanceId.layout(property: "balanceID")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"balanceID": balanceID.toVariantLayoutStruct()};
  }
}

class BeginSponsoringFutureReservesOperation extends OperationBody {
  final StellarPublicKey sponsoredId;
  const BeginSponsoringFutureReservesOperation(this.sponsoredId)
      : super(OperationType.beginSponsoringFutureReserves);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [StellarPublicKey.layout(property: "sponsoredId")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"sponsoredId": sponsoredId.toLayoutStruct()};
  }
}

class EndSponsoringFutureReservesOperation extends OperationBody {
  const EndSponsoringFutureReservesOperation()
      : super(OperationType.endSponsoringFutureReserves);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.noArgs(property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {};
  }
}

class RevokeSponsorshipOperation extends OperationBody {
  final RevokeSponsorship revokeSponsorship;
  const RevokeSponsorshipOperation(this.revokeSponsorship)
      : super(OperationType.revokeSponsorship);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct(
        [RevokeSponsorship.layout(property: "revokeSponsorship")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"revokeSponsorship": revokeSponsorship.toVariantLayoutStruct()};
  }
}

class ClawbackOperation extends OperationBody {
  final StellarAsset asset;
  final MuxedAccount from;
  final BigInt amount;
  ClawbackOperation(
      {required this.asset, required this.from, required BigInt amount})
      : amount = amount.asInt64,
        super(OperationType.clawback);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarAsset.layout(property: "asset"),
      MuxedAccount.layout(property: "from"),
      LayoutConst.s64be(property: "amount")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "asset": asset.toVariantLayoutStruct(),
      "from": from.toVariantLayoutStruct(),
      "amount": amount,
    };
  }
}

class ClawbackClaimableBalanceOperation extends OperationBody {
  final ClaimableBalanceId balanceId;
  const ClawbackClaimableBalanceOperation(this.balanceId)
      : super(OperationType.clawbackClaimableBalance);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ClaimableBalanceId.layout(property: "balanceId"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"balanceId": balanceId.toVariantLayoutStruct()};
  }
}

class SetTrustLineFlagsOperation extends OperationBody {
  final StellarPublicKey trustor;
  final StellarAsset asset;
  final int clearFlags;
  final int setFlags;
  SetTrustLineFlagsOperation(
      {required this.trustor,
      required this.asset,
      required int clearFlags,
      required int setFlags})
      : clearFlags = clearFlags.asUint32,
        setFlags = setFlags.asUint32,
        super(OperationType.setTrustLineFlags);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      StellarPublicKey.layout(property: "trustor"),
      StellarAsset.layout(property: "asset"),
      LayoutConst.u32be(property: "clearFlags"),
      LayoutConst.u32be(property: "setFlags"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "trustor": trustor.toLayoutStruct(),
      "asset": asset.toVariantLayoutStruct(),
      "clearFlags": clearFlags,
      "setFlags": setFlags
    };
  }
}

class LiquidityPoolDepositOperation extends OperationBody {
  final List<int> liquidityPoolId;
  final BigInt maxAmountA;
  final BigInt maxAmountB;
  final StellarPrice minPrice;
  final StellarPrice maxPrice;
  LiquidityPoolDepositOperation(
      {required List<int> liquidityPoolId,
      required BigInt maxAmountA,
      required BigInt maxAmountB,
      required this.minPrice,
      required this.maxPrice})
      : liquidityPoolId =
            liquidityPoolId.asImmutableBytes.max(StellarConst.hash256Length),
        maxAmountA = maxAmountA.asInt64,
        maxAmountB = maxAmountB.asInt64,
        super(OperationType.liquidityPoolDeposit);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length,
          property: "liquidityPoolId"),
      LayoutConst.s64be(property: "maxAmountA"),
      LayoutConst.s64be(property: "maxAmountB"),
      StellarPrice.layout(property: "minPrice"),
      StellarPrice.layout(property: "maxPrice")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "liquidityPoolId": liquidityPoolId,
      "maxAmountA": maxAmountA,
      "maxAmountB": maxAmountB,
      "minPrice": minPrice.toLayoutStruct(),
      "maxPrice": maxPrice.toLayoutStruct()
    };
  }
}

class LiquidityPoolWithdrawOperation extends OperationBody {
  final List<int> liquidityPoolId;
  final BigInt amount;
  final BigInt minAmountA;
  final BigInt minAmountB;
  LiquidityPoolWithdrawOperation({
    required List<int> liquidityPoolId,
    required BigInt amount,
    required BigInt minAmountA,
    required BigInt minAmountB,
  })  : liquidityPoolId =
            liquidityPoolId.asImmutableBytes.max(StellarConst.hash256Length),
        amount = amount.asInt64,
        minAmountA = minAmountA.asInt64,
        minAmountB = minAmountB.asInt64,
        super(OperationType.liquidityPoolWithdraw);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.fixedBlobN(StellarConst.hash256Length,
          property: "liquidityPoolId"),
      LayoutConst.s64be(property: "amount"),
      LayoutConst.s64be(property: "minAmountA"),
      LayoutConst.s64be(property: "minAmountB"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "liquidityPoolId": liquidityPoolId,
      "amount": amount,
      "minAmountA": minAmountA,
      "minAmountB": minAmountB,
    };
  }
}

class InvokeHostFunctionOperation extends OperationBody {
  final HostFunction hostFunction;
  final List<SorobanAuthorizationEntry> auth;
  InvokeHostFunctionOperation(
      {required this.hostFunction,
      required List<SorobanAuthorizationEntry> auth})
      : auth = auth.immutable,
        super(OperationType.invokeHostFunction);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      HostFunction.layout(property: "hostFunction"),
      LayoutConst.xdrVec(SorobanAuthorizationEntry.layout(), property: "auth")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "hostFunction": hostFunction.toVariantLayoutStruct(),
      "auth": auth.map((e) => e.toLayoutStruct()).toList()
    };
  }
}

class ExtendFootprintTtlOperation extends OperationBody {
  final ExtentionPointVoid ext = ExtentionPointVoid();
  final int extendTo;
  ExtendFootprintTtlOperation({required int extendTo})
      : extendTo = extendTo.asUint32,
        super(OperationType.extendFootprintTtl);
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      ExtentionPointVoid.layout(property: "ext"),
      LayoutConst.u32be(property: "extendTo"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"extendTo": extendTo, "ext": ext.toVariantLayoutStruct()};
  }
}

class RestoreFootprintOperation extends OperationBody {
  final ExtentionPointVoid ext = ExtentionPointVoid();
  RestoreFootprintOperation() : super(OperationType.restoreFootprint);

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([ExtentionPointVoid.layout(property: "ext")],
        property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"ext": ext.toVariantLayoutStruct()};
  }
}
